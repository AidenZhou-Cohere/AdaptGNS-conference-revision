"""Synthetic full-grid collector/summary integration; no models, arrays or children."""
import copy
from datetime import datetime, timedelta, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import test_goop2d_validation_cost_v3 as F


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
    path.write_bytes(raw)
    return hashlib.sha256(raw).hexdigest()


def fixture(root):
    repo = root / 'repo'
    sources = repo / 'cuda_preparation'
    sources.mkdir(parents=True)
    names = ('goop2d_validation_cost_contract_v3.py', 'summarize_goop2d_validation_cost_v1.py',
             'collect_goop2d_validation_cost_scalars_v1.py')
    for name in names:
        (sources / name).write_bytes((HERE / name).read_bytes())
    C = load(sources / names[0], '_integration_contract')
    S = load(sources / names[1], '_integration_summary')
    K = load(sources / names[2], '_integration_collector')
    K.S = S  # Same copied summary dependency; do not affect production modules.
    release = F.release()
    old_repo = release['repo']
    def relocate(value):
        if isinstance(value, str) and value.startswith(old_repo):
            return str(repo) + value[len(old_repo):]
        if isinstance(value, dict):
            return {k: relocate(v) for k, v in value.items()}
        if isinstance(value, list):
            return [relocate(v) for v in value]
        return value
    release = relocate(release)
    release.update(schema=C.SCHEMA, status='admitted_full', phase='full', full_admission_utc='2026-10-06T20:05:00+00:00',
        pilot_receipt={'path': str(root / 'controls' / 'pilot.json'), 'sha256': 'd' * 64},
        pilot_external_closure={'path': str(root / 'controls' / 'pilot_closure.json'), 'sha256': 'e' * 64},
        hardware_memory_evidence={'path': str(repo / 'hardware' / 'qualification.json'), 'sha256': C.HARDWARE_MEMORY_SHA})
    release['sources'] = {name: dict(path=str(sources / name), sha256=C.FROZEN.get(name, 'f' * 64))
                          for name in (*C.FROZEN, *C.NEW_SOURCES)}
    release['sources'][names[0]]['sha256'] = S.sha(sources / names[0])
    release['reporting_sources'] = {name: dict(path=str(sources / name), sha256=S.sha(sources / name)) for name in names[1:]}
    for gpu in release['gpus']:
        gpu.pop('total_memory_bytes', None)
        gpu.update(nvidia_smi_total_memory_mib=189471, cuda_mem_get_info_total_bytes=197897617408)
    manifest = {'records': F.records()}
    manifest_path = Path(release['controls']['manifest']['path'])
    release['controls']['manifest']['sha256'] = write(manifest_path, manifest)
    release_path = root / 'controls' / 'full_release.json'
    release_hash = write(release_path, release)
    identity = C.validate_release(release, 'full', now=C.stamp('2026-10-06T20:10:00+00:00'), verify=False)
    schedule = C.schedule(F.records(), 'full')
    children = []
    for model in release['models']:
        arm, seed = model['arm'], model['seed']
        output = Path(release['outputs']['full']) / ('seed%d_%s' % (seed, arm))
        committed = []
        for item in schedule:
            row = F.scalar_fixture(item, seed)
            for memory in row['memory']:
                memory.update(device_total_bytes=197897617408, nvidia_smi_total_memory_mib=189471)
            factor = (seed + 1) * (2 if arm == 'mix' else 1)
            for call in row['timed_calls']:
                for key in S.TIMES:
                    call['timing'][key] *= factor
            name = 'state_%03d.json' % item['schedule_index']
            row.update(artifact_file=name.replace('.json', '.npz'), artifact_sha256='0' * 64)
            committed.append(dict(schedule_index=item['schedule_index'], path=name, sha256=write(output / name, row)))
        receipt = dict(schema=C.CHILD_SCHEMA, status='complete', phase='full', study_identity=identity,
            arm=arm, seed=seed, release_sha256=release_hash, checkpoint_sha256=model['checkpoint']['sha256'],
            actual_checkpoint_path=model['checkpoint']['path'], original_checkpoint_path=model['original_checkpoint_path'],
            gpu_uuid=release['streams'][seed]['gpu_uuid'], schedule=schedule, blocks=150, complete_forwards=11400,
            all_inputs_reverified=True, all_memory_reference_hashes_equal=True, all_headroom_checks_passed=True,
            committed=committed, host_peak_rss_kib=123456 + seed,
            host_peak_rss_scope='Linux process lifetime, separately from CUDA allocator observations')
        children.append(dict(arm=arm, seed=seed, output=str(output), verified=True, reaped=True, exit_code=0,
            signals=[], receipt_sha256=write(output / 'receipt.json', receipt)))
    owner = dict(schema=C.OWNER_SCHEMA, status='complete', phase='full', failure=None, study_identity=identity,
        release_sha256=release_hash, all_children_reaped=True, final_gpu_processes=[], observed_complete_blocks=900,
        clock_origin=release['clock_origin'], phase_started_monotonic=300, completed_monotonic=600,
        completed_utc='2026-10-06T20:10:00+00:00', children=children)
    owner_path = Path(release['outputs']['full']) / 'owner_receipt.json'
    owner_hash = write(owner_path, owner)
    closure = dict(schema='adaptgns_goop2d_validation_cost_full_external_closure_v1', issued_by='root',
        status='original_session_exit_and_native_absence_verified', owner_receipt_sha256=owner_hash,
        original_session_exit_code=0, owner_native_absent=True, all_children_native_absent=True, gpu_processes=[],
        host_boot_id=release['clock_origin']['host_boot_id'], checked_utc='2026-10-06T20:10:01+00:00',
        checked_host_monotonic_seconds=601)
    closure_path = root / 'controls' / 'full_closure.json'
    write(closure_path, closure)
    return C, S, K, release, release_path, owner_path, closure_path


class FullReportingIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory(prefix='goop2d_scalar_integration_')
        cls.root = Path(cls.temporary.name).resolve()
        cls.C, cls.S, cls.K, cls.release, cls.release_path, cls.owner_path, cls.closure_path = fixture(cls.root)
        cls.bundle = cls.root / 'scalars'
        with patch.object(cls.S, 'deadline_check', return_value={'synthetic_clock_only': True}):
            cls.collection = cls.K.collect(cls.release_path, cls.owner_path, cls.closure_path, cls.bundle)
        cls.contract = cls.root / 'repo' / 'cuda_preparation' / 'goop2d_validation_cost_contract_v3.py'

    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()

    def test_complete_six_model_900_block_pipeline(self):
        result = self.S.summarize(self.bundle, self.contract)
        self.assertEqual(result['coverage']['blocks'], 900)
        self.assertEqual(result['coverage']['models'], 6)
        self.assertEqual(len(result['per_model']), 6)
        self.assertEqual(len(self.collection['files']), 910)
        self.assertEqual(len(result['input_scalar_sha256']), 910)
        self.assertEqual(result['three_seed_summaries']['base']['base']['end_to_end_seconds']['seed_values'], [1, 2, 3])
        self.assertEqual(result['three_seed_summaries']['base']['mix']['end_to_end_seconds']['seed_values'], [2, 4, 6])
        effect = result['graph_exposure_mix_minus_base']['base']['end_to_end_seconds']
        self.assertEqual(effect['difference_second_minus_first']['seed_values'], [1, 2, 3])
        self.assertEqual(effect['paired_percent_change']['seed_values'], [100, 100, 100])
        self.assertTrue(all(m['host_peak_rss_kib'] == 123456 + m['seed'] for m in result['per_model']))
        self.assertFalse(result['scope']['accuracy_reported'])
        self.assertFalse(result['scope']['numeric_arrays_independently_reloaded'])
        self.assertFalse(list(self.root.rglob('*.npz')))
        self.assertFalse(list(self.root.rglob('*.pt')))

    def test_missing_state_and_changed_scalar_bytes_rejected(self):
        path = self.bundle / 'seed0_base' / 'state_000.json'
        original = path.read_bytes()
        for kind in ('missing', 'changed'):
            try:
                if kind == 'missing':
                    path.unlink()
                else:
                    path.write_bytes(original + b' ')
                with self.subTest(kind=kind), self.assertRaises(ValueError):
                    self.S.summarize(self.bundle, self.contract)
            finally:
                path.write_bytes(original)

    def test_failed_original_closure_rejected_without_partial_estimate(self):
        path = self.bundle / 'external_closure.json'
        original = path.read_bytes()
        try:
            bad = json.loads(original); bad['original_session_exit_code'] = 1
            write(path, bad)
            with self.assertRaises(ValueError):
                self.S.summarize(self.bundle, self.contract)
        finally:
            path.write_bytes(original)

    def test_reporting_source_drift_rejected_before_collection(self):
        source = self.root / 'repo' / 'cuda_preparation' / 'summarize_goop2d_validation_cost_v1.py'
        original = source.read_bytes()
        try:
            source.write_bytes(original + b'\n# synthetic source drift\n')
            with patch.object(self.S, 'deadline_check', return_value={}), self.assertRaises(ValueError):
                self.K.collect(self.release_path, self.owner_path, self.closure_path, self.root / 'must_not_exist')
            self.assertFalse((self.root / 'must_not_exist').exists())
        finally:
            source.write_bytes(original)

    def test_reporting_clock_failure_blocks_collection(self):
        with patch.object(self.S, 'deadline_check', side_effect=ValueError('synthetic original clock expired')):
            with self.assertRaises(ValueError):
                self.K.collect(self.release_path, self.owner_path, self.closure_path, self.root / 'expired')
        self.assertFalse((self.root / 'expired').exists())

    def test_actual_clock_guard_rejects_reboot_shift_and_spent_error_reserve(self):
        release = copy.deepcopy(self.release)
        release['clock_origin']['error_bound_seconds'] = 5
        cases = [
            ('safe', 600, 600, 'synthetic-host', 'synthetic-boot', True),
            ('different_host', 600, 600, 'other-host', 'synthetic-boot', False),
            ('reboot', 600, 600, 'synthetic-host', 'other-boot', False),
            ('wall_rollback', 600, 590, 'synthetic-host', 'synthetic-boot', False),
            ('error_reserve_spent', 3596, 3596, 'synthetic-host', 'synthetic-boot', False),
            ('negative_monotonic', -1, -1, 'synthetic-host', 'synthetic-boot', False),
        ]
        for name, mono, wall, host, boot, accepted in cases:
            observed = datetime(2026, 10, 6, 20, tzinfo=timezone.utc) + timedelta(seconds=wall)
            clock = SimpleNamespace(now=lambda zone: observed, fromisoformat=datetime.fromisoformat)
            with self.subTest(name=name), patch.object(self.S, 'datetime', clock), \
                    patch.object(self.S.time, 'monotonic', return_value=mono), \
                    patch.object(self.S.socket, 'gethostname', return_value=host), \
                    patch.object(Path, 'read_text', return_value=boot):
                if accepted:
                    self.assertEqual(self.S.deadline_check(release)['remaining_seconds'], 2995)
                else:
                    with self.assertRaises(ValueError):
                        self.S.deadline_check(release)

    def test_no_numerical_imports_or_payload_files(self):
        self.assertFalse({'torch', 'numpy', 'scipy'} & set(sys.modules))
        self.assertFalse(list(self.root.rglob('*.npy')))


if __name__ == '__main__':
    unittest.main(verbosity=2)
