"""CPU-only lifecycle evidence and capacity boundary regression checks."""
import json
from pathlib import Path
import tempfile
import unittest
import audit_goop2d_v3_pilot_lifecycle_transition_v1 as A

PREP = Path(__file__).resolve().parent


class LifecycleTests(unittest.TestCase):
    def setUp(self):
        self.spec = json.loads((PREP/'goop2d_v3_lifecycle_actual_inputs_transition_v1.json').read_text())

    def mutation(self, role, change, message):
        with tempfile.TemporaryDirectory() as temp:
            data = json.loads(Path(self.spec[role]).read_bytes())
            change(data)
            path = Path(temp)/'evidence.json'
            path.write_text(json.dumps(data))
            spec = dict(self.spec, **{role:str(path)})
            with self.assertRaisesRegex(ValueError, message):
                A.audit(spec)

    def test_actual_failed_lifecycle_is_closed_without_capacity(self):
        result = A.audit(self.spec)
        self.assertEqual(result['status'], 'failed_pilot_closed_no_cost_result_no_full_admission')
        self.assertIsNone(result['forecast'])
        self.assertFalse(result['scientific_results_admitted'])
        self.assertEqual(result['observed_owner_attached_complete_blocks'], 0)
        self.assertEqual([c['exit_code'] for c in result['children']], [-2, 0, 0])
        self.assertTrue(any('refusing signal' in w for w in result['warnings']))

    def test_unscoped_empty_process_list_is_not_pid_absence(self):
        self.mutation('native_closure', lambda r:r.update(native_absent={}, processes=[]), 'Explicit PID absence')

    def test_different_boot_cannot_prove_closure(self):
        self.mutation('native_closure', lambda r:r.update(host_boot_id='another-boot'), 'another boot')

    def test_missing_terminal_cannot_use_candidate(self):
        spec = dict(self.spec)
        spec.pop('owner_receipt')
        with self.assertRaisesRegex(ValueError, 'Missing owner_receipt'):
            A.audit(spec)

    def test_partial_child_receipts_do_not_make_success(self):
        self.mutation('owner_receipt', lambda r:r.update(status='complete', failure=None), 'Original complete pilot')

    def test_external_exit_zero_contradicts_actual_failure(self):
        self.mutation('external_exit', lambda r:r.update(exit_code=0), 'Contradictory failed')

    def test_original_staging_cutoff_is_strict(self):
        self.mutation('owner_receipt', lambda r:r.update(phase_started_monotonic=A.ORIGIN['host_monotonic_seconds']+895), 'staging cutoff')

    def test_historical_inventory_must_bind_terminal_bytes(self):
        self.mutation('native_closure', lambda r:r['files']['owner_receipt.json'].update(sha256='0'*64), 'Historical closure bytes differ')

    def test_self_consistent_foreign_child_command_is_rejected(self):
        def change(record):
            child = record['children'][0]
            child['command'][1] = '/foreign/measure.py'
            child['identity']['argv'][1] = '/foreign/measure.py'
        self.mutation('owner_receipt', change, 'Child command differs')

    @staticmethod
    def rows():
        return [dict(arm=a, seed=s, status='complete', phase='pilot', blocks=15,
                     complete_forwards=1140, all_inputs_reverified=True,
                     all_memory_reference_hashes_equal=True, all_headroom_checks_passed=True,
                     setup_seconds=2, finalization_seconds=3,
                     publication_inclusive_block_seconds=[1]*15,
                     maximum_publication_inclusive_block_seconds=1,
                     owner_verification_block_seconds=[0.1]*15,
                     maximum_owner_verification_block_seconds=0.1)
                for a,s in sorted(A.PAIRS)]

    def test_owner_verification_is_serial_and_capacity_boundary_inclusive(self):
        rows = self.rows()
        expected_work = 2*(2+1.35*150+3)+6*1.35*150*.1
        exact_elapsed = 3600-(5+60+expected_work+90+450)
        result = A.measured_forecast(rows, exact_elapsed)
        self.assertAlmostEqual(result['work_seconds'], expected_work)
        self.assertTrue(result['arithmetic_fits'])
        self.assertFalse(A.measured_forecast(rows, exact_elapsed+1e-5)['arithmetic_fits'])

    def test_missing_nan_negative_or_infinite_rates_are_rejected(self):
        for value in (float('nan'),float('inf'),-0.1,None):
            rows = self.rows()
            rows[0]['owner_verification_block_seconds'][0] = value
            with self.subTest(value=value), self.assertRaises(ValueError):
                A.measured_forecast(rows, 100)


if __name__ == '__main__':
    unittest.main()
