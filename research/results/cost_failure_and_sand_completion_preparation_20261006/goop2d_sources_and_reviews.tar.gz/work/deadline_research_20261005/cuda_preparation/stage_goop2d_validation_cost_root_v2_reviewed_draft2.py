#!/usr/bin/env python3
"""Root staging only; never launches a pilot. No action without --execute.

The first remote sample starts the immutable 3600-second clock. All transfer,
source staging and full opaque input hashing count toward initial 300 seconds.
"""
import argparse,base64,datetime,hashlib,json,pathlib,shlex,subprocess,time
P=pathlib.Path(__file__).resolve().parent
B='aquamarine-toad-75.coder';A='yellow-worm-77.coder'
PYTHON='/root/repos/AdaptGNS-cuda-20261006/.venv/bin/python'

def dump(path,value):
 with path.open('x') as f: json.dump(value,f,indent=2,sort_keys=True);f.write('\n')

def runssh(code,data,output,name,timeout=60):
 assert timeout>0,'No remaining monotonic staging time'
 start=datetime.datetime.now(datetime.timezone.utc)
 try:
  p=subprocess.run(['ssh','-T','-F',str(P/'ssh_config'),B,PYTHON+' -B -c '+shlex.quote(code)],input=json.dumps(data),text=True,capture_output=True,timeout=timeout)
 except subprocess.TimeoutExpired as e:
  def txt(v):return v.decode(errors='replace') if isinstance(v,bytes) else v or ''
  (output/(name+'.stdout')).write_text(txt(e.stdout));(output/(name+'.stderr')).write_text(txt(e.stderr))
  dump(output/(name+'.external.json'),dict(status='local_ssh_timeout_remote_closure_required',local_before_utc=start.isoformat(),local_after_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),timeout_seconds=timeout,no_retry=True))
  raise
 end=datetime.datetime.now(datetime.timezone.utc)
 (output/(name+'.stdout')).write_text(p.stdout);(output/(name+'.stderr')).write_text(p.stderr)
 dump(output/(name+'.external.json'),dict(exit_code=p.returncode,local_before_utc=start.isoformat(),local_after_utc=end.isoformat()))
 if p.returncode:raise RuntimeError(name+' failed; preserve clock and outputs, no automatic retry')
 value=json.loads(p.stdout);dump(output/(name+'.json'),value)
 return value,start,end

CAPTURE=r'''import pathlib,os,json,sys,socket,time,datetime,subprocess
x=json.load(sys.stdin);clock=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),host_monotonic_seconds=time.monotonic(),host_boot_id=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),error_bound_seconds=5)
rows=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdecimal() or int(p.name)==os.getpid():continue
 try:
  argv=[s.decode(errors='surrogateescape') for s in (p/'cmdline').read_bytes().split(b'\0') if s];fs=(p/'stat').read_text().rsplit(') ',1)[1].split();names=[pathlib.Path(a).name for a in argv]
  if any((n.startswith(('train_','evaluate_','supervise_','measure_goop2d_validation_cost')) and n.endswith('.py')) for n in names): rows.append(dict(pid=int(p.name),ppid=int(fs[1]),start_ticks=int(fs[19]),argv=argv))
 except (FileNotFoundError,ProcessLookupError):pass
apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,process_name','--format=csv,noheader,nounits'],text=True,timeout=5)
gpus=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,name,memory.total','--format=csv,noheader,nounits'],text=True,timeout=5)
missing={str(pid):not (pathlib.Path('/proc')/str(pid)).exists() for pid in [56878,57161]}
out=dict(clock_origin=clock,hostname=socket.gethostname(),pid=os.getpid(),scientific_processes=rows,gpu_apps=apps,gpus=gpus,qualification_native_absent=missing,destinations_unused={p:not pathlib.Path(p).exists() for p in x['new_paths']})
print(json.dumps(out))
assert out['hostname']==x['hostname'] and not rows and not apps.strip() and all(missing.values()) and all(out['destinations_unused'].values())
'''

STAGE=r'''import pathlib,sys,json,base64,hashlib,time,datetime,socket,os
x=json.load(sys.stdin);c=x['clock'];assert pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()==c['host_boot_id'];assert socket.gethostname()==x['hostname']
print(json.dumps(dict(mode='stage',pid=os.getpid(),start_ticks=int(pathlib.Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19]))),file=sys.stderr,flush=True)
def check():
 mono=time.monotonic()-c['host_monotonic_seconds'];wall=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(c['checked_utc'])).total_seconds();assert mono>=0 and abs(wall-mono)<=5 and max(mono,wall)+5<300
check()
result={}
for path,value in x['files'].items():
 check();p=pathlib.Path(path);raw=base64.b64decode(value['base64']);assert hashlib.sha256(raw).hexdigest()==value['sha256'];p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:
  for off in range(0,len(raw),1<<20):check();f.write(raw[off:off+(1<<20)])
  f.flush();os.fsync(f.fileno());check()
 result[path]=hashlib.sha256(p.read_bytes()).hexdigest();assert result[path]==value['sha256']
for path in x['new_dirs']:check();pathlib.Path(path).mkdir(parents=True,exist_ok=False)
check()
print(json.dumps(dict(files=result,elapsed_monotonic_seconds=time.monotonic()-c['host_monotonic_seconds'])))
check()
'''

VERIFY=r'''import pathlib,sys,json,hashlib,time,datetime,socket,os
x=json.load(sys.stdin);c=x['clock'];assert pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()==c['host_boot_id'];assert socket.gethostname()==x['hostname'];result={}
print(json.dumps(dict(mode='verify',pid=os.getpid(),start_ticks=int(pathlib.Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19]))),file=sys.stderr,flush=True)
def check():
 mono=time.monotonic()-c['host_monotonic_seconds'];wall=(datetime.datetime.now(datetime.timezone.utc)-datetime.datetime.fromisoformat(c['checked_utc'])).total_seconds();assert mono>=0 and abs(wall-mono)<=5 and max(mono,wall)+5<300
for path,expected in x['files'].items():
 check()
 p=pathlib.Path(path);h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1<<20),b''):check();h.update(block)
 actual=h.hexdigest();assert actual==expected,(path,expected,actual);result[path]=dict(sha256=actual,size_bytes=p.stat().st_size)
 check()
clock=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),host_monotonic_seconds=time.monotonic(),host_boot_id=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip())
check()
print(json.dumps(dict(files=result,clock=clock,elapsed_monotonic_seconds=clock['host_monotonic_seconds']-c['host_monotonic_seconds'])))
check()
'''

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--candidate',type=pathlib.Path);p.add_argument('--output',type=pathlib.Path);a=p.parse_args()
 if not a.execute:print(json.dumps(dict(status='description_only',pilot_launch=False)));return
 assert a.candidate and a.output and not a.output.exists();a.output.mkdir(parents=True)
 candidate=json.loads((a.candidate/'pilot_candidate.json').read_bytes());mapping=json.loads((a.candidate/'copy_mapping.json').read_bytes());inputs=json.loads((a.candidate/'complete_input_map.json').read_bytes())['files_sha256']
 assert candidate['initial_staging_utc'] is None and candidate['issued_by']!='root'
 expected_new={'goop2d_validation_cost_contract_v2.py','measure_goop2d_validation_cost_v2.py','supervise_goop2d_validation_cost_v2.py'}
 expected_reports={'summarize_goop2d_validation_cost_v1.py','collect_goop2d_validation_cost_scalars_v1.py'}
 new={k:v for k,v in candidate['sources'].items() if k in expected_new}
 assert set(new)==expected_new and set(candidate['reporting_sources'])==expected_reports
 files={}
 for name,row in {**new,**candidate['reporting_sources']}.items():
  assert row['path']==candidate['repo']+'/cuda_preparation/'+name and row['path'] not in files
  raw=(P/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256'];files[row['path']]=dict(base64=base64.b64encode(raw).decode(),sha256=row['sha256'])
 row=candidate['hardware_memory_evidence'];raw=(P/pathlib.Path(row['path']).name).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256'];files[row['path']]=dict(base64=base64.b64encode(raw).decode(),sha256=row['sha256'])
 transfers=[r for r in mapping['models'] if r['transfer_required_before_pilot']];assert len(transfers)==2 and {(r['arm'],r['seed']) for r in transfers}=={('base',0),('base',1)}
 assert len(mapping['models'])==6 and {(r['arm'],r['seed']) for r in mapping['models']}=={(m['arm'],m['seed']) for m in candidate['models']}
 for r in mapping['models']:
  m=next(m for m in candidate['models'] if (m['arm'],m['seed'])==(r['arm'],r['seed']))
  assert (r['actual_B_checkpoint_path'],r['checkpoint_sha256'],r['original_checkpoint_path'])==(m['checkpoint']['path'],m['checkpoint']['sha256'],m['original_checkpoint_path'])
  assert inputs[r['actual_B_checkpoint_path']]==r['checkpoint_sha256']
 assert len({r['actual_B_checkpoint_path'] for r in transfers})==2
 assert all(inputs[path]==v['sha256'] for path,v in files.items())
 dirs=sorted({str(pathlib.Path(r['actual_B_checkpoint_path']).parent) for r in transfers})
 assert len(dirs)==1 and all(pathlib.PurePosixPath(p).is_absolute() and '..' not in pathlib.PurePosixPath(p).parts for p in list(files)+dirs)
 assert not any(pathlib.PurePosixPath(d) in pathlib.PurePosixPath(p).parents for d in dirs for p in files)
 new_paths=list(files)+dirs+list(candidate['outputs'].values())
 assert len(new_paths)==len(set(new_paths))
 local_stage_origin=time.monotonic()
 remaining=lambda:295-(time.monotonic()-local_stage_origin)
 capture,before,after=runssh(CAPTURE,dict(new_paths=new_paths,hostname=candidate['hostname']),a.output,'initial_clock_native')
 c=capture['clock_origin'];remote=datetime.datetime.fromisoformat(c['checked_utc']);assert (after-before).total_seconds()<=5 and before-datetime.timedelta(seconds=5)<=remote<=after+datetime.timedelta(seconds=5)
 assert not capture['scientific_processes'] and not capture['gpu_apps'].strip() and all(capture['qualification_native_absent'].values()) and all(capture['destinations_unused'].values())
 expected={g['index']:(g['uuid'],g['name'],g['nvidia_smi_total_memory_mib']) for g in candidate['gpus']};observed={}
 for line in capture['gpus'].strip().splitlines():
  i,u,n,m=[s.strip() for s in line.split(',')];observed[int(i)]=(u,n,int(m))
 assert observed==expected
 candidate.update(initial_staging_utc=c['checked_utc'],absolute_stop_utc=(remote+datetime.timedelta(seconds=3600)).isoformat(),clock_origin=c)
 assert remote+datetime.timedelta(seconds=3600)<=datetime.datetime(2026,10,7,1,tzinfo=datetime.timezone.utc)
 dump(a.output/'local_monotonic_origin.json',dict(local_monotonic_seconds=local_stage_origin,local_before_utc=before.isoformat(),conservative_deadline_seconds=295))
 dump(a.output/'resolved_pilot_UNADMITTED.json',candidate)
 runssh(STAGE,dict(clock=c,hostname=candidate['hostname'],files=files,new_dirs=dirs),a.output,'source_staging',timeout=min(60,remaining()))
 for row in transfers:
  left=remaining();assert left>0
  cmd=['scp','-3','-F',str(P/'ssh_config'),A+':'+row['original_checkpoint_path'],B+':'+row['actual_B_checkpoint_path']]
  try:result=subprocess.run(cmd,text=True,capture_output=True,timeout=left)
  except subprocess.TimeoutExpired as e:
   name='transfer_base_seed%d'%row['seed'];txt=lambda v:v.decode(errors='replace') if isinstance(v,bytes) else v or ''
   (a.output/(name+'.stdout')).write_text(txt(e.stdout));(a.output/(name+'.stderr')).write_text(txt(e.stderr));dump(a.output/(name+'.json'),dict(status='local_transfer_timeout_remote_closure_required',original=row['original_checkpoint_path'],destination=row['actual_B_checkpoint_path'],no_retry=True));raise
  name='transfer_base_seed%d'%row['seed'];(a.output/(name+'.stdout')).write_text(result.stdout);(a.output/(name+'.stderr')).write_text(result.stderr)
  dump(a.output/(name+'.json'),dict(exit_code=result.returncode,original=row['original_checkpoint_path'],destination=row['actual_B_checkpoint_path'],expected_sha256=row['checkpoint_sha256']))
  assert result.returncode==0,'Opaque checkpoint transfer failed; no retry'
 verified,_,_=runssh(VERIFY,dict(clock=c,hostname=candidate['hostname'],files=inputs),a.output,'full_input_hashes',timeout=remaining())
 assert verified['elapsed_monotonic_seconds']+5<300
 assert remaining()>0
 dump(a.output/'staging_receipt.json',dict(status='staged_verified_pilot_unadmitted',clock_origin=c,absolute_stop_utc=candidate['absolute_stop_utc'],files=len(inputs),model_payloads_deserialized=False,pilot_launched=False))
 print(json.dumps(dict(status='staged_verified_pilot_unadmitted',output=str(a.output),elapsed=verified['elapsed_monotonic_seconds'],absolute_stop_utc=candidate['absolute_stop_utc'])))

if __name__=='__main__':main()
