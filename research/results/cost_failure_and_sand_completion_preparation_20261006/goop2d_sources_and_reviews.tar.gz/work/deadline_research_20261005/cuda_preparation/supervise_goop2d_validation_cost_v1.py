#!/usr/bin/env python3
"""Own one explicitly released Goop2D cost phase; description only by default.

Three fixed paired-seed GPU streams; six fresh child processes. Pilot completion
does not launch full work. Only root can issue the separate full phase release.
No numerical imports, shell commands, process-group signals or implicit retry.
"""
import time
ENTRY_MONOTONIC = time.monotonic()
import argparse
from datetime import timedelta
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys

sys.dont_write_bytecode = True
import goop2d_validation_cost_contract_v1 as C


class StopRequested(RuntimeError):
    pass


def native(pid):
    root = Path('/proc') / str(pid)
    try:
        fields = (root / 'stat').read_text().rsplit(') ', 1)[1].split()
        result = dict(pid=pid, ppid=int(fields[1]), start_ticks=int(fields[19]), state=fields[0])
    except (FileNotFoundError, ProcessLookupError):
        return None
    try:
        result['argv'] = [s.decode(errors='surrogateescape') for s in (root / 'cmdline').read_bytes().split(b'\0') if s]
    except (FileNotFoundError, ProcessLookupError):
        result['argv'] = []
    try:
        result['executable'] = os.readlink(root / 'exe')
    except (FileNotFoundError, ProcessLookupError):
        result['executable'] = None
    try:
        after = (root / 'stat').read_text().rsplit(') ', 1)[1].split()
    except (FileNotFoundError, ProcessLookupError):
        return None
    C.require(int(after[19]) == result['start_ticks'], 'PID changed during native inspection')
    return result


def stable(row):
    return {k: row[k] for k in ('pid', 'ppid', 'start_ticks', 'argv', 'executable')}


def process_inventory():
    result = []
    for p in Path('/proc').iterdir():
        if p.name.isdecimal():
            try:
                row = native(int(p.name))
            except PermissionError:
                continue
            if row is not None:
                result.append(row)
    return result


class Runtime:
    mono = staticmethod(time.monotonic)
    now = staticmethod(C.utc)
    sleep = staticmethod(time.sleep)
    identity = staticmethod(native)
    processes = staticmethod(process_inventory)
    boot_id = staticmethod(lambda: Path('/proc/sys/kernel/random/boot_id').read_text().strip())

    def gpu_rows(self):
        # Synchronous subprocess.run consumes/reaps the query before a process
        # inventory is read; no asynchronous pre-exec argv fork window.
        p = subprocess.run(['nvidia-smi', '--query-compute-apps=pid,gpu_uuid,used_memory',
                            '--format=csv,noheader,nounits'], capture_output=True, text=True, timeout=5, check=True)
        result = []
        for line in p.stdout.splitlines():
            if line.strip():
                pid, uuid, memory = [s.strip() for s in line.split(',')]
                result.append(dict(pid=int(pid), gpu_uuid=uuid, used_memory_mib=int(memory)))
        return result

    def gpu_inventory(self):
        p = subprocess.run(['nvidia-smi', '--query-gpu=index,uuid,name,memory.total',
                            '--format=csv,noheader,nounits'], capture_output=True, text=True, timeout=5, check=True)
        result = []
        for line in p.stdout.splitlines():
            index, uuid, name, memory = [s.strip() for s in line.split(',')]
            result.append(dict(index=int(index), uuid=uuid, name=name, total_memory_bytes=int(memory) * 1048576))
        return sorted(result, key=lambda r: r['index'])

    def launch(self, command, log, environment):
        env = os.environ.copy(); env.update(environment)
        # CUDA_VISIBLE_DEVICES would remap physical indices and compromise pairing.
        env.pop('CUDA_VISIBLE_DEVICES', None)
        return subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                env=env, start_new_session=True)

    def pidfd_open(self, pid):
        return os.pidfd_open(pid, 0)

    def signal_pidfd(self, fd, sig):
        signal.pidfd_send_signal(fd, sig, None, 0)

    def reap(self, child):
        if child.get('reaped'):
            return True
        pid, status, usage = os.wait4(child['process'].pid, os.WNOHANG)
        if not pid:
            return False
        C.require(pid == child['process'].pid, 'Reaped an unexpected child')
        child['process'].returncode = os.waitstatus_to_exitcode(status)
        child.update(reaped=True, exit_code=child['process'].returncode, reaped_utc=self.now().isoformat(),
                     reaped_monotonic=self.mono(), usage=dict(cpu_user_seconds=usage.ru_utime,
                     cpu_system_seconds=usage.ru_stime, linux_peak_rss_kib=usage.ru_maxrss))
        return True


class Budget:
    def __init__(self, release, rt):
        self.rt, self.release = rt, release
        self.origin, self.origin_utc = rt.mono(), rt.now()
        self.absolute = C.stamp(release['absolute_stop_utc'])
        # Monotonic remaining time is fixed at entry. A wall-clock correction
        # may shorten the run but cannot replenish the original allocation.
        clock = release['clock_origin']
        C.require(rt.boot_id() == clock['host_boot_id'], 'Host reboot/boot identity changed between phases')
        self.clock_error = clock['error_bound_seconds']
        self.staging_mono = clock['host_monotonic_seconds']
        elapsed_mono = self.origin - self.staging_mono
        elapsed_wall = (self.origin_utc - C.stamp(release['initial_staging_utc'])).total_seconds()
        C.require(elapsed_mono >= 0 and abs(elapsed_mono - elapsed_wall) <= self.clock_error,
                  'Original host monotonic/root wall clock evidence disagrees; no clock replenishment')
        self.overall_end = self.staging_mono + 3600 - self.clock_error
        self.phase_origin = None
        self.phase_end = None
        self.work_end = self.overall_end - 540
        if release['phase'] == 'pilot':
            self.work_end = min(self.work_end, self.staging_mono + 300 - self.clock_error)
        self.abort = None

    def start_phase(self, seconds):
        C.require(self.phase_origin is None, 'Phase clock cannot be reset')
        self.phase_origin = self.rt.mono()
        self.phase_end = min(self.phase_origin + seconds, self.overall_end - 450)
        self.work_end = min(self.overall_end - 540, self.phase_end - 90)

    def check(self):
        if self.abort:
            raise StopRequested(self.abort)
        if self.rt.mono() >= self.work_end or self.rt.now() >= self.absolute - timedelta(seconds=540):
            raise StopRequested('Original study/phase work stop reached; cleanup and analysis reserved')

    def stop_utc(self):
        return min(self.absolute - timedelta(seconds=540), self.rt.now() + timedelta(seconds=max(0, self.work_end - self.rt.mono())))

    def publication_check(self):
        end = min(self.overall_end - 450, self.phase_end if self.phase_end is not None else self.overall_end - 450)
        if self.rt.mono() >= end or self.rt.now() >= self.absolute - timedelta(seconds=450 + self.clock_error):
            raise StopRequested('Terminal publication reached reserved analysis boundary')


def capture_owned(child, rt):
    """Recover a failed initial capture only for the unreaped exact direct child."""
    C.require(child.get('registered') is True, 'Only registered Popen child capture allowed')
    if rt.reap(child):
        return False
    current = rt.identity(child['process'].pid)
    C.require(current is not None and current['state'] != 'Z' and current['ppid'] == child['owner_pid']
              and current['argv'] == child['command'] and current['executable'] == child['expected_executable'],
              'Cannot establish exact direct-child ownership for capture')
    C.require(child.get('identity') is None or stable(child['identity']) == stable(current), 'Captured child identity changed')
    child['identity'] = current
    if child.get('pidfd') is None:
        child['pidfd'] = rt.pidfd_open(child['process'].pid)
    after = rt.identity(child['process'].pid)
    C.require(after is not None and stable(after) == stable(current), 'Child identity changed while opening pidfd')
    return True


def inspect_host(release, children, rt, owner_pid):
    active = {c['process'].pid: c for c in children if not c.get('reaped')}
    gpu = rt.gpu_rows()
    for row in gpu:
        child = active.get(row['pid'])
        C.require(child is not None and row['gpu_uuid'] == child['gpu_uuid'], 'Foreign/wrong-device GPU activity; abort without touching it')
    # Query subprocess is fully reaped before this inventory is acquired.
    rows = rt.processes()
    for row in rows:
        if row['pid'] == owner_pid:
            continue
        child = active.get(row['pid'])
        if child is not None:
            if row['state'] != 'Z':
                C.require(stable(row) == stable(child['identity']), 'Live child identity changed')
            continue
        names = [Path(a).name for a in row['argv']]
        relevant = any(n.startswith(('train_', 'evaluate_', 'supervise_')) and n.endswith('.py')
                       or n in C.NEW_SOURCES for n in names)
        descendant = row['ppid'] in set(active) | {owner_pid}
        C.require(not relevant and not descendant, 'Foreign scientific process or unexpected descendant; abort without signaling it')
    return gpu


def owned_signal(child, sig, rt):
    C.require(child.get('registered') is True, 'Only an explicitly registered child may be signaled')
    if rt.reap(child):
        return False
    if child.get('pidfd') is None or child.get('identity') is None:
        if not capture_owned(child, rt):
            return False
    current = rt.identity(child['process'].pid)
    if current is None or current['state'] == 'Z':
        rt.reap(child); return False
    C.require(child.get('pidfd') is not None and child.get('identity') is not None
              and stable(current) == stable(child['identity']) and current['ppid'] == child['owner_pid']
              and current['argv'] == child['command'], 'Owned identity changed; refusing signal')
    rt.signal_pidfd(child['pidfd'], sig)
    child['signals'].append(dict(signal=signal.Signals(sig).name, utc=rt.now().isoformat(), identity=current))
    return True


def cleanup_owned(children, budget, rt):
    origin = rt.mono()
    cutoff = min(origin + 85, budget.overall_end - 455,
                 budget.phase_end - 5 if budget.phase_end is not None else budget.overall_end - 455)
    while rt.mono() < cutoff:
        pending = [c for c in children if not c.get('reaped')]
        if not pending:
            break
        for child in pending:
            try:
                if rt.reap(child):
                    continue
                sent = {r['signal'] for r in child['signals']}
                for delay, sig in ((0, signal.SIGINT), (20, signal.SIGTERM), (40, signal.SIGKILL)):
                    if rt.mono() >= origin + delay and signal.Signals(sig).name not in sent:
                        owned_signal(child, sig, rt); sent.add(signal.Signals(sig).name)
            except BaseException as error:
                child['cleanup_errors'].append(type(error).__name__ + ': ' + str(error))
        rt.sleep(.1)
    for child in children:
        try:
            rt.reap(child)
        except BaseException as error:
            child['cleanup_errors'].append('final reap: ' + str(error))


def public_child(child):
    return {k: v for k, v in child.items() if k not in ('process', 'log', 'pidfd')}


def verify_child(child, release, identity, rt, check=lambda: None):
    check()
    C.require(child.get('reaped') is True and child['exit_code'] == 0 and child['signals'] == [], 'Nonzero/signaled child cannot support capacity or cost result')
    C.require(rt.identity(child['process'].pid) is None, 'Reaped child still has native identity')
    path = Path(child['output']) / 'receipt.json'
    receipt = json.loads(path.read_bytes())
    expected_blocks = 15 if release['phase'] == 'pilot' else 150
    C.require(receipt.get('schema') == C.CHILD_SCHEMA and receipt.get('status') == 'complete'
              and receipt.get('phase') == release['phase'] and receipt.get('study_identity') == identity
              and (receipt.get('arm'), receipt.get('seed')) == (child['arm'], child['seed'])
              and receipt.get('gpu_uuid') == child['gpu_uuid'] and receipt.get('blocks') == expected_blocks
              and receipt.get('checkpoint_sha256') == child['checkpoint_sha256']
              and receipt.get('original_checkpoint_path') == child['original_checkpoint_path']
              and receipt.get('actual_checkpoint_path') == child['actual_checkpoint_path']
              and receipt.get('release_sha256') == child['release_sha256']
              and receipt.get('all_inputs_reverified') is True and receipt.get('all_memory_reference_hashes_equal') is True
              and receipt.get('all_headroom_checks_passed') is True and receipt.get('complete_forwards') == expected_blocks * 76,
              'Child receipt does not cover the full fixed model-state workload')
    times = receipt.get('publication_inclusive_block_seconds', [])
    C.require(len(times) == expected_blocks and all(C.finite(v, True) for v in times)
              and receipt['maximum_publication_inclusive_block_seconds'] == max(times), 'Measured block durations incomplete')
    C.require(receipt.get('schedule') == child['schedule'], 'Child schedule differs from frozen validation descriptors')
    committed = receipt.get('committed', [])
    C.require(len(committed) == expected_blocks and [r['schedule_index'] for r in committed] == [s['schedule_index'] for s in child['schedule']], 'Committed schedule coverage differs')
    verification_times = []
    for row, item in zip(committed, child['schedule']):
        check()
        verification_start = rt.mono()
        C.require(row['path'] == 'state_%03d.json' % row['schedule_index'], 'Unexpected child product path')
        raw = Path(child['output']) / row['path']
        C.require(C.sha(raw, check) == row['sha256'], 'Committed child scalar changed')
        result = json.loads(raw.read_bytes())
        C.scalar_block(result, item, child['seed'])
        artifact = raw.with_suffix('.npz')
        C.require(result.get('artifact_file') == artifact.name and C.sha(artifact, check) == result.get('artifact_sha256'), 'Numeric reference artifact changed')
        verification_times.append(rt.mono() - verification_start)
    # Include process startup/exit, verification and final publication overhead
    # in the capacity setup/finalization allowances, never omit it from W.
    child_wall = rt.mono() - child['launched_monotonic']
    measured = receipt['setup_seconds'] + sum(times) + receipt['finalization_seconds']
    C.require(all(C.finite(receipt[k]) for k in ('setup_seconds', 'finalization_seconds')) and child_wall >= sum(times), 'Impossible child wall accounting')
    receipt = dict(receipt, finalization_seconds=receipt['finalization_seconds'] + max(0, child_wall - measured - sum(verification_times)),
                   raw_receipt_finalization_seconds=receipt['finalization_seconds'], observed_child_wall_seconds=child_wall,
                   owner_verification_block_seconds=verification_times,
                   maximum_owner_verification_block_seconds=max(verification_times))
    child.update(receipt=receipt, receipt_path=str(path), receipt_sha256=C.sha(path, check), verified=True)


def child_command(release, release_path, arm, seed, stop):
    return [release['python']['lexical_path'], release['sources']['measure_goop2d_validation_cost_v1.py']['path'],
            '--execute', '--release', str(release_path), '--arm', arm, '--seed', str(seed), '--work-stop-utc', stop]


def launch_child(release, release_path, arm, seed, schedule, budget, rt, children, identity):
    budget.check()
    output = Path(release['outputs'][release['phase']]) / ('seed%d_%s' % (seed, arm))
    output.mkdir(mode=0o700, exist_ok=False)
    command = child_command(release, release_path, arm, seed, budget.stop_utc().isoformat())
    model = next(m for m in release['models'] if (m['arm'], m['seed']) == (arm, seed))
    child = dict(arm=arm, seed=seed, command=command, output=str(output), owner_pid=os.getpid(),
        gpu_uuid=release['streams'][seed]['gpu_uuid'], checkpoint_sha256=model['checkpoint']['sha256'],
        original_checkpoint_path=model['original_checkpoint_path'], actual_checkpoint_path=model['checkpoint']['path'],
        expected_executable=release['python']['resolved_path'],
        release_sha256=C.sha(release_path, budget.check), schedule=schedule, signals=[], cleanup_errors=[],
        reaped=False, registered=False, identity=None, pidfd=None, verified=False)
    child['log'] = (output.parent / ('seed%d_%s.log' % (seed, arm))).open('xb')
    child['launched_monotonic'] = rt.mono(); child['launched_utc'] = rt.now().isoformat()
    try:
        child['process'] = rt.launch(command, child['log'], C.ENV)
    except BaseException:
        child['log'].close(); raise
    # Ownership is recorded immediately after Popen returns, before any check
    # can raise. Cleanup can see every successfully created process.
    children.append(child); child['registered'] = True
    child['pid'] = child['process'].pid
    C.require(capture_owned(child, rt), 'Child exited before launch identity capture completed')
    C.write(output.parent / 'children.json', [public_child(c) for c in children], budget.check)
    return child


def execute(release, release_path, rt=None):
    rt = rt or Runtime()
    phase = release['phase']
    identity = C.validate_release(release, phase, now=rt.now(), verify=False)
    C.require(socket.gethostname() == release['hostname'], 'Dedicated B hostname differs')
    C.require(sys.executable == release['python']['lexical_path'] and str(Path(sys.executable).resolve()) == release['python']['resolved_path'], 'Owner interpreter differs')
    output = Path(release['outputs'][phase]); output.mkdir(mode=0o700, exist_ok=False)
    budget = Budget(release, rt)
    children, failure, final_gpu, gate = [], None, None, None
    last_watch = [rt.mono()]
    def monitored_check():
        budget.check()
        if rt.mono() - last_watch[0] >= 2:
            for owned in children:
                if rt.reap(owned):
                    C.require(owned['exit_code'] == 0, 'Owned peer failed during artifact verification')
            inspect_host(release, children, rt, os.getpid())
            last_watch[0] = rt.mono()
        budget.check()
    sources = {v['path']: v['sha256'] for v in list(release['sources'].values()) + list(release['controls'].values())}
    sources.update({m['checkpoint']['path']: m['checkpoint']['sha256'] for m in release['models']})
    sources[str(release_path)] = C.sha(release_path)
    C.write(output / 'owner_started.json', dict(schema=C.OWNER_SCHEMA, phase=phase, study_identity=identity,
        release_sha256=C.sha(release_path), owner_pid=os.getpid(), owner_identity=rt.identity(os.getpid()),
        started_utc=rt.now().isoformat(), initial_staging_utc=release['initial_staging_utc'], absolute_stop_utc=release['absolute_stop_utc']))
    old_handlers = {}
    for sig in (signal.SIGINT, signal.SIGTERM):
        old_handlers[sig] = signal.getsignal(sig)
        signal.signal(sig, lambda number, frame: setattr(budget, 'abort', signal.Signals(number).name))
    try:
        C.validate_release(release, phase, now=rt.now(), verify=True, check=budget.check)
        C.require(rt.gpu_inventory() == sorted(release['gpus'], key=lambda g: g['index']), 'Physical GPU inventory changed')
        inspect_host(release, children, rt, os.getpid())
        budget.check()
        if phase == 'pilot':
            C.require((rt.now() - C.stamp(release['initial_staging_utc'])).total_seconds() <= 300,
                      'Initial staging/transfer/preflight exceeded original 300-second allowance')
            budget.start_phase(600)
        else:
            pilot = C.read_bound(release['pilot_receipt'], budget.check)
            closure = C.read_bound(release['pilot_external_closure'], budget.check)
            # Read scalar and hash referenced bytes only; never deserializes a
            # model or numeric artifact. Root closure binds the original run.
            for child in pilot['children']:
                raw = C.read_bound(dict(path=child['receipt_path'], sha256=child['receipt_sha256']), budget.check)
                augmented = child['receipt']
                C.require(all(augmented.get(k) == v for k, v in raw.items() if k != 'finalization_seconds')
                    and augmented.get('raw_receipt_finalization_seconds') == raw['finalization_seconds']
                    and C.finite(augmented.get('finalization_seconds'))
                    and augmented['finalization_seconds'] >= raw['finalization_seconds'], 'Pilot capacity receipt differs from original child bytes')
            gate = C.capacity_gate(release, pilot, closure, now=rt.now())
            C.write(output / 'capacity_gate.json', gate)
            budget.start_phase(gate['work_seconds'] + 90)
        manifest = C.read_bound(release['controls']['manifest'], budget.check)
        C.require(manifest.get('split') == 'valid' and manifest.get('dataset') == 'Goop', 'Validation only')
        expected = C.schedule(manifest['records'], phase)
        active = {}
        for seed in range(3):
            active[seed] = launch_child(release, release_path, C.ARMS[seed][0], seed, expected, budget, rt, children, identity)
        while active:
            budget.check()
            for seed, child in list(active.items()):
                if rt.reap(child):
                    verify_child(child, release, identity, rt, monitored_check)
                    # The first process is gone and verified before the second
                    # arm enters the same physical GPU/process allocator.
                    del active[seed]
                    if child['arm'] == C.ARMS[seed][0]:
                        inspect_host(release, children, rt, os.getpid())
                        active[seed] = launch_child(release, release_path, C.ARMS[seed][1], seed, expected, budget, rt, children, identity)
                    C.write(output / 'children.json', [public_child(c) for c in children], monitored_check)
            inspect_host(release, children, rt, os.getpid())
            rt.sleep(.25)
        C.verify_files(sources, monitored_check)
        final_gpu = inspect_host(release, children, rt, os.getpid())
        C.require(final_gpu == [] and len(children) == 6 and all(c.get('verified') for c in children), 'Complete clean six-model phase required')
    except BaseException as error:
        failure = dict(error_type=type(error).__name__, error=str(error), utc=rt.now().isoformat())
    finally:
        cleanup_owned(children, budget, rt)
        try:
            final_gpu = rt.gpu_rows()
        except BaseException as error:
            failure = failure or dict(error_type=type(error).__name__, error=str(error))
        for sig, handler in old_handlers.items():
            signal.signal(sig, handler)
        for child in children:
            child['log'].close()
            if child.get('pidfd') is not None:
                os.close(child['pidfd'])
    phase_seconds = rt.mono() - (budget.phase_origin if budget.phase_origin is not None else budget.origin)
    complete = (failure is None and len(children) == 6 and all(c.get('verified') and c.get('reaped') and not c['signals'] for c in children)
                and final_gpu == [] and budget.phase_end is not None and rt.mono() < budget.phase_end)
    if not complete and failure is None:
        failure = dict(error_type='IncompleteBoundedPhase', error='Complete verified six-model phase and terminal publication window not established')
    receipt = dict(schema=C.OWNER_SCHEMA, status='complete' if complete else 'failed', phase=phase,
        study_identity=identity, release_sha256=sources[str(release_path)], owner_pid=os.getpid(),
        initial_staging_utc=release['initial_staging_utc'], absolute_stop_utc=release['absolute_stop_utc'],
        clock_origin=release['clock_origin'], phase_started_monotonic=budget.phase_origin,
        completed_monotonic=rt.mono(),
        phase_started_utc=(budget.origin_utc + timedelta(seconds=(budget.phase_origin or budget.origin) - budget.origin)).isoformat(),
        whole_phase_seconds=phase_seconds, elapsed_since_initial_staging_seconds=(rt.now() - C.stamp(release['initial_staging_utc'])).total_seconds(),
        completed_utc=rt.now().isoformat(), children=[public_child(c) for c in children], failure=failure,
        observed_complete_blocks=sum(c.get('receipt', {}).get('blocks', 0) for c in children),
        all_children_reaped=all(c.get('reaped') for c in children), final_gpu_processes=final_gpu,
        capacity_gate=gate, full_launch_authorized_by_pilot=False, no_retry_or_subset_authorized=True)
    return publish_owner_receipt(output, receipt, budget)


def publish_owner_receipt(output, receipt, budget):
    try:
        C.write(output / 'owner_receipt_candidate.json', receipt, budget.publication_check)
        C.write(output / 'owner_receipt.json', receipt, budget.publication_check)
        budget.publication_check()
        return 0 if receipt['status'] == 'complete' else 1
    except BaseException as error:
        # A zero original owner exit is required by the external closure gate.
        # Preserve the candidate and make any late publication explicitly fail.
        failed = dict(receipt, status='failed', failure=dict(error_type=type(error).__name__, error=str(error)),
                      terminal_publication_verified_within_bound=False)
        path = output / 'owner_publication_failed.json'
        C.write(path, failed)
        if not (output / 'owner_receipt.json.tmp').exists():
            C.write(output / 'owner_receipt.json', failed)
        return 1


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    p.add_argument('--execute', action='store_true'); p.add_argument('--release', type=Path)
    args = p.parse_args(argv)
    if not args.execute:
        print(json.dumps(dict(status='description_only', execution=False, workload=C.WORKLOAD, limits=C.LIMITS,
                             separate_root_full_release_required=True), indent=2)); return 0
    C.require(args.release is not None, 'Explicit root phase release path required')
    path = args.release.resolve()
    return execute(json.loads(path.read_bytes()), path)


if __name__ == '__main__':
    raise SystemExit(main())
