#!/usr/bin/env python3
"""Independently audit locally prepared candidate JSON, without remote or payload reads."""
import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def require(test, message):
    if not test:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def document(path):
    return json.loads(path.read_text())


def resolve_pointer(value, pointer):
    require(pointer.startswith('/'), 'Expected nonempty JSON pointer')
    for segment in pointer[1:].split('/'):
        segment = segment.replace('~1', '/').replace('~0', '~')
        value = value[int(segment)] if isinstance(value, list) else value[segment]
    return value


def audit(directory):
    directory = directory.resolve()
    require(directory.parent == HERE, 'Only a local preparation candidate may be read')
    construction = document(directory / 'construction.json')
    require(construction['authority'] is None and construction['clock_started'] is False,
            'Candidate cannot issue authority or start clock')
    for key in ('payloads_read', 'remote_calls', 'staging_performed', 'launch_performed'):
        require(construction[key] is False, 'Candidate construction work scope changed')
    artifacts = {}
    for name, digest in construction['output_sha256'].items():
        require(Path(name).name == name, 'Candidate artifact must be a basename')
        require(sha(directory / name) == digest, 'Candidate artifact hash differs: ' + name)
        if name.endswith('.json'):
            artifacts[name.removesuffix('.json')] = document(directory / name)
    inputs = {}
    inherited = document(HERE / 'goop2d_validation_cost_candidate_UNADMITTED_owner_v1' / 'construction.json')
    all_metadata = dict(inherited['input_metadata_sha256'], **construction['input_metadata_sha256'])
    for name, digest in all_metadata.items():
        require(not Path(name).is_absolute() and '..' not in Path(name).parts and name.endswith('.json') and (HERE / name).resolve().is_relative_to(HERE), 'Only local metadata JSON is readable')
        require(sha(HERE / name) == digest, 'Input metadata pin differs: ' + name)
        inputs[name] = document(HERE / name)
    mapping = artifacts['complete_input_map']['files_sha256']
    provenance = artifacts['provenance_bindings']
    require(provenance['input_metadata_sha256'] == all_metadata,
            'Provenance inputs differ from construction')
    bindings = provenance['bindings']
    require(len(bindings) == len(mapping) == len({b['path'] for b in bindings}), 'Duplicate or missing bindings')
    role_counts = {}
    pointer_checks = 0
    for binding in bindings:
        path, digest = binding['path'], binding['sha256']
        require(mapping[path] == digest, 'Binding/input map disagree')
        require(Path(path).is_absolute(), 'Input path must be absolute')
        require(not any(part in ('test', 'train') for part in Path(path).parts), 'Test/training data path in validation input map')
        require(binding['metadata_evidence'], 'Input has no metadata evidence')
        for role in binding['roles']:
            role_counts[role] = role_counts.get(role, 0) + 1
        for evidence in binding['metadata_evidence']:
            name = evidence['metadata_file']
            require(evidence['metadata_sha256'] == all_metadata[name], 'Evidence metadata hash differs')
            observed = resolve_pointer(inputs[name], evidence['json_pointer'])
            if isinstance(observed, dict):
                observed = observed['sha256']
            require(observed == digest, 'JSON pointer does not reach bound hash')
            pointer_checks += 1
    require({b['path']: b['sha256'] for b in bindings} == mapping, 'Bindings do not exactly cover input map')
    counts = artifacts['complete_input_map']['counts']
    require(counts == construction['counts'] == provenance['counts'], 'Candidate counts disagree')
    comparisons = {
        'entry_or_new_sources': 'entry_or_new_source',
        'frozen_numerical_helpers': 'frozen_numerical_helper',
        'preserved_context_sources': 'preserved_context_source',
        'validation_position_arrays': 'validation_position_array',
        'validation_type_arrays': 'validation_type_array',
        'preserved_validation_step_context_arrays': 'validation_step_context_array',
        'actual_model_checkpoints': 'actual_model_checkpoint',
        'reporting_source_paths': 'reporting_source',
        'hardware_memory_qualification_paths': 'hardware_memory_qualification',
    }
    for count, role in comparisons.items():
        require(counts[count] == role_counts.get(role, 0), 'Claimed role count differs: ' + count)
    require(counts['controls'] == sum(n for r, n in role_counts.items() if r.startswith('control_')), 'Control count differs')
    require(counts['interpreter_and_venv_paths'] == sum(n for r, n in role_counts.items() if r.startswith('python_')), 'Python count differs')
    require(counts['total_distinct_input_paths'] == len(mapping), 'Distinct path count differs')
    require(counts['test_input_paths'] == counts['training_array_paths'] == 0, 'Unsupported data scope')
    pilot, full = artifacts['pilot_candidate'], artifacts['full_candidate']
    for candidate in (pilot, full):
        require(candidate['issued_by'] is None and candidate['initial_staging_utc'] is None and candidate['absolute_stop_utc'] is None, 'Authority/clock set')
        require(all(v is None for v in candidate['clock_origin'].values()), 'Clock origin set')
        for row in list(candidate['sources'].values()) + list(candidate['controls'].values()) + list(candidate['reporting_sources'].values()) + [candidate['hardware_memory_evidence']]:
            require(mapping[row['path']] == row['sha256'], 'Source/control not bound by input map')
    require(full['full_admission_utc'] is None and full['pilot_receipt']['sha256'] is None and full['pilot_external_closure']['sha256'] is None, 'Future evidence or authority fabricated')
    require(pilot['phase'] == 'pilot' and full['phase'] == 'full', 'Phase mapping differs')
    for key in pilot.keys() & full.keys() - {'phase'}:
        require(pilot[key] == full[key], 'Pilot/full common study field differs: ' + key)
    pairs = {(arm, seed) for arm in ('base', 'mix') for seed in range(3)}
    require(len(pilot['models']) == 6 and {(x['arm'], x['seed']) for x in pilot['models']} == pairs, 'Six-model cohort differs')
    copied = artifacts['copy_mapping']
    require(len(copied['models']) == 6 and {(x['arm'], x['seed']) for x in copied['models']} == pairs, 'Copy map identity grid differs')
    originals = copied['original_lineage_file_sha256']
    require(len(originals) == len(set(originals.values())) == 6, 'Original endpoints not six distinct pins')
    copied_by_pair = {(x['arm'], x['seed']): x for x in copied['models']}
    transfer_pairs = set()
    for row in pilot['models']:
        pair = (row['arm'], row['seed'])
        item = copied_by_pair[pair]
        original, actual, digest = row['original_checkpoint_path'], row['checkpoint']['path'], row['checkpoint']['sha256']
        require(item['original_checkpoint_path'] == original and item['actual_B_checkpoint_path'] == actual and item['checkpoint_sha256'] == digest, 'Model/copy mapping differs')
        require(originals[original] == mapping[actual] == digest, 'Original/actual hashes differ')
        require(item['fresh_local_byte_verification_required'] is True and item['current_payload_opened'] is False, 'Payload verification scope changed')
        if item['transfer_required_before_pilot']:
            transfer_pairs.add(pair)
        if row['seed'] < 2:
            require(original not in mapping and actual != original, 'Original A lineage mistaken for local B input')
        else:
            require(actual == original, 'Original B endpoint path changed')
    require(transfer_pairs == {('base', 0), ('base', 1)}, 'Prospective checkpoint transfer grid differs')
    workload = pilot['workload']
    expected = dict(endpoints=6, updates=100000, split='valid', trajectories=30,
        targets=[7, 105, 203, 301, 400], histories_per_model=150, full_blocks=900,
        pilot_blocks=90, timed_rounds=7, warmup_rounds=1, full_forwards=68400,
        pilot_forwards=6840, forwards_per_complete_block=76, accuracy_results_published=False,
        target_diagnostics_computed_by_frozen_same_state=True, pilot_in_final_estimates=False,
        policies=['base', 'dense', 'random25', 'speed25', 'relative-velocity-RMS25', 'previous-observed-base-risk25'],
        timing_reference='natural_base_reference')
    for key, value in expected.items():
        require(workload[key] == value, 'Frozen workload differs: ' + key)
    require(pilot['limits'] == dict(cleanup_seconds=90, collection_analysis_seconds=450,
        forecast_multiplier=1.35, handoff_seconds=60, pilot_seconds=600,
        staging_preflight_seconds=300, whole_seconds=3600), 'Clock quotas differ')
    prior_dir = HERE / 'goop2d_validation_cost_candidate_UNADMITTED_owner_v1'
    require(construction['preserved_prior_construction_sha256'] == sha(prior_dir / 'construction.json'), 'Prior candidate lineage differs')
    prior_map = document(prior_dir / 'complete_input_map.json')['files_sha256']
    prior_pilot = document(prior_dir / 'pilot_candidate.json')
    expected_map = dict(prior_map)
    for name in ('goop2d_validation_cost_contract', 'measure_goop2d_validation_cost', 'supervise_goop2d_validation_cost'):
        expected_map.pop(pilot['repo'] + '/cuda_preparation/' + name + '_v1.py')
        row = pilot['sources'][name + '_v2.py']
        expected_map[row['path']] = row['sha256']
    for row in list(pilot['reporting_sources'].values()) + [pilot['hardware_memory_evidence']]:
        expected_map[row['path']] = row['sha256']
    require(mapping == expected_map and len(mapping) == 137, 'V2 map has changes beyond three new-version sources, two reporting sources, one hardware receipt')
    for field in ('models', 'workload', 'limits', 'environment', 'streams', 'controls', 'python'):
        require(pilot[field] == prior_pilot[field], 'Original scientific/runtime/mapping field changed: ' + field)
    require(sha(directory / 'copy_mapping.json') == sha(prior_dir / 'copy_mapping.json'), 'Original endpoint/copy lineage bytes changed')
    require(pilot['outputs'] == {phase: pilot['repo'] + '/goop2d_validation_cost_' + phase + '_20261006_v2' for phase in ('pilot', 'full')}, 'Fresh v2 output trees differ')
    hardware = inputs['goop2d_memory_context_interface_153302_root_v1.json']
    require(hardware['host'] == pilot['hostname'] and hardware['models_data_or_benchmark_loaded'] is False, 'Hardware qualification host/scope changed')
    for gpu in pilot['gpus']:
        observed = next(row for row in hardware['devices'] if row['index'] == gpu['index'])
        require(gpu['uuid'].removeprefix('GPU-') == observed['nvidia_uuid'].removeprefix('GPU-') == observed['cuda_uuid'].removeprefix('GPU-'), 'Physical UUID binding changed')
        require(gpu['cuda_mem_get_info_total_bytes'] == observed['cuda_mem_get_info_total_bytes'] == 197897617408, 'Exact CUDA context pin differs')
        require(gpu['nvidia_smi_total_memory_mib'] == observed['nvidia_total_integer_mib'] == 189471, 'Exact NVIDIA integer-MiB pin differs')
        require(set(gpu) == {'index', 'uuid', 'name', 'cuda_mem_get_info_total_bytes', 'nvidia_smi_total_memory_mib'}, 'Cross-API alias or extra field remains in GPU row')
    require(artifacts['external_closure_candidate']['issued_by'] is None, 'External closure authority cannot be invented')
    require(not pilot['preparation_notes'].get('device_memory_equivalence_requires_current_scalar_evidence'), 'Obsolete cross-API equivalence note remains')
    return dict(status='passed_local_v2_metadata_preparation_review_only', candidate_directory=str(directory),
        construction_sha256=sha(directory / 'construction.json'),
        candidate_output_hash_checks=len(construction['output_sha256']),
        input_metadata_hash_checks=len(inputs), provenance_sha_pointer_checks=pointer_checks,
        complete_input_paths=len(mapping), actual_role_counts=role_counts,
        original_distinct_endpoints=6, complete_validation_trajectory_arrays=90,
        grid_and_clock_preserved=True, authority_and_clock_unset=True,
        no_remote_calls_or_checkpoint_or_array_reads=True, execution_admission=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = audit(args.candidate)
    text = json.dumps(result, sort_keys=True, indent=2, allow_nan=False) + '\n'
    if args.output:
        with args.output.open('x') as stream:
            stream.write(text)
    print(text, end='')


if __name__ == '__main__':
    main()
