#!/usr/bin/env python3
"""CPU synthetic contract tests; no NumPy, torch, model, data or OS child."""
import ast
import copy
from datetime import datetime, timedelta, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import signal
import sys
import tempfile
from types import SimpleNamespace
import unittest

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import goop2d_validation_cost_contract_v3 as C
import measure_goop2d_validation_cost_v3 as M
import supervise_goop2d_validation_cost_v3 as O


def records():
    return [dict(id='trajectory-%d' % i, source_index=i, positions={'shape': [401, 100 + ((i * 7) % 30), 2]}) for i in range(30)]


def release():
    base = Path('/tmp/goop2d_synthetic_root').resolve()
    controls = {k: {'path': str(base / 'inputs' / (k + '.json')), 'sha256': 'a' * 64} for k in C.CONTROL_NAMES}
    return dict(schema=C.SCHEMA, status='admitted_pilot', phase='pilot', issued_by='root', study_id='synthetic',
        **{key: {'path': str(base / relative), 'sha256': pin} for key, (relative, pin) in C.AMENDMENT_BINDINGS.items()},
        repo=str(base), hostname='synthetic-host', initial_staging_utc='2026-10-06T20:00:00+00:00',
        absolute_stop_utc='2026-10-06T21:00:00+00:00', workload=copy.deepcopy(C.WORKLOAD), limits=copy.deepcopy(C.LIMITS), environment=C.ENV.copy(),
        clock_origin=dict(host_monotonic_seconds=0,host_boot_id='synthetic-boot',checked_utc='2026-10-06T20:00:00+00:00',error_bound_seconds=0),
        python=dict(lexical_path='/usr/bin/python3', resolved_path='/usr/bin/python3', sha256='b' * 64,
                    venv_config={'path': str(base / 'venv' / 'pyvenv.cfg'), 'sha256': 'c' * 64}),
        hardware_memory_evidence={'path':str(base/'hardware'/'context.json'),'sha256':C.HARDWARE_MEMORY_SHA},
        reporting_sources={name:{'path':str(base/'cuda_preparation'/name),'sha256':'e'*64} for name in C.REPORTING_SOURCES},
        controls=controls, sources={name: dict(path=str(base / 'cuda_preparation' / name), sha256=C.FROZEN.get(name, 'f' * 64)) for name in (*C.FROZEN, *C.NEW_SOURCES)},
        models=[dict(arm=a, seed=s, original_checkpoint_path=str(base / 'original' / ('%s%d.pt' % (a,s))), checkpoint=dict(path=str(base / 'models' / ('%s%d.pt' % (a,s))), sha256=hashlib.sha256(('%s%d' % (a,s)).encode()).hexdigest())) for a in ('base','mix') for s in range(3)],
        gpus=[dict(index=s, uuid='GPU-%d' % s, name='NVIDIA GB200', nvidia_smi_total_memory_mib=1000,cuda_mem_get_info_total_bytes=1000000000) for s in range(4)],
        streams=[dict(seed=s, gpu_index=s, gpu_uuid='GPU-%d' % s, arms=list(C.ARMS[s])) for s in range(3)],
        outputs=dict(pilot=str(base / 'pilot'), full=str(base / 'full')))


def pilot(r):
    identity = C.study_identity(r)
    children=[]
    for m in r['models']:
        receipt=dict(schema=C.CHILD_SCHEMA, status='complete', phase='pilot', arm=m['arm'], seed=m['seed'],
                     study_identity=identity, checkpoint_sha256=m['checkpoint']['sha256'], gpu_uuid='GPU-%d' % m['seed'],
                     blocks=15, all_inputs_reverified=True, all_memory_reference_hashes_equal=True,
                     all_headroom_checks_passed=True, complete_forwards=1140, setup_seconds=1,
                     maximum_publication_inclusive_block_seconds=1, finalization_seconds=1,
                     owner_verification_block_seconds=[0]*15, maximum_owner_verification_block_seconds=0)
        children.append(dict(arm=m['arm'], seed=m['seed'], exit_code=0, reaped=True, signals=[], receipt=receipt))
    return dict(schema=C.OWNER_SCHEMA, status='complete', phase='pilot', study_identity=identity, all_children_reaped=True,
                final_gpu_processes=[], failure=None, observed_complete_blocks=90, whole_phase_seconds=200,
                clock_origin=r['clock_origin'], phase_started_monotonic=40,completed_monotonic=240,
                completed_utc='2026-10-06T20:04:00+00:00', phase_started_utc='2026-10-06T20:00:40+00:00', children=children)


def closure():
    return dict(schema='adaptgns_goop2d_validation_cost_external_closure_v3', issued_by='root',
                status='original_session_exit_and_native_absence_verified', pilot_receipt_sha256='d' * 64,
                original_session_exit_code=0, owner_native_absent=True, all_children_native_absent=True,
                gpu_processes=[], checked_utc='2026-10-06T20:04:01+00:00',host_boot_id='synthetic-boot',checked_host_monotonic_seconds=241)


class FakeArray:
    dtype = SimpleNamespace(hasobject=False)
    def __init__(self, value): self.value=value


class AuditVector(list):
    def __eq__(self, other):
        return [a == b for a, b in zip(self, other)] if isinstance(other, list) else [a == other for a in self]
    def __gt__(self, other): return [a > other for a in self]
    def max(self): return max(self)


class AuditEdges:
    def __init__(self, rows): self.rows=rows; self.shape=(len(rows), len(rows[0]))
    def __getitem__(self, key):
        if isinstance(key, tuple): return AuditEdges([row[key[1]] for row in self.rows[key[0]]])
        return AuditVector(self.rows[key])


def graph_fixture(method, seconds):
    if method != C.POLICIES[4]: return {'method':method}
    path=HERE/'sand_graph_support_policy.py'
    assert C.sha(path)==C.FROZEN[path.name]
    function=next(n for n in ast.parse(path.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='physical_graph')
    assign=next(n for n in function.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='audit' for t in n.targets))
    update=next(n for n in function.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call)
                and isinstance(n.value.func,ast.Attribute) and isinstance(n.value.func.value,ast.Name)
                and n.value.func.value.id=='audit' and n.value.func.attr=='update')
    score=next(n for n in function.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='score_seconds' for t in n.targets))
    assert ast.unparse(score.value)=='time.perf_counter() - score_started'
    assert next(k.value for k in update.value.keywords if k.arg=='physical_score_seconds').id=='score_seconds'
    native=AuditEdges([[0,1,0],[0,1,1]]); edges=AuditEdges([[0,1,0,1,2],[0,1,1,2,1]])
    def exact(a,b): return a.rows==b.rows
    def state_hash(value): return hashlib.sha256(repr(value.rows if isinstance(value,AuditEdges) else value).encode()).hexdigest()
    context=dict(graph=SimpleNamespace(base=[(0,1)],extra=[(0,2),(1,2),(0,3),(1,3)]),
        optional=[(1,2)],edges=edges,native_base=native,uncapped_base=native,
        degree=AuditVector([1,2,0]),native_degree=AuditVector([1,2,0]),asymmetric=1,
        np=SimpleNamespace(sum=sum,array_equal=exact),full=SimpleNamespace(state_hash=state_hash),
        PHYSICAL_POLICY=method,scores=[0.1,0.2,0.0],counts=AuditVector([1,1,0]),score_seconds=seconds,dt=.0025)
    # Execute the two actual pinned descriptor statements, not a copied schema.
    exec(compile(ast.Module(body=[assign,update],type_ignores=[]),str(path),'exec'),context)
    return context['audit']


def array_hash(value):
    return hashlib.sha256(str(value.value).encode()).hexdigest()


def policy_arrays(method):
    keys=['edges','prediction','risk','raw_risk','selected_optional_pairs','base_pairs']
    if method == C.POLICIES[-1]:
        keys += ['previous_base_edges','previous_base_prediction','previous_base_risk','previous_base_raw_risk','annulus_pairs']
    elif method != C.CASES[-1]:
        keys += ['annulus_pairs']
    if method == C.POLICIES[4]: keys += ['physical_selection_scores']
    return {k: FakeArray(method + '-' + k) for k in keys}


class FakeCuda:
    def __init__(self): self.events=[]; self.peak=300
    def synchronize(self, device): self.events.append('sync')
    def memory_allocated(self, device): self.events.append('allocated'); return 100
    def memory_reserved(self, device): self.events.append('reserved'); return 400
    def mem_get_info(self, device): self.events.append('free'); return 500,1000
    def reset_peak_memory_stats(self, device): self.events.append('reset')
    def max_memory_allocated(self, device): self.events.append('peak_allocated'); return self.peak
    def max_memory_reserved(self, device): self.events.append('peak_reserved'); return 400


class FakeEvaluator:
    def __init__(self, cuda): self.cuda=cuda; self.calls=[]; self.bad=None; self.network_passes=0
    def timing_order(self, source, schedule, round_index):
        offset=(source*5+schedule+round_index)%7
        return C.CASES[offset:]+C.CASES[:offset]
    def run_policy(self, native, model, current, previous, types, method, material, device):
        self.cuda.events.append('run'); self.calls.append((method,current,previous,types,material)); self.network_passes += 2 if method==C.POLICIES[-1] else 1
        saved=policy_arrays(method)
        if self.bad == method: saved['risk']=FakeArray('changed-risk')
        return dict(status='complete', failure=None, graph=graph_fixture(method, 2.0)), saved


def memory_fixture():
    cuda=FakeCuda(); evaluator=FakeEvaluator(cuda)
    arrays={k:FakeArray(k) for k in ('current_history','previous_history','particle_types')}
    for method in C.CASES:
        arrays.update({'r1_'+method+'__'+k:v for k,v in policy_arrays(method).items()})
    row=dict(source_index=2,schedule_index=14,random_seed_material=[20261006,93000,1,0,2,400],policies={m:{'graph':graph_fixture(m, 1.0)} for m in C.CASES})
    native=SimpleNamespace(full=SimpleNamespace(state_hash=array_hash),np=SimpleNamespace(ndarray=FakeArray))
    return cuda,evaluator,arrays,row,native


def scalar_fixture(item, seed=0):
    cuda,evaluator,arrays,row,native=memory_fixture()
    row.update(item)
    row['random_seed_material']=[20261006,93000,seed,0,item['source_index'],item['target_frame']]
    memory=M.memory_pass(evaluator,native,SimpleNamespace(cuda=cuda),None,arrays,row,'fake-device',{'cuda_mem_get_info_total_bytes':1000,'nvidia_smi_total_memory_mib':1})
    result=dict(item,status='complete',failure=None,complete_forwards=76,memory=memory,random_seed_material=row['random_seed_material'],
                native_parity={'current':{'passed':True},'previous':{'passed':True}},
                natural_shared_base={'ordered_edges_exact':True,'outputs_within_fixed_parity_tolerance':True},
                policies={m:dict(status='complete',repeat_consistent=True,completed_repetitions=7,
                                expected_repetitions=7,graph=graph_fixture(m, 1.0)) for m in C.CASES},
                array_value_sha256={k:array_hash(v) for k,v in arrays.items()})
    for field,rounds in [('warmup_calls',[-1]),('timed_calls',list(range(7)))]:
        result[field]=[dict(method=method,round=repetition,slot=slot,status='complete',failure=None,
                           timing=dict(end_to_end_seconds=1,network_passes=2 if method==C.POLICIES[-1] else 1,
                               score_generation_seconds=0,score_graph_seconds=0,score_forward_seconds=0,
                               current_graph_and_selection_seconds=0,current_forward_seconds=1),
                           **({'repeat_consistency':dict(ordered_edges_exact=True,outputs_within_fixed_parity_tolerance=True,
                               **({'previous_score_ordered_edges_exact':True,'previous_score_outputs_within_fixed_parity_tolerance':True} if method==C.POLICIES[-1] else {}),
                               **({'physical_scores_exact':True} if method==C.POLICIES[4] else {}))} if repetition>=1 else {}))
                       for repetition in rounds for slot,method in enumerate(evaluator.timing_order(item['source_index'],item['schedule_index'],max(0,repetition)))]
    return result


class Clock:
    def __init__(self, seconds=0): self.seconds=seconds; self.wall_shift=0
    def mono(self): return self.seconds
    def now(self): return datetime(2026,10,6,20,tzinfo=timezone.utc)+timedelta(seconds=self.seconds+self.wall_shift)
    def sleep(self, seconds): self.seconds += seconds
    def boot_id(self): return 'synthetic-boot'


class CostTests(unittest.TestCase):
    def test_actual_physical_descriptor_all_fields_and_timing_retained(self):
        first=graph_fixture(C.POLICIES[4],1.0); memory=graph_fixture(C.POLICIES[4],2.0)
        self.assertEqual({k for k in first if first[k]!=memory[k]},{'physical_score_seconds'})
        self.assertEqual(len(first),23)
        before=copy.deepcopy((first,memory))
        self.assertTrue(C.graph_audits_equal(C.POLICIES[4],first,memory))
        self.assertEqual((first,memory),before)
        cuda,evaluator,arrays,row,native=memory_fixture()
        measured=M.memory_pass(evaluator,native,SimpleNamespace(cuda=cuda),None,arrays,row,'fake-device',{'cuda_mem_get_info_total_bytes':1000,'nvidia_smi_total_memory_mib':1})
        self.assertEqual(row['policies'][C.POLICIES[4]]['graph'],first)
        self.assertEqual(next(x['graph'] for x in measured if x['method']==C.POLICIES[4]),memory)
        item=C.schedule(records(),'pilot')[0];scalar=scalar_fixture(item)
        self.assertTrue(C.scalar_block(scalar,item,0,{'cuda_mem_get_info_total_bytes':1000,'nvidia_smi_total_memory_mib':1}))
        self.assertEqual(scalar['policies'][C.POLICIES[4]]['graph']['physical_score_seconds'],1.0)
        self.assertEqual(next(x for x in scalar['memory'] if x['method']==C.POLICIES[4])['graph']['physical_score_seconds'],2.0)

    def test_actual_descriptor_every_nonvolatile_field_is_strict_at_both_guards(self):
        graph=graph_fixture(C.POLICIES[4],2.0)
        mutations=[]
        for key,value in graph.items():
            if key=='physical_score_seconds': continue
            changed=not value if isinstance(value,bool) else value+1 if isinstance(value,(int,float)) else value+'changed'
            mutations.append(lambda g,k=key,v=changed:g.update({k:v}))
        mutations += [lambda g:g.update(unknown_field=1),lambda g:g.pop('physical_score_sha256')]
        for mutate in mutations:
            with self.subTest(mutation=mutate):
                cuda,evaluator,arrays,row,native=memory_fixture(); original=evaluator.run_policy
                def tampered(*args):
                    result,saved=original(*args)
                    if args[5]==C.POLICIES[4]: mutate(result['graph'])
                    return result,saved
                evaluator.run_policy=tampered
                with self.assertRaises(ValueError): M.memory_pass(evaluator,native,SimpleNamespace(cuda=cuda),None,arrays,row,'fake-device',{'cuda_mem_get_info_total_bytes':1000,'nvidia_smi_total_memory_mib':1})
                item=C.schedule(records(),'pilot')[0];scalar=scalar_fixture(item)
                mutate(next(x for x in scalar['memory'] if x['method']==C.POLICIES[4])['graph'])
                with self.assertRaises(ValueError): C.scalar_block(scalar,item,0,{'cuda_mem_get_info_total_bytes':1000,'nvidia_smi_total_memory_mib':1})

    def test_physical_timing_invalid_on_either_side_and_nonphysical_no_exception(self):
        for value in (-1,float('nan'),float('inf'),True,None,'1'):
            for side in (0,1):
                pair=[graph_fixture(C.POLICIES[4],1),graph_fixture(C.POLICIES[4],2)];pair[side]['physical_score_seconds']=value
                with self.assertRaises(ValueError):C.graph_audits_equal(C.POLICIES[4],*pair)
        for side in (0,1):
            pair=[graph_fixture(C.POLICIES[4],1),graph_fixture(C.POLICIES[4],2)];pair[side].pop('physical_score_seconds')
            with self.assertRaises(ValueError):C.graph_audits_equal(C.POLICIES[4],*pair)
        pair=[graph_fixture(C.POLICIES[4],0),graph_fixture(C.POLICIES[4],2)]
        self.assertTrue(C.graph_audits_equal(C.POLICIES[4],*pair))
        for method in C.CASES:
            if method!=C.POLICIES[4]:self.assertFalse(C.graph_audits_equal(method,*pair))

    def test_v2_preserved_and_v3_entry_extension_spends_original_clock(self):
        pins={'goop2d_validation_cost_contract_v2.py':'42488d713fca7aebc1ee6bb2e6f22271c2323d14ffa0bb7a1341a0afd16e5ad0',
              'measure_goop2d_validation_cost_v2.py':'73c1225635e80d296a2e6158dd6610df458669509cde96f4ebf46fc907139652',
              'supervise_goop2d_validation_cost_v2.py':'f72022e92003c5f24451a678dbd18c460a0566a5e6759d489fd0ca732e678f79'}
        for name,pin in pins.items():self.assertEqual(C.sha(HERE/name),pin)
        r=release();r['clock_origin']['error_bound_seconds']=5;rt=Clock(894);budget=O.Budget(r,rt)
        self.assertEqual(budget.work_end,895);self.assertEqual(budget.overall_end,3595)
        budget.check();rt.seconds=895
        with self.assertRaises(O.StopRequested):budget.check()
        identity=C.study_identity(r);r['instrumentation_amendment']['sha256']='0'*64
        self.assertNotEqual(identity,C.study_identity(r))
        with self.assertRaises(ValueError):C.validate_release(r,'pilot',now=C.stamp(r['initial_staging_utc']),verify=False)

    def test_no_numerical_imports_or_execution_during_tests(self):
        self.assertNotIn('torch',sys.modules); self.assertNotIn('numpy',sys.modules); self.assertNotIn('scipy',sys.modules)

    def test_default_description_does_not_read_release(self):
        from contextlib import redirect_stdout
        import io
        with redirect_stdout(io.StringIO()):
            self.assertEqual(M.main([]),0); self.assertEqual(O.main([]),0)

    def test_complete_original_schedule_and_pilot_indices(self):
        full=C.schedule(records(),'full'); small=C.schedule(records(),'pilot')
        self.assertEqual(len(full),150); self.assertEqual(len(small),15)
        self.assertEqual([r['schedule_index'] for r in full],list(range(150)))
        ranked=sorted(range(30),key=lambda i:(records()[i]['positions']['shape'][1],i))
        self.assertEqual({r['source_index'] for r in small},{ranked[0],ranked[14],ranked[29]})
        self.assertTrue(all(r==full[r['schedule_index']] for r in small))

    def test_pilot_ties_and_invalid_descriptor_fail_closed(self):
        rows=records()
        for r in rows:r['positions']['shape'][1]=100
        self.assertEqual({r['source_index'] for r in C.schedule(rows,'pilot')},{0,14,29})
        for field,value in [('source_index',4),('id',rows[1]['id'])]:
            bad=copy.deepcopy(rows);bad[0][field]=value
            with self.assertRaises(ValueError):C.schedule(bad,'full')

    def test_root_release_and_full_cohort_cannot_shrink(self):
        r=release();self.assertEqual(C.validate_release(r,'pilot',now=C.stamp(r['initial_staging_utc']),verify=False),C.study_identity(r))
        mutations=[lambda x:x.update(status='candidate'),lambda x:x['models'].pop(),
                   lambda x:x['workload'].update(timed_rounds=3),lambda x:x['streams'][1].update(arms=['base','mix']),
                   lambda x:x['sources']['evaluate_goop_graph_support_final.py'].update(sha256='0'*64),
                   lambda x:x['outputs'].update(full=x['outputs']['pilot'])]
        for mutate in mutations:
            bad=copy.deepcopy(r);mutate(bad)
            with self.assertRaises(ValueError):C.validate_release(bad,'pilot',now=C.stamp(r['initial_staging_utc']),verify=False)

    def test_forecast_counts_both_arms_all_seeds_and_reserves(self):
        r=release();r['pilot_receipt']={'path':'/tmp/pilot.json','sha256':'d'*64};p=pilot(r)
        f=C.capacity_gate(r,p,closure(),now=C.stamp('2026-10-06T20:05:00+00:00'))
        self.assertEqual(f['work_seconds'],409);self.assertEqual(f['required_whole_seconds'],1309)
        with self.assertRaises(ValueError):C.capacity_gate(r,p,closure(),now=C.stamp('2026-10-06T20:50:00+00:00'))
        rows=[copy.deepcopy(c['receipt']) for c in p['children']]
        for row in rows:row.update(owner_verification_block_seconds=[.2]*15, maximum_owner_verification_block_seconds=.2)
        self.assertAlmostEqual(C.forecast(rows)['work_seconds'],652)
        for index,row in enumerate(rows):
            rate=(index+1)*.1;row.update(owner_verification_block_seconds=[rate]*15,maximum_owner_verification_block_seconds=rate)
        self.assertAlmostEqual(C.forecast(rows)['work_seconds'],834.25)

    def test_pilot_failure_or_identity_change_blocks_full(self):
        r=release();r['pilot_receipt']={'path':'/tmp/pilot.json','sha256':'d'*64};p=pilot(r);now=C.stamp('2026-10-06T20:05:00+00:00')
        changes=[lambda x:x['children'].pop(),lambda x:x['children'][0].update(exit_code=-2),
                 lambda x:x['children'][0]['receipt'].update(all_headroom_checks_passed=False),
                 lambda x:x['children'][0]['receipt'].update(gpu_uuid='GPU-foreign'),
                 lambda x:x.update(whole_phase_seconds=601),lambda x:x.update(observed_complete_blocks=89)]
        for change in changes:
            bad=copy.deepcopy(p);change(bad)
            with self.assertRaises(ValueError):C.capacity_gate(r,bad,closure(),now=now)
        bad=closure();bad['original_session_exit_code']=1
        with self.assertRaises(ValueError):C.capacity_gate(r,p,bad,now=now)
        r['clock_origin']['error_bound_seconds']=5;p=pilot(r);bad=closure()
        p.update(phase_started_monotonic=0,phase_started_utc=r['initial_staging_utc'])
        bad.update(checked_utc='2026-10-06T20:09:59+00:00',checked_host_monotonic_seconds=601)
        with self.assertRaises(ValueError):C.capacity_gate(r,p,bad,now=C.stamp('2026-10-06T20:10:00+00:00'))

    def test_exact_memory_graph_output_hashes_and_measurement_order(self):
        cuda,evaluator,arrays,row,native=memory_fixture()
        result=M.memory_pass(evaluator,native,SimpleNamespace(cuda=cuda),None,arrays,row,'fake-device',{'cuda_mem_get_info_total_bytes':1000,'nvidia_smi_total_memory_mib':1})
        self.assertEqual(len(result),7);self.assertEqual(evaluator.network_passes,8)
        self.assertTrue(all(r['peak_allocated_bytes']==300 and r['incremental_allocated_bytes']==200 for r in result))
        self.assertEqual(cuda.events[:12],['sync','allocated','reserved','free','reset','run','sync','peak_allocated','peak_reserved','allocated','reserved','free'])
        self.assertEqual([x[0] for x in evaluator.calls],list(evaluator.timing_order(2,14,0)))
        self.assertTrue(all(x[1] is arrays['current_history'] and x[2] is arrays['previous_history'] for x in evaluator.calls))

    def test_memory_hash_change_or_headroom_failure_stops(self):
        cuda,evaluator,arrays,row,native=memory_fixture();evaluator.bad=C.POLICIES[-1]
        with self.assertRaisesRegex(ValueError,'hashes differ'):M.memory_pass(evaluator,native,SimpleNamespace(cuda=cuda),None,arrays,row,'fake-device',{'cuda_mem_get_info_total_bytes':1000,'nvidia_smi_total_memory_mib':1})
        cuda,evaluator,arrays,row,native=memory_fixture();cuda.peak=950
        with self.assertRaises(ValueError):M.memory_pass(evaluator,native,SimpleNamespace(cuda=cuda),None,arrays,row,'fake-device',{'cuda_mem_get_info_total_bytes':1000,'nvidia_smi_total_memory_mib':1})

    def test_no_accuracy_estimates_in_cost_export(self):
        keys=('schedule_index','source_index','trajectory_id','target_frame','status','failure','random_seed_material','risk_source','warmup_calls','timed_calls','native_parity','natural_shared_base','parity_and_setup_seconds','total_wall_seconds_including_warmup_parity_audits')
        row={k:None for k in keys};row['policies']={m:{k:None for k in ('status','repeat_consistent','completed_repetitions','expected_repetitions','timing','graph','metrics')} for m in C.CASES}
        row.update(benefit={'secret':1},correlations={'secret':2},truth_boundary={})
        out=M.cost_row(row)
        self.assertNotIn('benefit',out);self.assertNotIn('correlations',out);self.assertTrue(all('metrics' not in x for x in out['policies'].values()))

    def test_independent_owner_scalar_grid_rejects_tampering(self):
        item=C.schedule(records(),'pilot')[0];row=scalar_fixture(item)
        self.assertTrue(C.scalar_block(row,item,0,{'cuda_mem_get_info_total_bytes':1000,'nvidia_smi_total_memory_mib':1}))
        changes=[lambda x:x['memory'].pop(),lambda x:x['timed_calls'].pop(),lambda x:x['warmup_calls'][0].update(slot=5),
                 lambda x:x['memory'][0].update(incremental_allocated_bytes=10),
                 lambda x:x['memory'][0]['array_value_sha256'].update(prediction='f'*64),
                 lambda x:x['policies']['dense'].update(completed_repetitions=6),
                 lambda x:x['timed_calls'][7].update(repeat_consistency={}),
                 lambda x:x['timed_calls'][0]['timing'].pop('score_graph_seconds'),
                 lambda x:x.update(random_seed_material=[20261006,93000,2,0,item['source_index'],item['target_frame']]),
                 lambda x:x['native_parity']['previous'].update(passed=False)]
        for change in changes:
            bad=copy.deepcopy(row);change(bad)
            with self.assertRaises(ValueError):C.scalar_block(bad,item,0,{'cuda_mem_get_info_total_bytes':1000,'nvidia_smi_total_memory_mib':1})

    def test_real_file_binding_rejects_mutation_and_preserves_atomic_output(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'input.json';C.write(path,{'synthetic':True})
            b={'path':str(path.resolve()),'sha256':C.sha(path)}
            self.assertEqual(C.read_bound(b),{'synthetic':True})
            path.write_text('{}')
            with self.assertRaises(ValueError):C.read_bound(b)

    def test_budget_no_reset_no_clock_rollback_credit(self):
        r=release();rt=Clock(890);b=O.Budget(r,rt);rt.seconds=900
        with self.assertRaises(O.StopRequested):b.check()
        rt=Clock(200);b=O.Budget(r,rt);b.start_phase(600)
        with self.assertRaises(ValueError):b.start_phase(600)
        rt.seconds=710;rt.wall_shift=-200
        with self.assertRaises(O.StopRequested):b.check()

    def test_cross_phase_rollback_and_reboot_rejected(self):
        r=release();r.update(phase='full',status='admitted_full')
        rt=Clock(1000);rt.wall_shift=-100
        with self.assertRaises(ValueError):O.Budget(r,rt)
        rt=Clock(1000);rt.boot_id=lambda:'different-boot'
        with self.assertRaises(ValueError):O.Budget(r,rt)
        rt=Clock(1000);r['clock_origin']['error_bound_seconds']=5
        b=O.Budget(r,rt);self.assertEqual(b.overall_end,3595)

    def test_capture_failure_keeps_pid_and_can_recover_only_same_child(self):
        identity=dict(pid=10,ppid=1,start_ticks=100,argv=['python','child.py'],executable='/python',state='R')
        child=dict(pid=10,process=SimpleNamespace(pid=10),registered=True,owner_pid=1,command=identity['argv'],
                   expected_executable='/python',pidfd=None,identity=None,signals=[])
        attempts=[];events=[]
        def open_fd(pid):
            attempts.append(pid)
            if len(attempts)==1:raise OSError('synthetic initial pidfd failure')
            return 22
        rt=SimpleNamespace(reap=lambda c:False,identity=lambda p:identity,pidfd_open=open_fd,
                           signal_pidfd=lambda fd,sig:events.append((fd,sig)),now=C.utc)
        with self.assertRaises(OSError):O.capture_owned(child,rt)
        self.assertEqual(O.public_child(child)['pid'],10)
        self.assertTrue(O.owned_signal(child,signal.SIGINT,rt));self.assertEqual(events,[(22,signal.SIGINT)])
        child['pidfd']=None;rt.identity=lambda p:dict(identity,start_ticks=999)
        with self.assertRaises(ValueError):O.capture_owned(child,rt)
        self.assertEqual(events,[(22,signal.SIGINT)])

    def test_delayed_publication_fails_and_preserves_candidate(self):
        from unittest.mock import patch
        with tempfile.TemporaryDirectory() as d:
            rt=Clock(10);b=O.Budget(release(),rt);b.start_phase(100)
            real_write=C.write
            def delayed(path,value,check=lambda:None):
                if Path(path).name=='owner_receipt.json':rt.seconds=111
                return real_write(path,value,check)
            with patch.object(C,'write',side_effect=delayed):
                code=O.publish_owner_receipt(Path(d),{'status':'complete'},b)
            self.assertEqual(code,1)
            self.assertTrue((Path(d)/'owner_receipt_candidate.json').is_file())
            self.assertEqual(json.loads((Path(d)/'owner_publication_failed.json').read_text())['status'],'failed')

    def test_owned_signal_rejects_reused_identity_and_foreign_gpu(self):
        identity=dict(pid=10,ppid=1,start_ticks=100,argv=['python','child.py'],executable='/python',state='R')
        child=dict(registered=True,identity=identity,pidfd=5,owner_pid=1,command=identity['argv'],process=SimpleNamespace(pid=10),signals=[])
        events=[];rt=SimpleNamespace(reap=lambda c:False,identity=lambda p:dict(identity,start_ticks=101),signal_pidfd=lambda fd,sig:events.append(sig),now=C.utc)
        with self.assertRaises(ValueError):O.owned_signal(child,signal.SIGINT,rt)
        self.assertEqual(events,[])
        rt=SimpleNamespace(gpu_rows=lambda:[dict(pid=99,gpu_uuid='GPU-0')],processes=lambda:[])
        with self.assertRaises(ValueError):O.inspect_host(release(),[],rt,1)

    def test_owned_signal_never_signals_reaped_child(self):
        events=[];child=dict(registered=True)
        rt=SimpleNamespace(reap=lambda c:True,signal_pidfd=lambda fd,sig:events.append(sig))
        self.assertFalse(O.owned_signal(child,signal.SIGKILL,rt));self.assertEqual(events,[])

    def test_foreign_peer_and_descendant_are_rejected(self):
        for row in [dict(pid=99,ppid=50,argv=['python','evaluate_other.py'],state='R'),dict(pid=98,ppid=1,argv=['helper'],state='R')]:
            rt=SimpleNamespace(gpu_rows=lambda:[],processes=lambda:[row])
            with self.assertRaises(ValueError):O.inspect_host(release(),[],rt,1)

    def test_source_uses_frozen_entry_calls_without_monkeypatch(self):
        tree=ast.parse((HERE/'measure_goop2d_validation_cost_v3.py').read_text())
        calls=[n.func.attr for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='evaluator']
        self.assertEqual(calls.count('same_state'),1);self.assertEqual(calls.count('run_policy'),1)
        for node in ast.walk(tree):
            if isinstance(node,(ast.Assign,ast.AnnAssign)):
                targets=node.targets if isinstance(node,ast.Assign) else [node.target]
                self.assertFalse(any(isinstance(t,ast.Attribute) and isinstance(t.value,ast.Name) and t.value.id=='evaluator' for t in targets))

    def test_frozen_source_bytes_unchanged(self):
        for name,pin in C.FROZEN.items(): self.assertEqual(C.sha(HERE/name),pin)

    def test_exact_context_and_nvidia_pins_need_no_cross_api_equality(self):
        cuda,evaluator,arrays,row,native=memory_fixture()
        total=197897617408
        cuda.mem_get_info=lambda device:(total-1000,total)
        expected={'cuda_mem_get_info_total_bytes':total,'nvidia_smi_total_memory_mib':189471}
        result=M.memory_pass(evaluator,native,SimpleNamespace(cuda=cuda),None,arrays,row,'fake-device',expected)
        self.assertTrue(all(m['device_total_bytes']==total and m['nvidia_smi_total_memory_mib']==189471 for m in result))
        self.assertNotEqual(total,189471*1048576)
        for wrong in (total-1,total+1,189471*1048576):
            with self.assertRaisesRegex(ValueError,'Exact CUDA context total'):
                M.memory_pass(evaluator,native,SimpleNamespace(cuda=cuda),None,arrays,row,'fake-device',dict(expected,cuda_mem_get_info_total_bytes=wrong))

    def test_scalar_context_denominator_and_native_metadata_are_both_bound(self):
        item=C.schedule(records(),'pilot')[0];row=scalar_fixture(item)
        self.assertTrue(C.scalar_block(row,item,0,{'cuda_mem_get_info_total_bytes':1000,'nvidia_smi_total_memory_mib':1}))
        for expected in ({'cuda_mem_get_info_total_bytes':2000,'nvidia_smi_total_memory_mib':1},
                         {'cuda_mem_get_info_total_bytes':1000,'nvidia_smi_total_memory_mib':2}):
            with self.assertRaises(ValueError):C.scalar_block(row,item,0,expected)

    def test_hardware_evidence_binds_uuid_boot_and_exact_api(self):
        r=release()
        evidence=dict(host=r['hostname'],boot_id='synthetic-boot',torch='2.13.0+cu129',cuda='12.9',pre_gpu_apps='',
                      models_data_or_benchmark_loaded=False,devices=[dict(index=g['index'],nvidia_uuid=g['uuid'],
                          cuda_uuid=C.gpu_uuid(g['uuid']),name=g['name'],nvidia_total_integer_mib=g['nvidia_smi_total_memory_mib'],
                          cuda_mem_get_info_total_bytes=g['cuda_mem_get_info_total_bytes'],cuda_device_properties_total_bytes=123)
                          for g in r['gpus']])
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'synthetic_metadata.json';C.write(path,evidence)
            r['hardware_memory_evidence']={'path':str(path.resolve()),'sha256':C.sha(path)}
            # Properties may differ; the context API remains independently exact.
            self.assertEqual(C.verify_hardware_memory(r),evidence)
            for change in (lambda x:x.update(boot_id='other-boot'),
                           lambda x:x['devices'][0].update(cuda_uuid='other-uuid'),
                           lambda x:x['devices'][0].update(cuda_mem_get_info_total_bytes=1000000001),
                           lambda x:x['devices'][0].update(nvidia_total_integer_mib=1001)):
                bad=copy.deepcopy(evidence);change(bad);C.write(path,bad)
                r['hardware_memory_evidence']['sha256']=C.sha(path)
                with self.assertRaises(ValueError):C.verify_hardware_memory(r)

    def test_reporting_sources_are_exact_and_in_study_fingerprint(self):
        r=release();original=C.study_identity(r)
        r['reporting_sources']['summarize_goop2d_validation_cost_v1.py']['sha256']='d'*64
        self.assertNotEqual(C.study_identity(r),original)
        r['reporting_sources'].pop('collect_goop2d_validation_cost_scalars_v1.py')
        with self.assertRaises(ValueError):C.validate_release(r,'pilot',now=C.stamp(r['initial_staging_utc']),verify=False)

    def test_v1_preserved_and_workload_lifecycle_ast_unchanged(self):
        expected={'goop2d_validation_cost_contract_v1.py':'119a18dcffe1e9730d5f248fa4a4cbe27fcdda5649a99e73bc117ea5e2eb1be6',
                  'measure_goop2d_validation_cost_v1.py':'69a9f87234e671821263ddff961f0f89b37abff43eb0e0a72e15f655df25a2b3',
                  'supervise_goop2d_validation_cost_v1.py':'58facf99bf4b9b3c7ec60e4b5b4fb597ef5768fcae9f5653346f2cf7d721d03f'}
        for name,pin in expected.items():self.assertEqual(C.sha(HERE/name),pin)
        import goop2d_validation_cost_contract_v1 as old
        self.assertEqual(C.WORKLOAD,old.WORKLOAD);self.assertEqual(C.LIMITS,dict(old.LIMITS,staging_preflight_seconds=900));self.assertEqual(C.ENV,old.ENV)
        def functions(path):
            return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(path.read_text()).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
        before=functions(HERE/'supervise_goop2d_validation_cost_v1.py');after=functions(HERE/'supervise_goop2d_validation_cost_v3.py')
        for name in ('capture_owned','owned_signal','cleanup_owned','publish_owner_receipt','child_command','launch_child'):
            self.assertEqual(before[name].replace('measure_goop2d_validation_cost_v1.py','measure_goop2d_validation_cost_v3.py'),after[name])


if __name__=='__main__':unittest.main(verbosity=2)
