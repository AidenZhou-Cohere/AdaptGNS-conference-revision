#!/usr/bin/env python3
"""Separate validation-only cost/memory adapter; description only by default.

The frozen same_state and run_policy functions are called without monkeypatches.
Numerical imports and input access occur only after explicit root phase gates.
"""
import time
ENTRY_MONOTONIC = time.monotonic()
import argparse
import json
import os
from pathlib import Path
import resource
import signal
import socket
import sys
from types import SimpleNamespace

sys.dont_write_bytecode = True
import goop2d_validation_cost_contract_v1 as C


def check_complete_timing(row, evaluator):
    C.require(row.get('status') == 'complete' and row.get('failure') is None
              and set(row.get('policies', {})) == set(C.CASES), 'Every frozen policy must complete')
    C.require(set(row.get('native_parity', {})) == {'current', 'previous'}
              and all(p.get('passed') is True for p in row['native_parity'].values()), 'Both native parity checks required')
    natural = row.get('natural_shared_base', {})
    C.require(natural.get('ordered_edges_exact') is True and natural.get('outputs_within_fixed_parity_tolerance') is True,
              'Natural/shared base parity required')
    for field, rounds in (('warmup_calls', [-1]), ('timed_calls', list(range(7)))):
        calls = row[field]
        C.require(len(calls) == len(rounds) * 7, 'No missing/extra warmup or timed call')
        for j, repetition in enumerate(rounds):
            order = evaluator.timing_order(row['source_index'], row['schedule_index'], max(0, repetition))
            for slot, method in enumerate(order):
                call = calls[j * 7 + slot]
                C.require((call['method'], call['round'], call['slot']) == (method, repetition, slot)
                          and call['status'] == 'complete' and call.get('failure') is None,
                          'Frozen cyclic order/call status changed')
                C.require(all(v is True for v in call.get('repeat_consistency', {}).values()), 'Frozen repeat parity failed')
                for name, value in call['timing'].items():
                    C.require(C.finite(value), 'Invalid measured call timing: ' + name)
    C.require(all(p['status'] == 'complete' and p['repeat_consistent'] is True
                  and p['completed_repetitions'] == p['expected_repetitions'] == 7 for p in row['policies'].values()),
              'All original repeats must be successful')


def reference_hashes(arrays, method, state_hash):
    prefix = 'r1_' + method + '__'
    found = {key[len(prefix):]: state_hash(value) for key, value in arrays.items() if key.startswith(prefix)}
    C.require({'edges', 'prediction', 'risk', 'raw_risk', 'selected_optional_pairs'} <= set(found), 'Missing first timed reference arrays')
    return found


def memory_pass(evaluator, native, torch, model, arrays, row, device, total_bytes):
    results = []
    order = evaluator.timing_order(row['source_index'], row['schedule_index'], 0)
    for slot, method in enumerate(order):
        reference = reference_hashes(arrays, method, native.full.state_hash)
        torch.cuda.synchronize(device)
        baseline_allocated = torch.cuda.memory_allocated(device)
        baseline_reserved = torch.cuda.memory_reserved(device)
        free_before, device_total = torch.cuda.mem_get_info(device)
        # nvidia-smi reports integer MiB; CUDA reports exact available bytes.
        C.require(total_bytes <= device_total < total_bytes + 1048576, 'Physical GPU memory identity differs')
        torch.cuda.reset_peak_memory_stats(device)
        result, saved = evaluator.run_policy(native, model, arrays['current_history'], arrays['previous_history'],
            arrays['particle_types'], method, row['random_seed_material'], device)
        torch.cuda.synchronize(device)
        peak_allocated = torch.cuda.max_memory_allocated(device)
        peak_reserved = torch.cuda.max_memory_reserved(device)
        after_allocated = torch.cuda.memory_allocated(device)
        after_reserved = torch.cuda.memory_reserved(device)
        free_after, after_total = torch.cuda.mem_get_info(device)
        C.require(after_total == device_total and result.get('status') == 'complete' and result.get('failure') is None,
                  'Memory pass failed; no reduced workload allowed')
        C.require(all(isinstance(value, native.np.ndarray) and not value.dtype.hasobject for value in saved.values()),
                  'Memory pass may retain only numeric CPU arrays')
        observed = {key: native.full.state_hash(value) for key, value in saved.items()}
        C.require(observed == reference, 'Memory-pass graph/selection/output hashes differ from frozen first timed call')
        C.require(result.get('graph') == row['policies'][method]['graph'], 'Memory-pass graph audit differs')
        C.require(all(type(v) is int and v >= 0 for v in (baseline_allocated, baseline_reserved, peak_allocated,
            peak_reserved, after_allocated, after_reserved, free_before, free_after))
            and baseline_allocated <= peak_allocated <= peak_reserved and baseline_reserved <= peak_reserved,
            'Invalid allocator observations')
        C.require(max(peak_allocated, peak_reserved) <= int(device_total * .90), 'Memory headroom gate failed')
        results.append(dict(method=method, slot=slot, status='complete', reference_hashes_equal=True,
            graph=result['graph'], array_value_sha256=observed, baseline_allocated_bytes=baseline_allocated,
            baseline_reserved_bytes=baseline_reserved, peak_allocated_bytes=peak_allocated,
            incremental_allocated_bytes=peak_allocated - baseline_allocated, peak_reserved_bytes=peak_reserved,
            after_allocated_bytes=after_allocated, after_reserved_bytes=after_reserved,
            device_free_before_bytes=free_before, device_free_after_bytes=free_after,
            device_total_bytes=device_total, headroom_passed=True,
            reserved_memory_interpretation='warm allocator/process observation; not isolated policy-owned memory'))
        # bridge.supplied returns CPU arrays; no live returned CUDA tensor can
        # cross this boundary. No cache clearing, telemetry or serialization is
        # inserted into the frozen latency call.
        del saved, observed, reference, result
    return results


def cost_row(row):
    # same_state computes its original target diagnostics after inference. This
    # supplement does not publish those accuracy estimates or tune any policy.
    keys = ('schedule_index', 'source_index', 'trajectory_id', 'target_frame', 'status', 'failure',
            'random_seed_material', 'risk_source', 'warmup_calls', 'timed_calls', 'native_parity',
            'natural_shared_base', 'parity_and_setup_seconds', 'total_wall_seconds_including_warmup_parity_audits')
    result = {k: row[k] for k in keys}
    result['policies'] = {method: {k: p[k] for k in ('status', 'repeat_consistent', 'completed_repetitions',
                          'expected_repetitions', 'timing', 'graph')} for method, p in row['policies'].items()}
    return result


def reference_arrays(arrays):
    return {key: value for key, value in arrays.items() if key in ('current_history', 'previous_history', 'particle_types')
            or key.startswith('r1_') or '_parity_' in key}


def execute(args, release):
    phase = release['phase']
    identity = C.validate_release(release, phase)
    if phase == 'full':
        # Root's admission is fixed once; re-checking the entire full forecast
        # after the first arm would incorrectly demand a second allocation.
        # The owner additionally checks the gate at actual full phase entry.
        C.capacity_gate(release, C.read_bound(release['pilot_receipt']), C.read_bound(release['pilot_external_closure']),
                        now=C.stamp(release['full_admission_utc']))
    C.require(socket.gethostname() == release['hostname'] and args.seed in range(3) and args.arm in C.ARMS[args.seed], 'Host/model identity differs')
    C.require(all(os.environ.get(k) == value for k, value in C.ENV.items()), 'Environment differs before numerical import')
    work_stop = C.stamp(args.work_stop_utc)
    C.require(C.utc() < work_stop <= C.stamp(release['absolute_stop_utc']) - C.timedelta(seconds=540), 'Child work stop cannot consume cleanup/analysis reserve')
    controls = {key: Path(value['path']) for key, value in release['controls'].items()}
    source = {key: Path(value['path']) for key, value in release['sources'].items()}
    selected = next(m for m in release['models'] if (m['arm'], m['seed']) == (args.arm, args.seed))
    output = Path(release['outputs'][phase]) / ('seed%d_%s' % (args.seed, args.arm))
    C.require(output.is_dir() and list(output.iterdir()) == [], 'Owner must provide exact fresh empty child directory')
    inputs = {v['path']: v['sha256'] for v in list(release['controls'].values()) + list(release['sources'].values())}
    inputs[selected['checkpoint']['path']] = selected['checkpoint']['sha256']
    inputs[str(args.release.resolve())] = C.sha(args.release)
    evaluator = C.load_source(source['evaluate_goop_graph_support_final.py'], C.FROZEN['evaluate_goop_graph_support_final.py'], '_cost_frozen_final')
    bench = C.load_source(source['benchmark_goop_graph_support_rollout.py'], C.FROZEN['benchmark_goop_graph_support_rollout.py'], '_cost_frozen_bench')
    a = SimpleNamespace(**{k: v for k, v in controls.items() if k != 'metadata'}, repo=Path(release['repo']),
        benchmark_helper=source['benchmark_goop_graph_support_rollout.py'], benchmark_sha256=C.FROZEN['benchmark_goop_graph_support_rollout.py'],
        trainer_source=source['train_goop_graph_support_cuda.py'], checkpoint=Path(selected['checkpoint']['path']),
        checkpoint_sha256=selected['checkpoint']['sha256'], arm=args.arm, seed=args.seed, split='valid',
        objective='faithful', mode='same-state', cuda_index=args.seed, threads=2, output_dir=output, cross_split_audit=None)
    train = json.loads(a.train_admission.read_text())
    cohort = json.loads(a.cohort.read_text())
    original = evaluator.check_cohort(cohort, a, train)
    C.require(original['checkpoint_path'] == selected['original_checkpoint_path'], 'Original cohort checkpoint path lineage differs')
    # Frozen all-six cohort gate precedes reading the validation manifest.
    manifest = json.loads(a.manifest.read_text())
    admission = json.loads(a.admission.read_text())
    structural = json.loads(a.structural_report.read_text())
    evaluator.check_split(bench, manifest, admission, structural, a, C.sha(a.cohort))
    C.require(C.sha(controls['metadata']) == evaluator.METADATA_SHA
              and json.loads(controls['metadata'].read_text()) == manifest['metadata'], 'Metadata differs')
    expected = C.schedule(manifest['records'], phase)
    frozen_full = evaluator.schedules(manifest['records'], 'same-state')
    C.require(expected == [r for r in frozen_full if r['schedule_index'] in {x['schedule_index'] for x in expected}], 'Frozen schedule interface differs')
    C.require(tuple(evaluator.TIMING_CASES) == C.CASES and evaluator.REPEATS == 7, 'Frozen timing cases/repeats differ')
    native, helpers = bench.load_helpers(a.repo)
    inputs.update({str(a.repo / p): d for p, d in bench.SOURCE_PINS.items()})
    inputs.update(bench.load_split_evidence(a, manifest, admission, helpers))
    trajectories = helpers.data_loader.load_manifest_data(a.manifest, verify_hashes=True)
    C.require(len(trajectories) == 30, 'All validation trajectories required')
    for record, (positions, types) in zip(manifest['records'], trajectories):
        C.require(positions.shape == tuple(record['positions']['shape']) and helpers.np.isfinite(positions).all()
                  and helpers.np.all(types == 7), 'Actual validation values/types differ')
        for field in ('positions', 'particle_types'):
            path = helpers.data_loader._manifest_array_path(a.manifest.resolve().parent, record[field])
            C.require(path.stat().st_size == record[field]['size_bytes'], 'Validation array byte length differs')
            inputs[str(path)] = record[field]['sha256']
    device, runtime = bench.configure_cuda(helpers, a)
    gpu = next(g for g in release['gpus'] if g['index'] == args.seed)
    C.require(C.gpu_uuid(runtime['uuid']) == C.gpu_uuid(gpu['uuid']), 'Actual GPU UUID differs from paired-seed stream')
    model_args = SimpleNamespace(**vars(a), model_kind='checkpoint', checkpoint_updates=100000, training_protocol=a.protocol)
    model, model_identity = bench.prepare_model(helpers, model_args, manifest['metadata'], train, device)
    C.write(output / 'protocol.json', dict(schema=C.CHILD_SCHEMA, phase=phase, study_identity=identity,
        release_sha256=C.sha(args.release), owner_pid=os.getppid(), pid=os.getpid(), arm=args.arm, seed=args.seed,
        runtime=runtime, model=model_identity, original_checkpoint_path=original['checkpoint_path'],
        actual_checkpoint_path=selected['checkpoint']['path'], schedule=expected, workload=C.WORKLOAD,
        input_files_sha256=inputs, work_stop_utc=work_stop.isoformat()))
    setup = time.monotonic() - ENTRY_MONOTONIC
    block_seconds, committed = [], []
    with helpers.torch.no_grad():
        for item in expected:
            block_start = time.monotonic()
            C.require(C.utc() < work_stop, 'Child work deadline reached')
            positions, types = trajectories[item['source_index']]
            row, arrays = evaluator.same_state(native, model, positions, types, manifest['metadata'], item, 'valid', args.seed, device)
            check_complete_timing(row, evaluator)
            memory = memory_pass(evaluator, native, helpers.torch, model, arrays, row, device, gpu['total_memory_bytes'])
            retained = reference_arrays(arrays)
            C.require(all(isinstance(v, helpers.np.ndarray) and not v.dtype.hasobject for v in retained.values()), 'Numeric CPU reference artifacts required')
            basename = 'state_%03d' % item['schedule_index']
            path = output / (basename + '.npz')
            temporary = path.with_suffix('.npz.tmp')
            with temporary.open('xb') as stream:
                helpers.np.savez_compressed(stream, **retained); stream.flush(); os.fsync(stream.fileno())
            temporary.replace(path)
            result = dict(cost_row(row), memory=memory, artifact_file=path.name, artifact_sha256=C.sha(path),
                array_value_sha256={k: native.full.state_hash(v) for k, v in retained.items()}, complete_forwards=76)
            C.write(output / (basename + '.json'), result)
            committed.append(dict(schedule_index=item['schedule_index'], path=basename + '.json', sha256=C.sha(output / (basename + '.json'))))
            C.write(output / 'progress.json', dict(status='running', phase=phase, completed_blocks=len(committed), expected_blocks=len(expected), committed=committed))
            del result, row, arrays, retained, memory
            # Includes compressed numeric publication, hashing, ledger update,
            # and releasing all returned arrays; never just the forward timer.
            block_seconds.append(time.monotonic() - block_start)
    finished_blocks = time.monotonic()
    C.verify_files(inputs)
    helpers.torch.cuda.synchronize(device)
    result = dict(schema=C.CHILD_SCHEMA, status='complete', phase=phase, study_identity=identity,
        release_sha256=C.sha(args.release), arm=args.arm, seed=args.seed, blocks=len(committed),
        schedule=expected, checkpoint_sha256=selected['checkpoint']['sha256'], gpu_uuid=gpu['uuid'],
        original_checkpoint_path=original['checkpoint_path'], actual_checkpoint_path=selected['checkpoint']['path'],
        cuda_reported_gpu_uuid=runtime['uuid'], canonical_gpu_uuid=C.gpu_uuid(runtime['uuid']),
        all_inputs_reverified=True, all_memory_reference_hashes_equal=True, all_headroom_checks_passed=True,
        complete_forwards=76 * len(committed), setup_seconds=setup,
        publication_inclusive_block_seconds=block_seconds, maximum_publication_inclusive_block_seconds=max(block_seconds),
        finalization_seconds=time.monotonic() - finished_blocks, host_peak_rss_kib=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
        host_peak_rss_scope='Linux process lifetime, separately from CUDA allocator observations', committed=committed,
        completed_utc=C.utc().isoformat(), elapsed_before_receipt_seconds=time.monotonic() - ENTRY_MONOTONIC)
    C.write(output / 'receipt.json', result)
    return 0


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    p.add_argument('--execute', action='store_true'); p.add_argument('--release', type=Path)
    p.add_argument('--arm', choices=('base', 'mix')); p.add_argument('--seed', type=int, choices=range(3))
    p.add_argument('--work-stop-utc')
    args = p.parse_args(argv)
    if not args.execute:
        print(json.dumps(dict(status='description_only', execution=False, workload=C.WORKLOAD, limits=C.LIMITS), indent=2)); return 0
    C.require(all(getattr(args, k) is not None for k in ('release', 'arm', 'seed', 'work_stop_utc')), 'Explicit complete owner arguments required')
    def expired(signum, frame):
        raise TimeoutError('Absolute owner work deadline reached')
    seconds = (C.stamp(args.work_stop_utc) - C.utc()).total_seconds()
    C.require(seconds > 0, 'Expired child deadline')
    signal.signal(signal.SIGALRM, expired); signal.setitimer(signal.ITIMER_REAL, seconds)
    release = json.loads(args.release.read_bytes())
    try:
        return execute(args, release)
    except BaseException as error:
        output = Path(release['outputs'][release['phase']]) / ('seed%d_%s' % (args.seed, args.arm))
        if output.is_dir():
            C.write(output / 'failed_attempt.json', dict(status='failed', error_type=type(error).__name__, error=str(error),
                retained_existing_products=True, no_retry_or_subset_authorized=True, utc=C.utc().isoformat()))
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)


if __name__ == '__main__':
    raise SystemExit(main())
