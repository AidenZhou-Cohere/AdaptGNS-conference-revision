#!/usr/bin/env python3
"""Stage the explicitly amended v3 sources using the ORIGINAL v2 study clock.

No model transfer, no numerical inference, no pilot issuance or launch.
"""
import argparse,base64,datetime,hashlib,importlib.util,json,pathlib,time,sys
P=pathlib.Path(__file__).resolve().parent
OLD_STAGE=P/'stage_goop2d_validation_cost_root_v2.py'
assert hashlib.sha256(OLD_STAGE.read_bytes()).hexdigest()=='f6db2dd834752ecc60f11260b78c21e84274ce1ebffded9b8c2c14801d3f5911'
spec=importlib.util.spec_from_file_location('_preserved_cost_stager',OLD_STAGE);old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)
STAGE=old.STAGE.replace('+5<300','+5<900')
VERIFY=old.VERIFY.replace('+5<300','+5<900')
CAPTURE=r'''import sys,json,pathlib,os,socket,subprocess,time,datetime
x=json.load(sys.stdin);origin=x['clock'];checked=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),host_monotonic_seconds=time.monotonic(),host_boot_id=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip())
print(json.dumps(dict(mode='v3_fresh_native_same_original_clock',original_clock=origin,checked=checked,pid=os.getpid(),start_ticks=int(pathlib.Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19]))),file=sys.stderr,flush=True)
assert checked['host_boot_id']==origin['host_boot_id'] and socket.gethostname()==x['hostname']
elapsed=checked['host_monotonic_seconds']-origin['host_monotonic_seconds'];wall=(datetime.datetime.fromisoformat(checked['checked_utc'])-datetime.datetime.fromisoformat(origin['checked_utc'])).total_seconds();assert elapsed>=0 and abs(wall-elapsed)<=5 and max(wall,elapsed)+5<900
rows=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdecimal() or int(p.name)==os.getpid():continue
 try:
  argv=[a.decode(errors='surrogateescape') for a in (p/'cmdline').read_bytes().split(b'\0') if a];fs=(p/'stat').read_text().rsplit(') ',1)[1].split();names=[pathlib.Path(a).name for a in argv]
  if any(n.startswith(('train_','evaluate_','supervise_','measure_goop2d_validation_cost')) and n.endswith('.py') for n in names):rows.append(dict(pid=int(p.name),ppid=int(fs[1]),start_ticks=int(fs[19]),argv=argv))
 except (FileNotFoundError,ProcessLookupError):pass
apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,process_name','--format=csv,noheader,nounits'],text=True,timeout=5)
gpus=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,name,memory.total','--format=csv,noheader,nounits'],text=True,timeout=5)
absent={str(pid):not (pathlib.Path('/proc')/str(pid)).exists() for pid in [57960,57965,57966,57967]}
unused={p:not pathlib.Path(p).exists() for p in x['new_paths']}
print(json.dumps(dict(original_clock_origin=origin,checked_clock=checked,hostname=socket.gethostname(),pid=os.getpid(),prior_v2_pids_absent=absent,scientific_processes=rows,gpu_apps=apps,gpus=gpus,destinations_unused=unused)))
assert not rows and not apps.strip() and all(absent.values()) and all(unused.values())
'''

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--candidate',type=pathlib.Path);p.add_argument('--output',type=pathlib.Path);a=p.parse_args()
 if not a.execute:print(json.dumps(dict(status='description_only',clock_reset=False,pilot_launch=False)));return
 assert a.candidate and a.output and not a.output.exists();a.output.mkdir(parents=True)
 r=json.loads((a.candidate/'pilot_candidate.json').read_bytes());inputs=json.loads((a.candidate/'complete_input_map.json').read_bytes())['files_sha256']
 oldroot=P/'goop2d_validation_cost_staged_root_v2';original=json.loads((oldroot/'resolved_pilot_UNADMITTED.json').read_bytes());local_origin=json.loads((oldroot/'local_monotonic_origin.json').read_bytes())['local_monotonic_seconds']
 assert r['clock_origin']==original['clock_origin'] and r['initial_staging_utc']==original['initial_staging_utc'] and r['absolute_stop_utc']==original['absolute_stop_utc']
 assert r['issued_by']!='root' and r['models']==original['models'] and r['controls']==original['controls'] and r['reporting_sources']==original['reporting_sources'] and r['gpus']==original['gpus']
 assert r['workload']==original['workload'] and r['environment']==original['environment'] and r['python']==original['python'] and r['hostname']==original['hostname']
 assert r['limits']==dict(original['limits'],staging_preflight_seconds=900)
 assert r['prior_failed_owner_receipt']==dict(path=r['repo']+'/goop2d_validation_cost_pilot_20261006_v2/owner_receipt.json',sha256='58c10ec8cb8f541a8cc824f6fc603352160b7a8048159001ea99d8dab2299000')
 assert r['instrumentation_amendment']['sha256']=='5e5d478bb5c8981359daf1b4666731d7a2b68c41875a40f8338ed90c54cf2bf5'
 names={'goop2d_validation_cost_contract_v3.py','measure_goop2d_validation_cost_v3.py','supervise_goop2d_validation_cost_v3.py'}
 assert names<=set(r['sources'])
 files={}
 for name in names:
  row=r['sources'][name];assert row['path']==r['repo']+'/cuda_preparation/'+name;raw=(P/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256'];files[row['path']]=dict(sha256=row['sha256'],base64=base64.b64encode(raw).decode())
 row=r['instrumentation_amendment'];assert row['path']==r['repo']+'/cuda_preparation/goop2d_validation_cost_v3_instrumentation_amendment_root_v1.md';raw=(P/pathlib.Path(row['path']).name).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256'];files[row['path']]=dict(sha256=row['sha256'],base64=base64.b64encode(raw).decode())
 assert len(files)==4 and all(inputs[path]==v['sha256'] for path,v in files.items())
 assert inputs[r['prior_failed_owner_receipt']['path']]==r['prior_failed_owner_receipt']['sha256']
 oldinputs=json.loads((P/'goop2d_validation_cost_candidate_UNADMITTED_owner_v2r2/complete_input_map.json').read_bytes())['files_sha256'];oldnew={original['sources'][n]['path'] for n in ['goop2d_validation_cost_contract_v2.py','measure_goop2d_validation_cost_v2.py','supervise_goop2d_validation_cost_v2.py']}
 expected={k:v for k,v in oldinputs.items() if k not in oldnew};expected.update({k:v['sha256'] for k,v in files.items()});expected[r['prior_failed_owner_receipt']['path']]=r['prior_failed_owner_receipt']['sha256'];assert inputs==expected and len(inputs)==139
 remaining=lambda:895-(time.monotonic()-local_origin)
 assert remaining()>0
 data=dict(clock=r['clock_origin'],hostname=r['hostname'])
 capture,_,_=old.runssh(CAPTURE,dict(data,new_paths=list(files)+list(r['outputs'].values())),a.output,'fresh_native_same_clock',timeout=min(30,remaining()))
 expected_gpu={g['index']:(g['uuid'],g['name'],g['nvidia_smi_total_memory_mib']) for g in r['gpus']};observed={}
 for line in capture['gpus'].strip().splitlines():
  i,u,n,m=[v.strip() for v in line.split(',')];observed[int(i)]=(u,n,int(m))
 assert observed==expected_gpu and not capture['scientific_processes'] and not capture['gpu_apps'].strip()
 old.dump(a.output/'resolved_pilot_UNADMITTED.json',r)
 old.runssh(STAGE,dict(data,files=files,new_dirs=[]),a.output,'new_source_staging',timeout=min(60,remaining()))
 verified,_,_=old.runssh(VERIFY,dict(data,files=inputs),a.output,'complete_input_hashes',timeout=remaining())
 assert verified['elapsed_monotonic_seconds']+5<900 and remaining()>0
 old.dump(a.output/'staging_receipt.json',dict(status='v3_staged_verified_pilot_unadmitted',original_clock_origin=r['clock_origin'],absolute_stop_utc=r['absolute_stop_utc'],files=139,all_failed_v2_time_retained=True,pilot_launched=False,clock_reset=False))
 print(json.dumps(dict(status='v3_staged_verified_pilot_unadmitted',elapsed_since_original_origin=verified['elapsed_monotonic_seconds'],output=str(a.output))));sys.stdout.flush()
 if remaining()<=0:
  old.dump(a.output/'late_staging_publication.json',dict(status='failed_late_publication',pilot_admitted=False));raise RuntimeError('v3 staging exceeds cumulative900s rule')

if __name__=='__main__':main()
