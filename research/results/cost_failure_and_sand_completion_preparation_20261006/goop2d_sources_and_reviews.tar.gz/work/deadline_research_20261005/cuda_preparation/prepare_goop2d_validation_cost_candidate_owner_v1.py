#!/usr/bin/env python3
"""Construct UNADMITTED cost-study controls from pinned local JSON metadata only.

Never opens a checkpoint, array, scientific Python source, remote path or shell.
Default description only. --build writes one fresh local candidate directory.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path
import re

HERE = Path(__file__).resolve().parent
META_PINS = {
 'goop2d_validation_cost_pilot_release_UNADMITTED_v1.json':'6c97a35f21293a2978d70cd2841b542c5197b1e2433fb0b0b2f5b5212480576c',
 'goop2d_validation_cost_full_release_UNADMITTED_v1.json':'6d9fa32ea2b6685637eeabcfab6f750482a6e08b5803d063a399b725dd694050',
 'goop2d_validation_cost_external_closure_UNADMITTED_v1.json':'bd758c50ab196531be6784ad10030d438a2fe4c6b4c39b1431d974d5dbd2c447',
 'aquamarine_idle_locality_1522_root_v1.json':'a81eb3106a518d40a099965f7bc0ff8068b971fde70cda05c67e85569cb34c91',
 'goop_evaluation_release_A_0947_v1.json':'fff53f74ac22e980fe6e9bfdddb6c32014d34d8150b5c6f3733a291843f1d6eb',
 'goop_evaluation_release_B_0949_v1.json':'0eb041ffe34391dbfb7e40ee5d3ab7338663c99847be548a57452b184468d825',
 'goop_gate_train_labels_seed0_release_1155_v1.json':'d01fa527e8203e9457e60cd91189413a0e11a21db1f44dced51d05ff052160a3',
 'goop_gate_train_labels_seed1_release_1155_v1.json':'bef4eee46013819b25c45625f0ba989d2ab1b249704588bda04fca9f96f77309',
 'goop2d_validation_cost_source_preparation_UNADMITTED_v1.json':'12d114b52d1ac6593340741998ea0dcbd7e9401139dd28a624d4dc9d19ce7c59',
 'goop2d_validation_cost_independent_review_code_audit_v1.json':'b032fdeeccab2b71be7a799b9254f7df784df6b775e3e93141ed2d3820add88f',
 'goop2d_validation_cost_lifecycle_source_review_transition_v1.json':'4050362b9714ed75d59655d6a428a483f5454d230e88052b1f76453c023e8ee8',
}
NUMERICAL = (
 'research/native_graph_rollout.py','research/graph_convention_bridge.py','research/full_rollout.py',
 'research/full_same_state.py','research/budget_graph.py','research/full_training.py',
 'adaptive-gns/gns/data_loader.py','adaptive-gns/gns/device_utils.py','adaptive-gns/gns/graph_network.py',
 'adaptive-gns/gns/learned_simulator.py','adaptive-gns/gns/losses.py','adaptive-gns/gns/model_io.py')
CONTEXT = ('README.md','learned_simulator.py','reading_utils.py','train.py')


def require(value,message):
    if not value: raise ValueError(message)


def encode(value):
    return (json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(path,value):
    raw=encode(value)
    with Path(path).open('xb') as stream: stream.write(raw)
    return sha(raw)


def pointer(*parts):
    return '/'+'/'.join(str(p).replace('~','~0').replace('/','~1') for p in parts)


def read_metadata():
    result={}
    for name,pin in META_PINS.items():
        path=HERE/name
        require(path.suffix=='.json','Only local JSON metadata is readable')
        raw=path.read_bytes()
        require(sha(raw)==pin,'Metadata changed: '+name)
        result[name]=json.loads(raw)
    return result


def assemble(meta):
    p_name='goop2d_validation_cost_pilot_release_UNADMITTED_v1.json'
    f_name='goop2d_validation_cost_full_release_UNADMITTED_v1.json'
    a_name='goop_evaluation_release_A_0947_v1.json';b_name='goop_evaluation_release_B_0949_v1.json'
    l_name='aquamarine_idle_locality_1522_root_v1.json'
    report_name='goop2d_validation_cost_source_preparation_UNADMITTED_v1.json'
    pilot,full=copy.deepcopy(meta[p_name]),copy.deepcopy(meta[f_name])
    require(pilot['status']==full['status']=='UNADMITTED_source_preparation_only','Templates must be unadmitted')
    common_keys=set(pilot)-{'phase'}
    require(all(pilot[k]==full[k] for k in common_keys),'Pilot/full common fields differ before construction')
    locality=meta[l_name];a=meta[a_name];b=meta[b_name];R=pilot['repo']
    require(pilot['hostname']==locality['hostname'] and locality['matching_processes']==[] and locality['gpu_apps']=='','Planning-only B host evidence differs')
    observed=[]
    for line in locality['gpu_inventory'].splitlines():
        index,uuid,name,memory,used=[x.strip() for x in line.split(',')]
        require(int(used)==0,'Planning-only GPU inventory not idle')
        observed.append(dict(index=int(index),uuid=uuid,name=name,total_memory_bytes=int(memory)*1048576))
    require(pilot['gpus']==observed,'Four physical GPU identities differ from existing B metadata')
    py=b['python_environment'];expected_python=dict(lexical_path=py['lexical_path'],resolved_path=py['resolved_binary_path'],
        sha256=py['binary_sha256'],venv_config=dict(path=py['pyvenv_config_path'],sha256=py['pyvenv_config_sha256']))
    require(pilot['python']==expected_python,'B interpreter/venv metadata differs')
    for candidate in (pilot,full):
        candidate.update(issued_by=None,status='UNADMITTED_actual_metadata_candidate',initial_staging_utc=None,absolute_stop_utc=None)
        candidate['clock_origin']={k:None for k in candidate['clock_origin']}
        candidate['preparation_notes'].update(authority_unset=True,all_clock_fields_unset=True,
            no_staging_or_clock_started=True,prior_metadata_is_not_fresh_native_or_byte_evidence=True)
    full['full_admission_utc']=None
    full['pilot_receipt']['sha256']=None;full['pilot_external_closure']['sha256']=None
    closure=copy.deepcopy(meta['goop2d_validation_cost_external_closure_UNADMITTED_v1.json'])
    closure.update(issued_by=None,status='UNADMITTED_actual_metadata_candidate')

    files={};binding_rows={};lineage={};copies=[]
    def evidence(name,*parts):
        return dict(metadata_file=name,metadata_sha256=META_PINS[name],json_pointer=pointer(*parts))
    def add(path,pin,role,proof):
        require(Path(path).is_absolute() and isinstance(pin,str) and re.fullmatch('[0-9a-f]{64}',pin),'Absolute exact path/hash required')
        require('/test/' not in path and '/test_' not in path and not Path(path).name.startswith('test'), 'No test input may enter this validation candidate')
        require(path not in files or files[path]==pin,'Conflicting path/hash metadata')
        files[path]=pin
        row=binding_rows.setdefault(path,dict(path=path,sha256=pin,roles=[],metadata_evidence=[]))
        if role not in row['roles']:row['roles'].append(role)
        if proof not in row['metadata_evidence']:row['metadata_evidence'].append(proof)
    for name,row in pilot['sources'].items():
        add(row['path'],row['sha256'],'entry_or_new_source',evidence(p_name,'sources',name,'sha256'))
        if name in meta[report_name]['source_files']:
            require(meta[report_name]['source_files'][name]==row['sha256'],'New source preparation pin differs')
            add(row['path'],row['sha256'],'entry_or_new_source',evidence(report_name,'source_files',name))
        else:
            require(b['files_sha256'][row['path']]==row['sha256'],'Frozen entry source differs from original evaluation metadata')
            add(row['path'],row['sha256'],'entry_or_new_source',evidence(b_name,'files_sha256',row['path']))
    for key,row in pilot['controls'].items():
        require(b['files_sha256'][row['path']]==row['sha256'],'Original control metadata differs: '+key)
        add(row['path'],row['sha256'],'control_'+key,evidence(b_name,'files_sha256',row['path']))
    for relative in NUMERICAL:
        path=R+'/'+relative;pin=b['files_sha256'][path]
        require(a['files_sha256'][path]==pin,'Original A/B numerical helper pins disagree')
        add(path,pin,'frozen_numerical_helper',evidence(b_name,'files_sha256',path))
    for name in CONTEXT:
        path=R+'/cuda_preparation/goop_context_semantics_sources/'+name
        add(path,b['files_sha256'][path],'preserved_context_source',evidence(b_name,'files_sha256',path))
    for field in ('position','type','step_context'):
        expected={R+'/goop_numeric_train_valid_20261006_v1/valid/'+field+'_%06d.npy'%i for i in range(30)}
        observed={path for path in b['files_sha256'] if path.startswith(R+'/goop_numeric_train_valid_20261006_v1/valid/'+field+'_')}
        require(observed==expected,'Complete validation array metadata grid differs: '+field)
        for path in sorted(expected):
            require(a['files_sha256'][path]==b['files_sha256'][path],'A/B validation array hash metadata disagree')
            add(path,b['files_sha256'][path],'validation_'+field+'_array',evidence(b_name,'files_sha256',path))
    require(len(pilot['models'])==6 and {(m['arm'],m['seed']) for m in pilot['models']}=={(arm,seed) for arm in ('base','mix') for seed in range(3)},'Original complete six-model identity set required')
    for index,model in enumerate(pilot['models']):
        original=model['original_checkpoint_path'];actual=model['checkpoint']['path'];pin=model['checkpoint']['sha256']
        role='A' if model['seed']<2 else 'B';origin_meta=a_name if role=='A' else b_name
        require(meta[origin_meta]['files_sha256'][original]==pin,'Original cohort endpoint hash differs')
        lineage[original]=pin
        proof=evidence(origin_meta,'files_sha256',original)
        copy_evidence=[proof,evidence(p_name,'models',index,'checkpoint')]
        if model['seed']<2 and model['arm']=='mix':
            gate_name='goop_gate_train_labels_seed%d_release_1155_v1.json'%model['seed']
            require(meta[gate_name]['files_sha256'][actual]==pin,'Previously released mix copy hash differs from original endpoint')
            proof=evidence(gate_name,'files_sha256',actual);copy_evidence.append(proof)
            availability='prior_admitted_gate_copy_path_metadata_only; fresh B rehash required'
            transfer=False
        elif role=='B':
            require(actual==original and locality['original_checkpoint_path_locality'][original]['exists'] is True,'Original B endpoint locality differs')
            availability='exists_in_planning_only_B_snapshot; fresh B rehash required';transfer=False
        else:
            require(actual==R+'/goop2d_validation_cost_inputs_20261006_v1/base_seed%d.pt'%model['seed'],'Prospective base copy destination differs')
            require(locality['original_checkpoint_path_locality'][original]['exists'] is False,'Planning snapshot no longer matches original A path absence')
            availability='prospective_fresh_destination; no copy or byte observation performed';transfer=True
        add(actual,pin,'actual_model_checkpoint',proof)
        copies.append(dict(arm=model['arm'],seed=model['seed'],original_host_role=role,
            original_checkpoint_path=original,actual_B_checkpoint_path=actual,checkpoint_sha256=pin,
            transfer_required_before_pilot=transfer,availability_evidence=availability,
            fresh_local_byte_verification_required=True,current_payload_opened=False,metadata_evidence=copy_evidence))
    for path,pin,role,parts in ((py['lexical_path'],py['binary_sha256'],'python_lexical',('python_environment','binary_sha256')),
            (py['resolved_binary_path'],py['binary_sha256'],'python_resolved',('python_environment','binary_sha256')),
            (py['pyvenv_config_path'],py['pyvenv_config_sha256'],'python_venv',('python_environment','pyvenv_config_sha256'))):
        require(b['files_sha256'][path]==pin,'Interpreter file metadata differs')
        add(path,pin,role,evidence(b_name,*parts))
    require(len(files)==134,'Exact complete source/input map expected: 134 distinct paths')
    require(len(lineage)==6 and len(set(lineage.values()))==6,'Six distinct original endpoint hashes required')
    counts=dict(entry_or_new_sources=8,controls=11,frozen_numerical_helpers=12,preserved_context_sources=4,
                validation_position_arrays=30,validation_type_arrays=30,preserved_validation_step_context_arrays=30,
                actual_model_checkpoints=6,interpreter_and_venv_paths=3,total_distinct_input_paths=134,
                test_input_paths=0,training_array_paths=0)
    provenance=dict(schema='adaptgns_goop2d_validation_cost_candidate_provenance_v1',status='UNADMITTED_metadata_only',
        bindings=[binding_rows[p] for p in sorted(binding_rows)],input_metadata_sha256=META_PINS,
        counts=counts,all_bound_remote_bytes_require_fresh_verification=True,
        source_or_model_or_array_payloads_read=False,current_remote_locality_verified=False)
    mapping=dict(schema='adaptgns_goop2d_validation_cost_copy_mapping_v1',status='UNADMITTED_metadata_only',
        cohort_binding=pilot['controls']['cohort'],cohort_audit_binding=pilot['controls']['cohort_audit'],
        models=copies,original_lineage_file_sha256=lineage,
        original_A_paths_are_lineage_only_not_required_B_local_inputs=True)
    native=dict(schema='adaptgns_goop2d_validation_cost_host_candidate_v1',status='UNADMITTED_prior_metadata_only',
        hostname=pilot['hostname'],gpus=pilot['gpus'],python=pilot['python'],
        planning_snapshot=dict(path=l_name,sha256=META_PINS[l_name],checked_utc=locality['checked_utc']),
        fresh_native_process_and_gpu_closure_required=True,cuda_memory_total_compatibility_verified=None,
        clock_origin=None,phase_launch_authority=None,clock_error_bound_seconds_maximum=5)
    return dict(pilot_candidate=pilot,full_candidate=full,external_closure_candidate=closure,
        complete_input_map=dict(schema='adaptgns_goop2d_validation_cost_complete_input_map_v1',
            status='UNADMITTED_metadata_only',files_sha256=dict(sorted(files.items())),counts=counts),
        provenance_bindings=provenance,copy_mapping=mapping,host_candidate=native)


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__,allow_abbrev=False)
    parser.add_argument('--build',action='store_true');parser.add_argument('--output',type=Path)
    args=parser.parse_args(argv)
    if not args.build:
        print(json.dumps(dict(status='description_only',execution=False,metadata_inputs=len(META_PINS)),indent=2));return 0
    require(args.output is not None,'Explicit fresh local output directory required')
    out=args.output.resolve();require(out.parent==HERE,'Candidate must stay in local preparation directory')
    meta=read_metadata();products=assemble(meta)
    # Recheck every input metadata byte before publication. No source, model or
    # numerical array is opened even to check existence.
    read_metadata()
    out.mkdir(mode=0o700,exist_ok=False)
    output_sha={name+'.json':write(out/(name+'.json'),value) for name,value in products.items()}
    description='''# Goop2D cost candidate — UNADMITTED\n\nThese controls contain known paths and hashes from pinned local metadata. Authority and all clock fields remain null. They have not been issued or staged; the 3,600-second clock has not started.\n\nThe complete input map has 134 distinct paths: 8 entry/new sources, 12 frozen numerical helpers, 4 preserved context sources, 11 controls, 60 validation position/type arrays, 30 preserved validation context arrays, 6 actual checkpoint paths and 3 interpreter/venv paths. Original A lineage paths remain separate from actual B input paths.\n\nThe two base seed-0/1 destinations need charged transfer before pilot; mix seed-0/1 use prior gate-copy path metadata, and seed-2 uses original B paths. Every actual checkpoint and input needs a fresh rehash. No model or array payload was opened.\n\nRoot owns fresh native/device-memory checks, monotonic/boot clock capture, source/input staging, pilot issuance, measured capacity admission, and any launch. The pilot does not authorize the full study.\n'''
    with (out/'README.md').open('x') as stream:stream.write(description)
    output_sha['README.md']=sha(description.encode())
    record=dict(schema='adaptgns_goop2d_validation_cost_candidate_construction_v1',status='UNADMITTED_metadata_only_complete',
        builder_sha256=sha(Path(__file__).read_bytes()),input_metadata_sha256=META_PINS,output_sha256=output_sha,
        counts=products['complete_input_map']['counts'],model_mapping_count=6,authority=None,clock_started=False,
        payloads_read=False,remote_calls=False,staging_performed=False,launch_performed=False)
    digest=write(out/'construction.json',record)
    print(json.dumps(dict(output=str(out),construction_sha256=digest,counts=record['counts']),indent=2));return 0


if __name__=='__main__':raise SystemExit(main())
