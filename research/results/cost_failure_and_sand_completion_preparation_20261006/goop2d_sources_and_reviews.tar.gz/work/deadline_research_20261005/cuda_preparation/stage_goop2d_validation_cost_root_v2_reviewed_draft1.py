#!/usr/bin/env python3
"""Root staging only; never launches a pilot. No action without --execute.

The first remote sample starts the immutable 3600-second clock. All transfer,
source staging and full opaque input hashing count toward initial 300 seconds.
"""
import argparse,base64,datetime,hashlib,json,pathlib,shlex,subprocess,time
P=pathlib.Path(__file__).resolve().parent
B='aquamarine-toad-75.coder';A='yellow-worm-77.coder'
PYTHON='/root/repos/AdaptGNS-cuda-20261006/.venv/bin/python'

def dump(path,value):
 with path.open('x') as f: json.dump(value,f,indent=2,sort_keys=True);f.write('\n')

def runssh(code,data,output,name,timeout=60):
 start=datetime.datetime.now(datetime.timezone.utc)
 p=subprocess.run(['ssh','-T','-F',str(P/'ssh_config'),B,PYTHON+' -B -c '+shlex.quote(code)],input=json.dumps(data),text=True,capture_output=True,timeout=timeout)
 end=datetime.datetime.now(datetime.timezone.utc)
 (output/(name+'.stdout')).write_text(p.stdout);(output/(name+'.stderr')).write_text(p.stderr)
 dump(output/(name+'.external.json'),dict(exit_code=p.returncode,local_before_utc=start.isoformat(),local_after_utc=end.isoformat()))
 if p.returncode:raise RuntimeError(name+' failed; preserve clock and outputs, no automatic retry')
 value=json.loads(p.stdout);dump(output/(name+'.json'),value)
 return value,start,end

CAPTURE=r'''import pathlib,os,json,sys,socket,time,datetime,subprocess
x=json.load(sys.stdin);clock=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),host_monotonic_seconds=time.monotonic(),host_boot_id=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),error_bound_seconds=5)
rows=[]
for p in pathlib.Path('/proc').iterdir():
 if not p.name.isdecimal() or int(p.name)==os.getpid():continue
 try:
  argv=[s.decode(errors='surrogateescape') for s in (p/'cmdline').read_bytes().split(b'\0') if s];fs=(p/'stat').read_text().rsplit(') ',1)[1].split();names=[pathlib.Path(a).name for a in argv]
  if any((n.startswith(('train_','evaluate_','supervise_','measure_goop2d_validation_cost')) and n.endswith('.py')) for n in names): rows.append(dict(pid=int(p.name),ppid=int(fs[1]),start_ticks=int(fs[19]),argv=argv))
 except (FileNotFoundError,ProcessLookupError):pass
apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,process_name','--format=csv,noheader,nounits'],text=True,timeout=5)
gpus=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,name,memory.total','--format=csv,noheader,nounits'],text=True,timeout=5)
missing={str(pid):not (pathlib.Path('/proc')/str(pid)).exists() for pid in [56878,57161]}
out=dict(clock_origin=clock,hostname=socket.gethostname(),pid=os.getpid(),scientific_processes=rows,gpu_apps=apps,gpus=gpus,qualification_native_absent=missing,destinations_unused={p:not pathlib.Path(p).exists() for p in x['new_paths']})
print(json.dumps(out))
assert out['hostname']==x['hostname'] and not rows and not apps.strip() and all(missing.values()) and all(out['destinations_unused'].values())
'''

STAGE=r'''import pathlib,sys,json,base64,hashlib,time,datetime,socket
x=json.load(sys.stdin);c=x['clock'];elapsed=time.monotonic()-c['host_monotonic_seconds'];assert pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()==c['host_boot_id'];assert socket.gethostname()==x['hostname'];assert elapsed+5<300
result={}
for path,value in x['files'].items():
 p=pathlib.Path(path);raw=base64.b64decode(value['base64']);assert hashlib.sha256(raw).hexdigest()==value['sha256'];p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(raw)
 result[path]=hashlib.sha256(p.read_bytes()).hexdigest();assert result[path]==value['sha256']
for path in x['new_dirs']:pathlib.Path(path).mkdir(parents=True,exist_ok=False)
print(json.dumps(dict(files=result,elapsed_monotonic_seconds=time.monotonic()-c['host_monotonic_seconds'])))
'''

VERIFY=r'''import pathlib,sys,json,hashlib,time,datetime,socket
x=json.load(sys.stdin);c=x['clock'];assert pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()==c['host_boot_id'];assert socket.gethostname()==x['hostname'];result={}
for path,expected in x['files'].items():
 assert time.monotonic()-c['host_monotonic_seconds']+5<300
 p=pathlib.Path(path);h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(1<<20),b''):h.update(block)
 actual=h.hexdigest();assert actual==expected,(path,expected,actual);result[path]=dict(sha256=actual,size_bytes=p.stat().st_size)
clock=dict(checked_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),host_monotonic_seconds=time.monotonic(),host_boot_id=pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip())
print(json.dumps(dict(files=result,clock=clock,elapsed_monotonic_seconds=clock['host_monotonic_seconds']-c['host_monotonic_seconds'])))
'''

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--execute',action='store_true');p.add_argument('--candidate',type=pathlib.Path);p.add_argument('--output',type=pathlib.Path);a=p.parse_args()
 if not a.execute:print(json.dumps(dict(status='description_only',pilot_launch=False)));return
 assert a.candidate and a.output and not a.output.exists();a.output.mkdir(parents=True)
 candidate=json.loads((a.candidate/'pilot_candidate.json').read_bytes());mapping=json.loads((a.candidate/'copy_mapping.json').read_bytes());inputs=json.loads((a.candidate/'complete_input_map.json').read_bytes())['files_sha256']
 assert candidate['initial_staging_utc'] is None and candidate['issued_by']!='root'
 files={}
 for name,row in {**{k:v for k,v in candidate['sources'].items() if k.endswith('_v2.py')},**candidate['reporting_sources']}.items():
  raw=(P/name).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256'];files[row['path']]=dict(base64=base64.b64encode(raw).decode(),sha256=row['sha256'])
 row=candidate['hardware_memory_evidence'];raw=(P/pathlib.Path(row['path']).name).read_bytes();assert hashlib.sha256(raw).hexdigest()==row['sha256'];files[row['path']]=dict(base64=base64.b64encode(raw).decode(),sha256=row['sha256'])
 transfers=[r for r in mapping['models'] if r['transfer_required_before_pilot']];assert len(transfers)==2 and {(r['arm'],r['seed']) for r in transfers}=={('base',0),('base',1)}
 dirs=sorted({str(pathlib.Path(r['actual_B_checkpoint_path']).parent) for r in transfers})
 new_paths=list(files)+dirs+list(candidate['outputs'].values())
 capture,before,after=runssh(CAPTURE,dict(new_paths=new_paths,hostname=candidate['hostname']),a.output,'initial_clock_native')
 c=capture['clock_origin'];remote=datetime.datetime.fromisoformat(c['checked_utc']);assert (after-before).total_seconds()<=5 and before-datetime.timedelta(seconds=5)<=remote<=after+datetime.timedelta(seconds=5)
 assert not capture['scientific_processes'] and not capture['gpu_apps'].strip() and all(capture['qualification_native_absent'].values()) and all(capture['destinations_unused'].values())
 expected={g['index']:(g['uuid'],g['name'],g['nvidia_smi_total_memory_mib']) for g in candidate['gpus']};observed={}
 for line in capture['gpus'].strip().splitlines():
  i,u,n,m=[s.strip() for s in line.split(',')];observed[int(i)]=(u,n,int(m))
 assert observed==expected
 candidate.update(initial_staging_utc=c['checked_utc'],absolute_stop_utc=(remote+datetime.timedelta(seconds=3600)).isoformat(),clock_origin=c)
 dump(a.output/'resolved_pilot_UNADMITTED.json',candidate)
 runssh(STAGE,dict(clock=c,hostname=candidate['hostname'],files=files,new_dirs=dirs),a.output,'source_staging')
 for row in transfers:
  remaining=300-5-(datetime.datetime.now(datetime.timezone.utc)-remote).total_seconds();assert remaining>0
  cmd=['scp','-3','-F',str(P/'ssh_config'),A+':'+row['original_checkpoint_path'],B+':'+row['actual_B_checkpoint_path']]
  result=subprocess.run(cmd,text=True,capture_output=True,timeout=remaining)
  name='transfer_base_seed%d'%row['seed'];(a.output/(name+'.stdout')).write_text(result.stdout);(a.output/(name+'.stderr')).write_text(result.stderr)
  dump(a.output/(name+'.json'),dict(exit_code=result.returncode,original=row['original_checkpoint_path'],destination=row['actual_B_checkpoint_path'],expected_sha256=row['checkpoint_sha256']))
  assert result.returncode==0,'Opaque checkpoint transfer failed; no retry'
 verified,_,_=runssh(VERIFY,dict(clock=c,hostname=candidate['hostname'],files=inputs),a.output,'full_input_hashes',timeout=max(1,295-(datetime.datetime.now(datetime.timezone.utc)-remote).total_seconds()))
 assert verified['elapsed_monotonic_seconds']+5<300
 dump(a.output/'staging_receipt.json',dict(status='staged_verified_pilot_unadmitted',clock_origin=c,absolute_stop_utc=candidate['absolute_stop_utc'],files=len(inputs),model_payloads_deserialized=False,pilot_launched=False))
 print(json.dumps(dict(status='staged_verified_pilot_unadmitted',output=str(a.output),elapsed=verified['elapsed_monotonic_seconds'],absolute_stop_utc=candidate['absolute_stop_utc'])))

if __name__=='__main__':main()
