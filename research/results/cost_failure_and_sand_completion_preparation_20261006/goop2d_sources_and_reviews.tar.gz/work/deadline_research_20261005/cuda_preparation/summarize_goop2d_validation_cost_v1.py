#!/usr/bin/env python3
"""Complete-cohort scalar summary; no numerical inference or array replay.

The stopped owner already verified numeric artifact bytes. This independent
summary verifies its scalar chains and aggregation, not the NPZ payloads.
Default invocation describes the interface without reading result files.
"""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import statistics
import socket
import sys
import time
from datetime import datetime, timezone

sys.dont_write_bytecode = True

TIMES = ('end_to_end_seconds', 'score_generation_seconds', 'score_graph_seconds',
         'score_forward_seconds', 'current_graph_and_selection_seconds', 'current_forward_seconds')
MEMORY = ('baseline_allocated_bytes', 'baseline_reserved_bytes', 'peak_allocated_bytes',
          'incremental_allocated_bytes', 'peak_reserved_bytes', 'after_allocated_bytes',
          'after_reserved_bytes', 'device_free_before_bytes', 'device_free_after_bytes', 'device_total_bytes')
MODELS = {(arm, seed) for arm in ('base', 'mix') for seed in range(3)}
REPORTERS = ('summarize_goop2d_validation_cost_v1.py', 'collect_goop2d_validation_cost_scalars_v1.py')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path, expected=None):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'Missing or linked scalar: ' + str(path))
    raw = path.read_bytes()
    if expected is not None:
        require(hashlib.sha256(raw).hexdigest() == expected, 'Scalar byte hash changed: ' + str(path))
    return json.loads(raw)


def verify_reporting_sources(release):
    sources = release.get('reporting_sources', {})
    require(set(sources) == set(REPORTERS), 'Exact separately released reporting sources required')
    for name, bound in sources.items():
        actual = Path(__file__).resolve().parent / name
        require(set(bound) == {'path', 'sha256'} and str(actual) == bound['path']
            and not actual.is_symlink() and sha(actual) == bound['sha256'], 'Reporting source changed: ' + name)


def deadline_check(release):
    """Run reporting on the same host/boot and original, never-reset clock."""
    origin = release['clock_origin']
    boot = Path('/proc/sys/kernel/random/boot_id').read_text().strip()
    require(socket.gethostname() == release['hostname'] and boot == origin['host_boot_id'], 'Reporting host/boot changed')
    now, mono = datetime.now(timezone.utc), time.monotonic()
    elapsed = mono - origin['host_monotonic_seconds']
    wall = (now - datetime.fromisoformat(release['initial_staging_utc'])).total_seconds()
    error = origin['error_bound_seconds']
    require(0 <= elapsed and abs(wall - elapsed) <= error and max(wall, elapsed) + error < 3600,
        'Reporting exceeded original 3600-second allocation or clock agreement')
    return dict(checked_utc=now.isoformat(), host_monotonic_seconds=mono, host_boot_id=boot,
        elapsed_monotonic_seconds=elapsed, error_bound_seconds=error,
        remaining_seconds=3600 - max(wall, elapsed) - error)


def avg(values):
    require(values and all(type(v) in (float, int) and math.isfinite(v) for v in values), 'Nonfinite or empty scalar group')
    return statistics.fmean(values)


def average_metrics(rows):
    require(rows and all(set(r) == set(rows[0]) for r in rows), 'Metric coverage differs')
    return {key: avg([r[key] for r in rows]) for key in rows[0]}


def state_metrics(row, cases):
    result = {}
    for policy in cases:
        calls = [c for c in row['timed_calls'] if c['method'] == policy]
        require(len(calls) == 7 and {c['round'] for c in calls} == set(range(7)), 'All seven distinct timing rounds required')
        mem = [m for m in row['memory'] if m['method'] == policy]
        require(len(mem) == 1, 'Exactly one separate memory observation required')
        result[policy] = {key: avg([c['timing'][key] for c in calls]) for key in TIMES}
        for key in MEMORY:
            value = mem[0][key]
            require(type(value) is int and value >= 0, 'Invalid memory scalar')
            result[policy][key] = value
    return result


def aggregate(rows, cases):
    """Average repeats -> histories -> trajectories; never pool training seeds."""
    expected = {(i, t) for i in range(30) for t in (7, 105, 203, 301, 400)}
    require(len(rows) == 150 and {(r['source_index'], r['target_frame']) for r in rows} == expected,
            'Full 30-source/five-target grid required without duplicates')
    states = {r['schedule_index']: state_metrics(r, cases) for r in rows}
    require(set(states) == set(range(150)), 'Original schedule indices required')
    trajectories = []
    for source in range(30):
        selected = [r for r in rows if r['source_index'] == source]
        require(len({r['trajectory_id'] for r in selected}) == 1, 'Trajectory identity differs across targets')
        trajectories.append(dict(source_index=source, trajectory_id=selected[0]['trajectory_id'],
            policies={p: average_metrics([states[r['schedule_index']][p] for r in selected]) for p in cases}))
    return dict(trajectories=trajectories,
        policies={p: average_metrics([r['policies'][p] for r in trajectories]) for p in cases},
        maximum_observed_memory={p: {key: max(next(m[key] for m in r['memory'] if m['method'] == p) for r in rows)
            for key in ('peak_allocated_bytes', 'incremental_allocated_bytes', 'peak_reserved_bytes')} for p in cases})


def three_seed(values):
    require(len(values) == 3, 'Exactly three independent training-seed summaries required')
    return dict(seed_values=values, mean=avg(values), sample_sd=statistics.stdev(values), n_seeds=3)


def paired(first, second):
    """Second minus first; percentages are paired first, then averaged."""
    require(len(first) == len(second) == 3, 'Three paired seeds required')
    difference = three_seed([b - a for a, b in zip(first, second)])
    pct = [100 * (b - a) / a if a != 0 else None for a, b in zip(first, second)]
    return dict(difference_second_minus_first=difference, paired_percent_change=dict(seed_values=pct,
        mean=avg(pct) if None not in pct else None,
        sample_sd=statistics.stdev(pct) if None not in pct else None,
        undefined_reason='zero first-arm denominator' if None in pct else None))


def summarize(bundle, contract_path, check=lambda: None):
    bundle, contract_path = Path(bundle), Path(contract_path)
    release = read(bundle / 'release.json')
    verify_reporting_sources(release)
    bound = release['sources'].get(contract_path.name)
    require(bound is not None and sha(contract_path) == bound['sha256'], 'Exact released contract required')
    spec = importlib.util.spec_from_file_location('_cost_summary_contract', contract_path)
    C = importlib.util.module_from_spec(spec); spec.loader.exec_module(C)
    owner = read(bundle / 'owner_receipt.json')
    closure = read(bundle / 'external_closure.json')
    identity = C.validate_release(release, 'full', now=C.stamp(owner['completed_utc']), verify=False)
    require(owner.get('schema') == C.OWNER_SCHEMA and owner.get('status') == 'complete'
        and owner.get('phase') == 'full' and owner.get('failure') is None
        and owner.get('study_identity') == identity and owner.get('release_sha256') == sha(bundle / 'release.json')
        and owner.get('all_children_reaped') is True and owner.get('final_gpu_processes') == []
        and owner.get('observed_complete_blocks') == 900, 'Complete original full owner required')
    require(closure.get('schema') == 'adaptgns_goop2d_validation_cost_full_external_closure_v1'
        and closure.get('issued_by') == 'root'
        and closure.get('status') == 'original_session_exit_and_native_absence_verified'
        and closure.get('owner_receipt_sha256') == sha(bundle / 'owner_receipt.json')
        and closure.get('original_session_exit_code') == 0
        and closure.get('owner_native_absent') is True and closure.get('all_children_native_absent') is True
        and closure.get('gpu_processes') == [] and closure.get('host_boot_id') == release['clock_origin']['host_boot_id'],
        'Original external exit and native closure required')
    origin = release['clock_origin']
    wall = (C.stamp(closure['checked_utc']) - C.stamp(release['initial_staging_utc'])).total_seconds()
    mono = closure['checked_host_monotonic_seconds'] - origin['host_monotonic_seconds']
    require(owner.get('clock_origin') == origin and 0 <= mono and max(mono, wall) + origin['error_bound_seconds'] <= 3150
        and abs(wall - mono) <= origin['error_bound_seconds']
        and origin['host_monotonic_seconds'] <= owner['phase_started_monotonic'] <= owner['completed_monotonic']
            <= closure['checked_host_monotonic_seconds']
        and C.stamp(owner['completed_utc']) <= C.stamp(closure['checked_utc']),
        'Original-clock full closure and complete 450-second analysis reserve required')
    children = owner.get('children', [])
    require(len(children) == 6 and {(c['arm'], c['seed']) for c in children} == MODELS,
        'All six distinct completed children required')
    manifest = read(bundle / 'valid_manifest.json', release['controls']['manifest']['sha256'])
    expected = C.schedule(manifest['records'], 'full')
    all_files = {name: sha(bundle / name) for name in ('release.json', 'owner_receipt.json', 'external_closure.json', 'valid_manifest.json')}
    models = []
    for child in sorted(children, key=lambda c: (c['arm'], c['seed'])):
        check()
        arm, seed = child['arm'], child['seed']
        require(child.get('verified') is True and child.get('reaped') is True
            and child.get('exit_code') == 0 and child.get('signals') == [], 'Failed or unreaped child')
        folder = 'seed%d_%s' % (seed, arm)
        receipt = read(bundle / folder / 'receipt.json', child['receipt_sha256'])
        model = next(m for m in release['models'] if (m['arm'], m['seed']) == (arm, seed))
        require(receipt.get('schema') == C.CHILD_SCHEMA and receipt.get('status') == 'complete'
            and receipt.get('phase') == 'full' and receipt.get('study_identity') == identity
            and (receipt.get('arm'), receipt.get('seed')) == (arm, seed)
            and receipt.get('release_sha256') == owner['release_sha256']
            and receipt.get('checkpoint_sha256') == model['checkpoint']['sha256']
            and receipt.get('actual_checkpoint_path') == model['checkpoint']['path']
            and receipt.get('original_checkpoint_path') == model['original_checkpoint_path']
            and C.gpu_uuid(receipt['gpu_uuid']) == C.gpu_uuid(release['streams'][seed]['gpu_uuid'])
            and receipt.get('schedule') == expected and receipt.get('blocks') == 150
            and receipt.get('complete_forwards') == 11400
            and all(receipt.get(k) is True for k in ('all_inputs_reverified', 'all_memory_reference_hashes_equal', 'all_headroom_checks_passed')),
            'Full child endpoint, workload or verification differs')
        committed = receipt['committed']
        require(len(committed) == 150 and [r['schedule_index'] for r in committed] == list(range(150)), 'Full committed scalar ledger required')
        require({p.name for p in (bundle / folder).glob('state_*.json')} == {'state_%03d.json' % i for i in range(150)}, 'Extra or missing state scalar')
        rows = []
        all_files[folder + '/receipt.json'] = child['receipt_sha256']
        for commit, item in zip(committed, expected):
            check()
            name = 'state_%03d.json' % item['schedule_index']
            require(commit['path'] == name, 'Unexpected scalar path')
            row = read(bundle / folder / name, commit['sha256'])
            gpu = next(g for g in release['gpus'] if g['index'] == seed)
            C.scalar_block(row, item, seed, gpu)
            require(row['artifact_file'] == name.replace('.json', '.npz') and C.digest(row['artifact_sha256']), 'Original numeric artifact descriptor missing')
            rows.append(row); all_files[folder + '/' + name] = commit['sha256']
        require(type(receipt.get('host_peak_rss_kib')) is int and receipt['host_peak_rss_kib'] >= 0
            and receipt.get('host_peak_rss_scope') == 'Linux process lifetime, separately from CUDA allocator observations',
            'Process-lifetime host RSS scope/value required')
        models.append(dict(arm=arm, seed=seed, checkpoint_sha256=model['checkpoint']['sha256'],
            gpu_uuid=receipt['gpu_uuid'], host_peak_rss_kib=receipt['host_peak_rss_kib'],
            host_peak_rss_scope=receipt['host_peak_rss_scope'], **aggregate(rows, C.CASES)))
    lookup = {(m['arm'], m['seed']): m for m in models}
    population, exposure, policy_contrasts = {}, {}, {}
    for policy in C.CASES:
        check()
        population[policy] = {arm: {key: three_seed([lookup[arm, s]['policies'][policy][key] for s in range(3)])
            for key in TIMES + MEMORY} for arm in ('base', 'mix')}
        exposure[policy] = {key: paired([lookup['base', s]['policies'][policy][key] for s in range(3)],
            [lookup['mix', s]['policies'][policy][key] for s in range(3)]) for key in TIMES + MEMORY}
        policy_contrasts[policy] = {arm: {reference: {key: paired(
            [lookup[arm, s]['policies'][reference][key] for s in range(3)],
            [lookup[arm, s]['policies'][policy][key] for s in range(3)]) for key in TIMES + MEMORY}
            for reference in ('base', 'natural_base_reference', 'random25')} for arm in ('base', 'mix')}
    verify_reporting_sources(release)
    return dict(schema='adaptgns_goop2d_validation_cost_summary_v1', status='complete_scalar_summary',
        study_identity=identity, phase='full', coverage=dict(models=6, sources_per_model=30, targets_per_source=5,
        blocks=900, policies_including_natural_reference=7, timed_calls=44100, complete_forwards=68400, failed=0, missing=0),
        scope=dict(split='valid', inference_replayed=False, numeric_arrays_independently_reloaded=False,
            numeric_byte_verification='original completed owner; scalar descriptor chains verified here',
            accuracy_reported=False, autonomous_cost_claim=False, pilot_in_final_estimates=False,
            timings='per-device calls during three-stream shared-host execution; not isolated-host speedups',
            risk='previous observed native-base history, not autonomous cached risk',
            allocator='warm CUDA allocator; reserved memory is process observation, not policy-owned memory',
            aggregation='mean of seven timed repeats, five histories within each trajectory, 30 trajectories within seed; descriptive three-seed mean and sample SD'),
        per_model=models, three_seed_summaries=population, graph_exposure_mix_minus_base=exposure,
        policy_minus_reference=policy_contrasts, input_scalar_sha256=all_files,
        original_closure=closure)


def main():
    p = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    p.add_argument('--execute', action='store_true'); p.add_argument('--bundle', type=Path)
    p.add_argument('--contract', type=Path); p.add_argument('--output', type=Path)
    a = p.parse_args()
    if not a.execute:
        print(json.dumps(dict(status='description_only', requires='complete stopped full phase, 900 scalar blocks, original external closure'))); return
    require(a.bundle and a.contract and a.output and not a.output.exists(), 'Explicit complete input and fresh output required')
    release = read(a.bundle / 'release.json')
    deadline_check(release)
    result = summarize(a.bundle, a.contract, lambda: deadline_check(release))
    with a.output.open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False); stream.write('\n')
    digest = sha(a.output)
    clock = deadline_check(release)
    verify_reporting_sources(release)
    publication = dict(status='summary_published_within_original_clock', summary_sha256=digest,
        live_clock=clock, root_original_external_exit_and_closure_still_required=True)
    with a.output.with_suffix('.publication.json').open('x') as stream:
        json.dump(publication, stream, indent=2, sort_keys=True); stream.write('\n')
    deadline_check(release)
    print(json.dumps(dict(status=result['status'], output=str(a.output), sha256=digest, coverage=result['coverage'])))


if __name__ == '__main__':
    main()
