"""Independent scalar regressions; synthetic fixtures only, no numerical imports."""
import copy
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import goop2d_validation_cost_contract_v2 as C
import measure_goop2d_validation_cost_v2 as M
import test_goop2d_validation_cost_v2 as F


class IndependentCostRegressions(unittest.TestCase):
    def test_serial_owner_verification_is_charged_for_all_six_models(self):
        release = F.release()
        rows = [copy.deepcopy(c['receipt']) for c in F.pilot(release)['children']]
        for i, row in enumerate(rows):
            row.update(setup_seconds=0, finalization_seconds=0,
                       maximum_publication_inclusive_block_seconds=.001,
                       owner_verification_block_seconds=[i + 1] * 15,
                       maximum_owner_verification_block_seconds=i + 1)
        result = C.forecast(rows)
        serial_owner_work = 150 * sum(range(1, 7))
        self.assertGreaterEqual(result['work_seconds'], serial_owner_work,
            'All 900 full-state artifact checks execute in one serial owner; max over seed pairs cannot discard four models of owner work.')

    def test_owner_verification_measurements_cannot_be_omitted(self):
        rows = [copy.deepcopy(c['receipt']) for c in F.pilot(F.release())['children']]
        rows[0].pop('owner_verification_block_seconds')
        with self.assertRaises(ValueError):
            C.forecast(rows)

    def test_same_cuda_uuid_matches_nvidia_smi_prefix(self):
        bare = 'b6685200-7eaf-b46c-89b4-53e8715b8e21'
        self.assertEqual(C.gpu_uuid(bare), C.gpu_uuid('GPU-' + bare))
        self.assertNotEqual(C.gpu_uuid(bare), C.gpu_uuid('GPU-38f0a7dd-8a4a-a461-2de3-747ebc7a73c6'))

    def test_pilot_closure_cannot_gain_time_from_clock_shift_or_reboot(self):
        release = F.release()
        release['clock_origin']['error_bound_seconds'] = 5
        release['pilot_receipt'] = {'path': '/synthetic/pilot.json', 'sha256': 'd' * 64}
        pilot = F.pilot(release)
        for case in ('clock_shift', 'different_boot'):
            with self.subTest(case=case):
                closure = F.closure()
                if case == 'clock_shift':
                    # Wall phase time is599 seconds, monotonic time601;
                    # the allowed two-second wall correction cannot grant time.
                    closure.update(checked_utc='2026-10-06T20:10:39+00:00', checked_host_monotonic_seconds=641)
                else:
                    closure['host_boot_id'] = 'different-boot'
                with self.assertRaises(ValueError):
                    C.capacity_gate(release, pilot, closure, now=C.stamp('2026-10-06T20:11:00+00:00'))

    def test_missing_repeat_proof_or_latency_or_wrong_rng_rejected(self):
        item = C.schedule(F.records(), 'pilot')[0]
        result = F.scalar_fixture(item)
        self.assertTrue(C.scalar_block(result, item, 0, {'cuda_mem_get_info_total_bytes': 1000, 'nvidia_smi_total_memory_mib': 1}))
        changes = [
            lambda x: x['timed_calls'][7].pop('repeat_consistency'),
            lambda x: x['timed_calls'][0]['timing'].pop('current_graph_and_selection_seconds'),
            lambda x: x['random_seed_material'].__setitem__(2, 2),
            lambda x: x['random_seed_material'].__setitem__(3, 1),
        ]
        for index, change in enumerate(changes):
            with self.subTest(index=index):
                bad = copy.deepcopy(result)
                change(bad)
                with self.assertRaises(ValueError):
                    C.scalar_block(bad, item, 0, {'cuda_mem_get_info_total_bytes': 1000, 'nvidia_smi_total_memory_mib': 1})

    def test_memory_pass_rejects_non_cpu_return_or_changed_graph(self):
        for change in ('non_cpu', 'graph'):
            with self.subTest(change=change):
                cuda, evaluator, arrays, row, native = F.memory_fixture()
                original = evaluator.run_policy
                def replaced(*args):
                    result, saved = original(*args)
                    if change == 'non_cpu':
                        saved['prediction'] = object()
                    else:
                        result['graph'] = {'changed': True}
                    return result, saved
                evaluator.run_policy = replaced
                with self.assertRaises(ValueError):
                    M.memory_pass(evaluator, native, SimpleNamespace(cuda=cuda), None, arrays, row, 'synthetic', {'cuda_mem_get_info_total_bytes': 1000, 'nvidia_smi_total_memory_mib': 1})

    def test_reserved_headroom_is_enforced_even_with_small_allocated_peak(self):
        cuda, evaluator, arrays, row, native = F.memory_fixture()
        cuda.max_memory_reserved = lambda device: 950
        with self.assertRaises(ValueError):
            M.memory_pass(evaluator, native, SimpleNamespace(cuda=cuda), None, arrays, row, 'synthetic', {'cuda_mem_get_info_total_bytes': 1000, 'nvidia_smi_total_memory_mib': 1})

    def test_all_cost_helpers_are_stdlib_only_until_execution(self):
        self.assertFalse({'torch', 'numpy', 'scipy'} & set(sys.modules))


if __name__ == '__main__':
    unittest.main(verbosity=2)
