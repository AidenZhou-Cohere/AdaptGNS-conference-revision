#!/usr/bin/env python3
"""Read root staging JSON receipts locally; no remote calls or model/data reads."""
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
CANDIDATE = HERE / 'goop2d_validation_cost_candidate_UNADMITTED_owner_v2r2'
CONSTRUCTION_SHA = 'f30e0ad378aa0322b36cf02fa666c270b5b605c4f74033e21fe9c17cc2070480'


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    require(path.is_file() and not path.is_symlink() and path.suffix == '.json', 'Local JSON receipt required')
    return json.loads(path.read_bytes())


def audit(directory):
    require(sha(CANDIDATE / 'construction.json') == CONSTRUCTION_SHA, 'Reviewed candidate construction changed')
    construction = read(CANDIDATE / 'construction.json')
    for name, digest in construction['output_sha256'].items():
        require(sha(CANDIDATE / name) == digest, 'Reviewed candidate output changed')
    old = read(CANDIDATE / 'pilot_candidate.json')
    mapping = read(CANDIDATE / 'complete_input_map.json')['files_sha256']
    copies = read(CANDIDATE / 'copy_mapping.json')['models']
    resolved = read(directory / 'resolved_pilot_UNADMITTED.json')
    require(set(resolved) == set(old), 'Resolved candidate field set changed')
    for key in set(old) - {'clock_origin', 'initial_staging_utc', 'absolute_stop_utc'}:
        require(old[key] == resolved[key], 'Non-clock candidate field changed: ' + key)
    require(resolved['issued_by'] is None and resolved['status'] == 'UNADMITTED_actual_metadata_candidate', 'Resolved candidate cannot issue pilot authority')
    contract_path = HERE / 'goop2d_validation_cost_contract_v2.py'
    require(sha(contract_path) == resolved['sources'][contract_path.name]['sha256'], 'Contract source changed')
    spec = importlib.util.spec_from_file_location('_resolved_cost_contract', contract_path)
    C = importlib.util.module_from_spec(spec); spec.loader.exec_module(C)
    native = read(directory / 'initial_clock_native.json')
    origin = resolved['clock_origin']
    require(origin == native['clock_origin'] and origin['checked_utc'] == resolved['initial_staging_utc'], 'Original staging clock changed')
    require(native['hostname'] == resolved['hostname'] and native['scientific_processes'] == [] and native['gpu_apps'].strip() == '', 'Staging native/GPU entry not empty')
    require(native['qualification_native_absent'] == {'56878': True, '57161': True}, 'Original property/context probe native closure missing')
    new_sources = {k: v for k, v in resolved['sources'].items() if k in C.NEW_SOURCES}
    staged = {v['path']: v['sha256'] for v in list(new_sources.values()) + list(resolved['reporting_sources'].values()) + [resolved['hardware_memory_evidence']]}
    transferred = [r for r in copies if r['transfer_required_before_pilot']]
    expected_unused = set(staged) | {str(Path(r['actual_B_checkpoint_path']).parent) for r in transferred} | set(resolved['outputs'].values())
    require(set(native['destinations_unused']) == expected_unused and all(native['destinations_unused'].values()), 'Fresh destination entry grid changed')
    observed = {}
    for line in native['gpus'].strip().splitlines():
        i, uuid, name, memory = (s.strip() for s in line.split(','))
        observed[int(i)] = (uuid, name, int(memory))
    require(observed == {g['index']: (g['uuid'], g['name'], g['nvidia_smi_total_memory_mib']) for g in resolved['gpus']}, 'Physical GPU NVIDIA inventory differs')
    for name in ('initial_clock_native', 'source_staging', 'full_input_hashes'):
        require(read(directory / (name + '.external.json'))['exit_code'] == 0, 'Remote staging operation not exited zero: ' + name)
    stage = read(directory / 'source_staging.json')
    require(stage['files'] == staged and len(staged) == 6, 'Exact six new source/evidence byte pins required')
    for row in transferred:
        transfer = read(directory / ('transfer_base_seed%d.json' % row['seed']))
        require(transfer['exit_code'] == 0 and transfer['original'] == row['original_checkpoint_path']
            and transfer['destination'] == row['actual_B_checkpoint_path'] and transfer['expected_sha256'] == row['checkpoint_sha256'], 'Original checkpoint copy receipt differs')
    verified = read(directory / 'full_input_hashes.json')
    require(set(verified['files']) == set(mapping) and len(mapping) == 137, 'Complete source/input byte verification grid differs')
    for path, digest in mapping.items():
        require(verified['files'][path]['sha256'] == digest and type(verified['files'][path]['size_bytes']) is int and verified['files'][path]['size_bytes'] > 0, 'Verified input byte pin/size differs')
    end = verified['clock']
    elapsed = end['host_monotonic_seconds'] - origin['host_monotonic_seconds']
    wall = (C.stamp(end['checked_utc']) - C.stamp(origin['checked_utc'])).total_seconds()
    require(end['host_boot_id'] == origin['host_boot_id'] and 0 <= stage['elapsed_monotonic_seconds'] <= elapsed
        and elapsed == verified['elapsed_monotonic_seconds'] and max(elapsed, wall) + origin['error_bound_seconds'] < 300
        and abs(wall - elapsed) <= origin['error_bound_seconds'], 'Original same-boot 300-second staging budget violated')
    hardware = read(HERE / 'goop2d_memory_context_interface_153302_root_v1.json')
    require(origin['host_boot_id'] == hardware['boot_id'], 'Qualified host boot changed before staging')
    receipt = read(directory / 'staging_receipt.json')
    require(receipt == dict(status='staged_verified_pilot_unadmitted', clock_origin=origin,
        absolute_stop_utc=resolved['absolute_stop_utc'], files=137, model_payloads_deserialized=False, pilot_launched=False), 'Final staging receipt differs')
    require(not (directory / 'late_staging_publication.json').exists(), 'Late staging publication must not admit pilot')
    prospective = copy.deepcopy(resolved)
    prospective.update(issued_by='root', status='admitted_pilot')
    identity = C.validate_release(prospective, 'pilot', now=C.stamp(end['checked_utc']), verify=False)
    return dict(status='passed_local_resolved_staging_receipt_review_only', construction_sha256=CONSTRUCTION_SHA,
        resolved_pilot_sha256=sha(directory / 'resolved_pilot_UNADMITTED.json'), prospective_study_identity=identity,
        reviewed_staging_artifacts={p.name: sha(p) for p in directory.glob('*.json')},
        verified_complete_input_paths=137, transferred_original_base_endpoints=2, staged_new_source_and_hardware_files=6,
        elapsed_staging_seconds=elapsed, wall_elapsed_staging_seconds=wall,
        original_clock=origin, absolute_stop_utc=resolved['absolute_stop_utc'],
        changed_candidate_fields=['clock_origin','initial_staging_utc','absolute_stop_utc'],
        pilot_authority_unset=True, numerical_or_model_payloads_read=False, remote_calls=False,
        execution_admission=False, root_original_outer_exit_and_fresh_native_staging_helper_closure_still_required=True)


def main():
    p = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    p.add_argument('staging_directory', type=Path); p.add_argument('--output', type=Path, required=True)
    a = p.parse_args(); result = audit(a.staging_directory)
    raw = json.dumps(result, sort_keys=True, indent=2, allow_nan=False) + '\n'
    with a.output.open('x') as stream: stream.write(raw)
    print(raw, end='')


if __name__ == '__main__':
    main()
