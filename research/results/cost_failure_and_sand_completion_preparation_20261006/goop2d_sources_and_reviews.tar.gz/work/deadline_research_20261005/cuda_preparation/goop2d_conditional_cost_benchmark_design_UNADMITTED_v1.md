# Prospective Goop-2D cost study: 60-minute decision

Status: **not admitted; source/interface design only**. No model, array, test outcome, remote execution or scientific launch was performed for this assessment.

**Recommendation:** a complete, three-seed validation observed-state cost study is a useful conditional supplement. It is not yet supported by a measured 60-minute capacity bound. Do not promise a complete autonomous-rollout cost/memory study in that window. Preserve Sand/D3 completion and analysis as the first priority.

## What the existing interfaces support

`evaluate_goop_graph_support_final.py` has the frozen final-100k cohort/checkpoint gates, full validation schedule (30 trajectories × targets 7,105,203,301,400), `same_state`, `run_policy`, and seven cyclic timing orders. `run_policy` synchronizes before/after its complete operation and charges previous-observed-base scoring, graph construction/selection, transfers, prediction and returned-output validation. Each state has four parity forwards, eight warmup forwards and 56 timed forwards: 68 total. The standalone score pass is included for `previous-observed-base-risk25`.

The six observed-state policies are base, dense, random25, speed25, relative-velocity-RMS25 and previous-observed-base-risk25; natural_base_reference is an additional timing/construction reference. **Previous-observed-base risk is not the autonomous cached-own-graph laggedrisk25 policy.** The resulting claim must be observed-state deployment cost, not complete-rollout speed or a new accuracy result.

The final CLI supports valid/test, not train, and always covers the complete prescribed validation schedule. The separate `benchmark_goop_graph_support_rollout.py` diagnostic timing CLI is explicitly limited to 512-update infrastructure checkpoints. It cannot be relabelled as a final-100k timing release. The latter's full-rollout interface is also fixed-order operational timing, not balanced repeated policy timing.

Neither frozen Goop-2D interface records per-policy CUDA allocator peaks. A separately reviewed measurement adapter is necessary; leave the frozen files byte-identical. Existing training throughput, shared-host evaluation quotas and gate-label timings do not establish capacity for this workload. The declined action-gate rollout capacity remains declined, with no grid, guard, policy or gate changes.

## Fixed prospective workload

Use the original six faithful 100k endpoints, base/mix × seeds 0,1,2, on **all 30 validation trajectories and all five fixed observed targets**. Validation only satisfies the train/validation-only restriction and avoids creating a new train schedule. There are 900 model-state blocks and 5,400 required policy-state cells, plus 900 natural-base-reference cells. Keep the existing one warmup and seven cyclic timing rounds, input/random material, parity tolerances and failure rules.

The new adapter should call the frozen `same_state` unchanged for latency, then run a separate, untimed-for-latency memory pass through the frozen `run_policy` for each of its seven cases. The memory pass synchronizes, records baseline allocated/reserved bytes, resets peak counters, calls the unchanged operation, synchronizes and records peak allocated/reserved bytes. Release prior returned arrays before the next call and do not retain live GPU tensors between cases. This adds eight forwards per state, giving **76 per state / 68,400 for the full study**. Verify the memory-pass output/graph hashes against the corresponding frozen timing reference. A fresh process per model prevents earlier models' allocator histories from carrying forward.

Report total peak allocated and incremental allocated-over-baseline per call. Reserved memory is a warm-allocator/process observation and can depend on earlier policy calls; do not present it as isolated policy-owned memory. Record process host-RSS high water separately. Do not put cache clearing, telemetry or artifact publication inside the existing latency measurement. Charge those costs to whole-case/whole-study wall time.

Use three seed streams on three separately identified idle B GPUs; each stream processes both arms sequentially on the same GPU. Predeclare arm order base→mix for seeds 0/2 and mix→base for seed 1. The fourth GPU need not be occupied. This pairs hardware within seed. Label timing as the declared three-stream, dedicated-host workload; CPU/I/O contention between benchmark streams remains part of its execution environment. No work may contend with a final queue or require interrupting Sand/D3.

Aggregate repeated calls within state, states within trajectory, trajectories within seed, and then give the three paired seed effects. Report every policy, graph/selection cost, end-to-end cost and memory, with coverage/failures. The reference population is these observed validation states. No best-policy selection, endpoint selection or gate retuning follows the result.

## Measured capacity admission within the same 60-minute clock

Before any pilot, freeze the new adapter, all six checkpoint/source/data hashes, exact full schedule, memory semantics, output paths, three-stream topology and absolute 3,600-second stop. The first stage must verify that B is idle and all required final checkpoints are actually local or charge their transfer/rehash to this clock. Current locality and runtime are not established by this source-only review.

Run a separately authorized pilot on all six endpoints and all seven cases, using the validation trajectories at minimum/lower-median/maximum particle-count ranks, tie-broken by source order, at all five targets: **90 complete state blocks / 6,840 forwards**. Include unchanged parity/warmup/repeats, the memory pass, real publication, setup, rehash and teardown. Use exactly the planned three-stream topology. The pilot is capacity evidence only, excluded from final cost estimates; the full study repeats its complete fixed schedule.

For model m, measure setup a_m, finalization f_m, and the maximum complete publication-inclusive pilot block time c_m. Define `R_m = a_m + 1.35 × 150 × c_m + f_m`, and `W = max_seed(R_base,seed + R_mix,seed)`. The 1.35 allowance is engineering contingency, not a runtime guarantee. Root may admit the full study only after all 90 pilot blocks complete with exact identities, hashes, clean exits/reaps, no guard/timeout/nonfinite/parity/repeat failure, acceptable memory headroom, and

`actual elapsed since initial staging + 60 handoff + W + 90 cleanup + 450 collection/analysis/writeup ≤ 3,600 seconds`.

Cap pilot work at 600 seconds and initial transfer/preflight at 300 seconds; actual spent time is never reset or credited away. Any pilot failure or failed whole-study inequality means **do not launch the full benchmark**. Retain the pilot as failed/incomplete capacity evidence, without reducing seeds, policies, states, repeats or reserves. No autonomous H395 extrapolation is allowed from this pilot.

This path is worthwhile only if its small new measurement adapter and independent equivalence checks are quick to prepare. If strict reuse of existing CLIs alone is required, the requested complete cost **and per-policy memory** study is unavailable; use existing supported timing evidence descriptively and spend the hour on the complete Sand/D3 results instead.
