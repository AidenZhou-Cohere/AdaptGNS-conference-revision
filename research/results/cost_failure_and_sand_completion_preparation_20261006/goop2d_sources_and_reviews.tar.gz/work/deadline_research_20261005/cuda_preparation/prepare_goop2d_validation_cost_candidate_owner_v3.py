#!/usr/bin/env python3
"""Prepare one unadmitted v3 metadata candidate; no remote or scientific access."""
import argparse
import copy
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
PRIOR='goop2d_validation_cost_candidate_UNADMITTED_owner_v2r2'
REPORT='goop2d_validation_cost_source_preparation_UNADMITTED_v3.json'
RELEASE='goop2d_validation_cost_staged_root_v2/pilot_release.json'
FAILURES='goop2d_cost_pilot_failure_20261006_root_v2/collection_inventory.json'
PINS={PRIOR+'/construction.json':'f30e0ad378aa0322b36cf02fa666c270b5b605c4f74033e21fe9c17cc2070480',
      REPORT:'60eceb0dd863d949a5f7642747f7dcbe47134ca47044c906d2d651ea9914519f',
      RELEASE:'9208335e2a0c71049707fa1163b92eaef06f900c889c7283305fa0bf42c5c27f',
      FAILURES:'2a925a27af08d6fa24b7cc8900b4837158a1f6104b56d2152efe10c51f91c8a8',
      'goop2d_cost_pilot_failure_20261006_root_v2/owner_receipt.json':'58c10ec8cb8f541a8cc824f6fc603352160b7a8048159001ea99d8dab2299000',
      'goop2d_validation_cost_v3_instrumentation_amendment_root_v1.md':'5e5d478bb5c8981359daf1b4666731d7a2b68c41875a40f8338ed90c54cf2bf5'}


def require(ok,message):
    if not ok:raise ValueError(message)


def sha(raw):return hashlib.sha256(raw).hexdigest()
def encode(value):return (json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def pointer(*parts):return '/'+'/'.join(str(x).replace('~','~0').replace('/','~1') for x in parts)


def read(name,pin):
    require(Path(name).suffix in ('.json','.md'),'Only metadata is readable')
    raw=(HERE/name).read_bytes();require(sha(raw)==pin,'Pinned metadata changed: '+name)
    return json.loads(raw) if name.endswith('.json') else raw.decode()


def write(path,value):
    raw=encode(value)
    with path.open('xb') as f:f.write(raw)
    return sha(raw)


def assemble(meta,prior):
    result=copy.deepcopy(prior); report=meta[REPORT]; issued=meta[RELEASE]; R=issued['repo']
    require(len(meta[FAILURES]['files'])==13,'Preserve exact original failure inventory')
    new={n:{'path':R+'/cuda_preparation/'+n,'sha256':pin} for n,pin in report['new_sources'].items()}
    extras={key:report[key] for key in ('instrumentation_amendment','prior_failed_owner_receipt')}
    require(set(new)=={'goop2d_validation_cost_contract_v3.py','measure_goop2d_validation_cost_v3.py','supervise_goop2d_validation_cost_v3.py'},'Exact three v3 sources')
    for phase in ('pilot','full'):
        candidate=result[phase+'_candidate']
        require(candidate['models']==issued['models'],'Original six model path/hash/lineage mappings changed')
        for field in ('workload','limits','environment','streams','controls','python','gpus','hardware_memory_evidence','reporting_sources'):
            require(candidate[field]==issued[field],'Frozen prior field changed: '+field)
        candidate.update(schema='adaptgns_goop2d_validation_cost_release_v3',study_id='goop2d_validation_cost_20261006_v3',issued_by=None,
            status='UNADMITTED_actual_metadata_candidate',**copy.deepcopy(extras))
        for field in ('initial_staging_utc','absolute_stop_utc','clock_origin'):candidate[field]=copy.deepcopy(issued[field])
        candidate['limits']['staging_preflight_seconds']=900
        for name,pin in report['v2_source_pins_preserved'].items():
            require(candidate['sources'].pop(name)['sha256']==pin,'Original v2 source changed')
        candidate['sources'].update(copy.deepcopy(new))
        candidate['outputs']={name:R+'/goop2d_validation_cost_'+name+'_20261006_v3' for name in ('pilot','full')}
        notes=candidate['preparation_notes']
        for key in ('all_clock_fields_unset','no_staging_or_clock_started','original_A_base0_base1_require_charged_transfer','source_freeze_precedes_staging_clock'):notes.pop(key,None)
        notes.update(original_clock_already_started_and_all_spent_time_charged=True,all_139_inputs_require_fresh_rehash=True,
            reuse_original_transferred_checkpoint_bytes_without_overwrite=True,prior_v2_permanently_declined=True,
            prior_failure_inventory_preserved_sha256=PINS[FAILURES],no_execution_authority=True)
    pilot=result['pilot_candidate'];full=result['full_candidate']
    full['pilot_receipt']['path']=pilot['outputs']['pilot']+'/owner_receipt.json'
    full['pilot_external_closure']['path']=R+'/cuda_preparation/goop2d_validation_cost_pilot_external_closure_root_v3.json'
    result['external_closure_candidate']['schema']='adaptgns_goop2d_validation_cost_external_closure_v3'
    host=result['host_candidate'];host['schema']='adaptgns_goop2d_validation_cost_host_candidate_v3'
    host['clock_origin']=copy.deepcopy(issued['clock_origin']);host['prior_v2_process_ids_must_be_absent']=[57960,57965,57966,57967]
    host['prior_v2_closure_metadata']={'local_metadata':FAILURES,'sha256':PINS[FAILURES],'fresh_native_check_still_required':True}
    for i,row in enumerate(result['copy_mapping']['models']):
        row['availability_evidence']='Original issued v2 path/hash metadata; existing bytes must be freshly rehashed for v3'
        row['transfer_required_before_pilot']=False
        row['metadata_evidence'].append(dict(metadata_file=RELEASE,metadata_sha256=PINS[RELEASE],json_pointer=pointer('models',i,'checkpoint')))
    result['copy_mapping']['schema']='adaptgns_goop2d_validation_cost_copy_mapping_v3'
    files=result['complete_input_map']['files_sha256'];bindings={r['path']:r for r in result['provenance_bindings']['bindings']}
    for name,pin in report['v2_source_pins_preserved'].items():
        path=R+'/cuda_preparation/'+name;require(files.pop(path)==pin,'Prior input map source changed');bindings.pop(path)
    for name,row in new.items():
        files[row['path']]=row['sha256'];bindings[row['path']]=dict(row,roles=['entry_or_new_source'],metadata_evidence=[dict(metadata_file=REPORT,metadata_sha256=PINS[REPORT],json_pointer=pointer('new_sources',name))])
    for key,row in extras.items():
        require(row['path'] not in files,'History evidence must be a separate path')
        files[row['path']]=row['sha256'];bindings[row['path']]=dict(row,roles=[key],metadata_evidence=[dict(metadata_file=REPORT,metadata_sha256=PINS[REPORT],json_pointer=pointer(key,'sha256'))])
    require(len(files)==len(bindings)==139,'Exact runtime map:137 prior -3 v2 +3 v3 +2 history bindings')
    result['complete_input_map']['files_sha256']=dict(sorted(files.items()))
    result['provenance_bindings']['bindings']=[bindings[k] for k in sorted(bindings)]
    result['provenance_bindings']['input_metadata_sha256'].update(PINS)
    result['provenance_bindings']['preserved_v2_construction_sha256']=PINS[PRIOR+'/construction.json']
    result['provenance_bindings']['preserved_failure_inventory_sha256']=PINS[FAILURES]
    for key in ('complete_input_map','provenance_bindings'):
        result[key]['schema']=result[key]['schema'].removesuffix('_v2')+'_v3'
        result[key]['counts'].update(amendment_and_prior_failure_paths=2,total_distinct_input_paths=139)
    return result


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__,allow_abbrev=False);parser.add_argument('--build',action='store_true');parser.add_argument('--output',type=Path)
    args=parser.parse_args(argv)
    if not args.build:print(json.dumps(dict(status='description_only',execution=False)));return 0
    require(args.output is not None,'Fresh local output required');out=args.output.resolve();require(out.parent==HERE,'Local preparation directory only')
    meta={n:read(n,pin) for n,pin in PINS.items()};construction=meta[PRIOR+'/construction.json']
    prior={Path(name).stem:read(PRIOR+'/'+name,pin) for name,pin in construction['output_sha256'].items()}
    products=assemble(meta,prior)
    for n,pin in PINS.items():read(n,pin)
    out.mkdir(mode=0o700,exist_ok=False)
    hashes={name+'.json':write(out/(name+'.json'),value) for name,value in products.items()}
    record=dict(schema='adaptgns_goop2d_validation_cost_candidate_construction_v3',status='UNADMITTED_metadata_only_complete',authority=None,
        builder_sha256=sha(Path(__file__).read_bytes()),input_metadata_sha256=PINS,output_sha256=hashes,counts=products['complete_input_map']['counts'],
        preserved_prior_construction_sha256=PINS[PRIOR+'/construction.json'],original_clock_already_started=True,clock_reset=False,
        initial_staging_utc=products['pilot_candidate']['initial_staging_utc'],absolute_stop_utc=products['pilot_candidate']['absolute_stop_utc'],
        payloads_read=False,remote_calls=False,staging_performed=False,launch_performed=False)
    pin=write(out/'construction.json',record);print(json.dumps(dict(output=str(out),construction_sha256=pin,counts=record['counts']),indent=2));return 0


if __name__=='__main__':raise SystemExit(main())
