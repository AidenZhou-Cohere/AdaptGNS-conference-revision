# Goop2D validation cost and allocator-memory supplement

Status: source preparation only, **UNADMITTED**. This package does not authorize staging, a pilot, a full run, retries or a reduced workload. Frozen scientific sources remain unchanged. All preparation tests use only synthetic CPU objects and temporary scalar files; no model, array, test outcome or remote execution is part of preparation.

## Fixed scope and scientific interface

The study uses the original faithful base/mix × seeds 0/1/2 cohort at exactly 100,000 updates. Every model covers all 30 validation trajectories at targets 7, 105, 203, 301 and 400: 150 histories per model and 900 complete model-state blocks. Every block includes base, dense, random25, speed25, relative-velocity-RMS25 and previous-observed-base-risk25, plus the natural-base timing reference. The risk policy uses the **previous observed native-base history**; this is not an autonomous cached-own-graph rollout measurement.

`measure_goop2d_validation_cost_v1.py` calls the frozen `same_state` function once per block, unchanged. That preserves both native parity checks, one warmup round and seven balanced cyclic timing rounds. The frozen operation synchronizes its timing and charges graph construction, selection, transfer, prediction, output validation and the separate previous-base scoring forward. A separate allocator-memory pass calls the frozen `run_policy` unchanged in the first timed cyclic order. It compares every returned graph/selection/prediction/risk array hash, including previous-base scoring arrays and physical scores, with the first timed reference. There are 68 frozen forwards and eight memory-pass forwards per block: 76 total, or 68,400 for the full study.

The frozen `same_state` still reads validation targets and computes its original diagnostics after timed inference. This supplement omits accuracy estimates from its published scalar rows and does not use them for endpoint choice, policy selection or retuning. It does not invoke the old final evaluation CLI or repeat its full autonomous evaluation schedule.

Memory is CUDA allocator memory: total peak allocated, allocated increment over the pre-call baseline, and reserved memory observations. Reserved memory is explicitly a warm-allocator/process observation, not isolated policy-owned memory. Each model runs in a fresh process. Returned reference arrays are numeric CPU arrays; memory-pass output arrays are released before the next case. No cache clearing, telemetry or serialization enters frozen latency intervals. Host peak RSS is a separate Linux process-lifetime observation, not per-policy CPU memory. No autonomous rollout memory claim follows.

All four B GPUs must be idle at entry. Three fixed streams use physical GPUs 0/1/2 for seeds 0/1/2; seed 0 and 2 run base then mix, and seed 1 runs mix then base. Both arms of a seed use the same UUID, sequentially, in fresh processes. The fourth GPU stays idle. Runtime UUID comparisons normalize the optional `GPU-` prefix while retaining raw CUDA and nvidia-smi forms. Before admission, root must establish that nvidia-smi integer-MiB total memory and CUDA's total agree within the adapter's explicit one-MiB bound; this has not been measured by this preparation. A mismatch declines execution rather than changing the memory rule mid-study.

## Immutable source and input bindings

The contract binds the three new source files, five frozen entry/helper files, original cohort/audit, training admission/protocol, validation manifest/admission/structural report, metadata and acquisition/context/auxiliary evidence. Frozen helpers independently verify their numerical source closure and actual validation bytes. All inputs are reverified before successful completion.

Each model has two explicit paths: `original_checkpoint_path` is the unchanged path in the original frozen cohort; `checkpoint.path` is the actual locally available identical-byte copy. The selected SHA must equal the original all-six cohort and endpoint audit. The original checkpoint payload lineage and exact simulator restore are verified through the frozen helper. A copied original-A model is never represented as B training or a new cohort.

The UNADMITTED templates use planning-only B locality metadata from `aquamarine_idle_locality_1522_root_v1.json`. They retain original B seed-2 paths, propose existing gate-copy paths for original A mix seeds 0/1, and prospective fresh copy paths for original A base seeds 0/1. **No current bytes or locality are admitted by those templates.** Root must freshly rehash all six and charge any transfer to the study clock after source freeze. The copied base paths are planned destinations, not claims that copies already exist.

## One clock, two separate admissions

At the beginning of actual staging, freeze root UTC, host `time.monotonic()` and `/proc/sys/kernel/random/boot_id`, with a clock error bound no larger than five seconds. The absolute stop is exactly 3,600 seconds after that original UTC and no later than the original research cutoff. Both phases bind the same study fingerprint, original monotonic origin and boot identity. An owner rejects reboot or wall/monotonic disagreement. Clock uncertainty is charged, not credited. Source preparation precedes this staging clock; transfer and fresh byte verification do not.

Root may issue the pilot release only after independent source review and fresh host/source/input checks. Initial staging and preflight must fit 300 seconds from the original origin. The pilot uses min/lower-median/max validation particle-count ranks, ties broken by original source order, and all five targets on every endpoint: 90 blocks/6,840 forwards. Original full schedule indices, random material and cyclic ordering are preserved. The pilot has a 600-second bound including 90 seconds reserved for cleanup/publication. The full workload is never launched automatically by pilot completion.

For every model m, record setup `a_m`, maximum complete publication-inclusive child block `c_m`, fixed finalization `f_m`, and maximum owner artifact-verification block `v_m`. The owner independently verifies every scalar grid and every referenced numeric artifact hash. Owner verification is serialized across all six models, so the conservative forecast is:

`W = max_seed(sum_arms(a_m + 1.35 × 150 × c_m + f_m)) + 1.35 × 150 × sum_all_six(v_m)`.

This deliberately charges the entire serialized owner verification workload even where it overlaps a running child. It avoids treating the 15-block pilot verification sweep as a fixed cost for 150 full blocks. The 1.35 multiplier is engineering contingency, not a runtime guarantee.

Root must collect the original pilot session's zero exit, all child zero exits/reaps with no signals, owner/child native absence and empty GPU state. The external closure binds the owner receipt SHA, boot identity and host monotonic sample. Publication, owner exit and native closure must fit the same exact 600-second pilot interval; a backward wall-clock correction cannot hide late closure.

Only then may root issue a separate full release with the same study fingerprint. Full admission and actual owner entry must satisfy:

`elapsed since original staging + clock error + 60 handoff + W + 90 cleanup + 450 collection/analysis ≤ 3,600`.

The full owner uses the original monotonic endpoint and cannot replenish spent time. Any pilot, parity, nonfinite, graph guard, repeat, memory, source-identity, process-identity, timeout or capacity failure declines the full workload. Keep failed/incomplete evidence and all existing outputs. Do not shorten seeds, policies, histories, repeats or reserves. Pilot observations are excluded from final cost estimates; a successful full phase repeats the complete 150-history schedule per model.

## Operational receipts and collection

The owner registers each successful `Popen` immediately, recording PID/argv/owner before fallible capture. It uses exact direct-child identity and pidfds for cleanup, retries a failed capture only while the unreaped exact child still matches, and never signals a foreign PID, process name or process group. File verification checks deadlines and periodically reaps/inspects peers. Cleanup reserves are shared across children. Checked candidate/final publication returns nonzero and preserves a failed-publication receipt if it crosses a boundary.

The owner provides `owner_started.json`, child logs/identity ledger, per-child protocol/progress/state JSON and numeric references, per-child receipt and `owner_receipt.json`. `owner_receipt_candidate.json` alone is never completion evidence. Root must bind the final receipt to the original owner session exit and fresh native absence; collection is read-only. Incomplete runs cannot be converted into a full cost estimate by selecting the completed rows.

After a complete full phase, aggregate the existing seven repeated latency calls within state, the five states within trajectory, trajectories within seed, and retain all three paired seed effects. Report all policies and the natural-base reference, graph/selection/scoring/end-to-end latency, allocated memory and warm reserved memory, full coverage and failures. The population is the declared observed validation histories. Collection, analysis and writeup remain inside the reserved 450 seconds and original 3,600-second clock.

## Prepared files

- `goop2d_validation_cost_contract_v1.py`: stdlib source/input/workload/clock/receipt/capacity contract.
- `measure_goop2d_validation_cost_v1.py`: validation-only frozen timing calls and separate memory pass.
- `supervise_goop2d_validation_cost_v1.py`: explicitly released three-stream phase owner.
- `test_goop2d_validation_cost_v1.py`: safe synthetic tests; no numerical imports or OS children.
- `goop2d_validation_cost_pilot_release_UNADMITTED_v1.json` and `goop2d_validation_cost_full_release_UNADMITTED_v1.json`: metadata candidates with deliberately missing root clock/admission fields.
- `goop2d_validation_cost_external_closure_UNADMITTED_v1.json`: root closure interface, not actual evidence.

Every executable defaults to description only. No launch command was run during preparation.
