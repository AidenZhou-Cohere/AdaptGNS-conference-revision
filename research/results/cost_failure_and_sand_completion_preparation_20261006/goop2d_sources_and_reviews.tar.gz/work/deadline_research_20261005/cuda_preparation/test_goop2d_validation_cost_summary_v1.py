"""Synthetic aggregation checks; no numerical imports, remote calls or models."""
import copy
import math
import unittest
import summarize_goop2d_validation_cost_v1 as S


def rows():
    result = []
    for source in range(30):
        for j, target in enumerate((7, 105, 203, 301, 400)):
            calls = [dict(method='base', round=r, timing={key: source * 100 + j * 10 + r for key in S.TIMES}) for r in range(7)]
            memory = dict(method='base', **{key: 1000 + source * 100 + j * 10 for key in S.MEMORY})
            result.append(dict(source_index=source, target_frame=target, schedule_index=source * 5 + j,
                trajectory_id='trajectory%d' % source, timed_calls=calls, memory=[memory]))
    return result


class Aggregation(unittest.TestCase):
    def test_closed_form_nested_means(self):
        value = S.aggregate(rows(), ('base',))
        self.assertEqual(value['policies']['base']['end_to_end_seconds'], 1473.0)
        self.assertEqual(value['trajectories'][3]['policies']['base']['end_to_end_seconds'], 323.0)
        self.assertEqual(value['policies']['base']['peak_allocated_bytes'], 2470.0)
        self.assertEqual(value['maximum_observed_memory']['base']['peak_allocated_bytes'], 3940)

    def test_reordering_is_invariant(self):
        original = rows()
        self.assertEqual(S.aggregate(original, ('base',)), S.aggregate(list(reversed(original)), ('base',)))

    def test_missing_duplicate_or_wrong_target_rejected(self):
        original = rows()
        variants = [original[:-1], original + original[:1], original[:-1] + original[:1]]
        bad = copy.deepcopy(original); bad[0]['target_frame'] = 8; variants.append(bad)
        for bad in variants:
            with self.subTest(length=len(bad)), self.assertRaises(ValueError):
                S.aggregate(bad, ('base',))

    def test_bad_repeat_and_memory_rejected(self):
        for kind in ('missing', 'duplicate', 'nan', 'memory'):
            bad = rows()
            if kind == 'missing': bad[0]['timed_calls'].pop()
            if kind == 'duplicate': bad[0]['timed_calls'][0]['round'] = 1
            if kind == 'nan': bad[0]['timed_calls'][0]['timing'][S.TIMES[0]] = math.nan
            if kind == 'memory': bad[0]['memory'].append(bad[0]['memory'][0])
            with self.subTest(kind=kind), self.assertRaises(ValueError): S.aggregate(bad, ('base',))

    def test_percent_change_is_seed_paired(self):
        value = S.paired([1, 10, 100], [2, 10, 50])
        self.assertEqual(value['paired_percent_change']['seed_values'], [100, 0, -50])
        self.assertAlmostEqual(value['paired_percent_change']['mean'], 50 / 3)
        self.assertEqual(value['difference_second_minus_first']['seed_values'], [1, 0, -50])
        self.assertNotAlmostEqual(value['paired_percent_change']['mean'], 100 * (62 - 111) / 111)

    def test_zero_denominator_preserved(self):
        value = S.paired([0, 1, 2], [1, 2, 3])
        self.assertEqual(value['difference_second_minus_first']['seed_values'], [1, 1, 1])
        self.assertIsNone(value['paired_percent_change']['mean'])
        self.assertEqual(value['paired_percent_change']['seed_values'], [None, 100, 50])

    def test_sample_sd_and_all_seed_requirement(self):
        self.assertEqual(S.three_seed([1, 2, 3]), dict(seed_values=[1, 2, 3], mean=2, sample_sd=1, n_seeds=3))
        with self.assertRaises(ValueError): S.three_seed([1, 2])


if __name__ == '__main__':
    unittest.main()
