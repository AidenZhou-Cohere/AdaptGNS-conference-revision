#!/usr/bin/env python3
"""Derive an unadmitted v2 candidate from pinned v1/scalar metadata only."""
import argparse
import copy
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
PRIOR='goop2d_validation_cost_candidate_UNADMITTED_owner_v1'
PINS={
 PRIOR+'/construction.json':'f47620ab072909abb80b2736e15d8cfa2144cee5a4f4aca6f8aab01d5db0bce2',
 'goop2d_validation_cost_source_preparation_UNADMITTED_v2.json':'1620ec27089edd3e47c6a820b719649ea27debc755a930e08d7d2a77c02dbce2',
 'goop2d_memory_context_interface_153302_root_v1.json':'17c30900e3b7742fa9d1bfd215a7dbd6a35a2b40c61304bab11e76756f909653',
 'goop2d_validation_cost_v2_independent_review_code_audit_v1.json':'e5c2501e9bdcb4e0adde924a48ed608d798cb503696d04672a52fd2c7769e804',
}


def require(value,message):
    if not value:raise ValueError(message)


def sha(raw):return hashlib.sha256(raw).hexdigest()
def encode(value):return (json.dumps(value,sort_keys=True,indent=2,allow_nan=False)+'\n').encode()
def pointer(*parts):return '/'+'/'.join(str(x).replace('~','~0').replace('/','~1') for x in parts)


def load(name,pin):
    require(Path(name).suffix=='.json','Only JSON metadata is readable')
    raw=(HERE/name).read_bytes();require(sha(raw)==pin,'Metadata pin changed: '+name)
    return json.loads(raw)


def write(path,value):
    raw=encode(value)
    with path.open('xb') as stream:stream.write(raw)
    return sha(raw)


def assemble(meta,prior):
    report_name='goop2d_validation_cost_source_preparation_UNADMITTED_v2.json'
    evidence_name='goop2d_memory_context_interface_153302_root_v1.json'
    report=meta[report_name];hardware=meta[evidence_name]
    result=copy.deepcopy(prior)
    pilot=result['pilot_candidate'];full=result['full_candidate'];R=pilot['repo']
    require(hardware['host']==pilot['hostname'] and hardware['models_data_or_benchmark_loaded'] is False
            and hardware['pre_gpu_apps']=='','Actual API evidence host/scope differs')
    new_sources={name:{'path':R+'/cuda_preparation/'+name,'sha256':pin} for name,pin in report['new_sources'].items()}
    reporting={name:{'path':R+'/cuda_preparation/'+name,'sha256':pin} for name,pin in report['reporting_sources'].items()}
    require(set(new_sources)=={'goop2d_validation_cost_contract_v2.py','measure_goop2d_validation_cost_v2.py','supervise_goop2d_validation_cost_v2.py'},'Exact v2 source set required')
    require(set(reporting)=={'summarize_goop2d_validation_cost_v1.py','collect_goop2d_validation_cost_scalars_v1.py'},'Exact reporting source set required')
    gpu_rows=[]
    for old in pilot['gpus']:
        rows=[r for r in hardware['devices'] if r['index']==old['index']]
        require(len(rows)==1,'Exactly one qualified context row per GPU required');row=rows[0]
        require(row['nvidia_uuid']==old['uuid'] and row['cuda_uuid']==old['uuid'].removeprefix('GPU-')
                and row['name']==old['name'] and row['nvidia_total_integer_mib']*1048576==old['total_memory_bytes'],
                'Original physical GPU NVIDIA identity differs')
        require(type(row['cuda_mem_get_info_total_bytes']) is int and row['cuda_mem_get_info_total_bytes']>0,
                'Exact positive context API value required')
        gpu_rows.append(dict(index=old['index'],uuid=old['uuid'],name=old['name'],
            nvidia_smi_total_memory_mib=row['nvidia_total_integer_mib'],cuda_mem_get_info_total_bytes=row['cuda_mem_get_info_total_bytes']))
    hardware_binding=dict(path=R+'/cuda_preparation/'+evidence_name,sha256=PINS[evidence_name])
    for candidate in (pilot,full):
        require(candidate['issued_by'] is None and set(candidate['clock_origin'].values())=={None},'Prior candidate authority/clock must remain null')
        candidate['schema']='adaptgns_goop2d_validation_cost_release_v2'
        candidate['study_id']='goop2d_validation_cost_20261006_v2'
        for name in list(candidate['sources']):
            if name in report['v1_source_pins_preserved']:
                require(candidate['sources'][name]['sha256']==report['v1_source_pins_preserved'][name],'V1 source pin provenance differs')
                del candidate['sources'][name]
        candidate['sources'].update(new_sources)
        candidate['reporting_sources']=reporting
        candidate['hardware_memory_evidence']=hardware_binding
        candidate['gpus']=gpu_rows
        candidate['outputs']={phase:R+'/goop2d_validation_cost_'+phase+'_20261006_v2' for phase in ('pilot','full')}
        candidate['preparation_notes'].update(v1_sources_candidates_and_qualification_failures_preserved=True,
            separate_exact_api_pins=True,device_property_total_is_not_context_denominator=True,
            reporting_sources_separately_bound=True)
        candidate['preparation_notes'].pop('device_memory_equivalence_requires_current_scalar_evidence',None)
        candidate['preparation_notes']['separate_api_pins_require_fresh_runtime_verification']=True
    full['pilot_receipt']['path']=pilot['outputs']['pilot']+'/owner_receipt.json'
    full['pilot_external_closure']['path']=R+'/cuda_preparation/goop2d_validation_cost_pilot_external_closure_root_v2.json'
    result['external_closure_candidate']['schema']='adaptgns_goop2d_validation_cost_external_closure_v2'
    native=result['host_candidate'];native['gpus']=gpu_rows
    native['schema']='adaptgns_goop2d_validation_cost_host_candidate_v2'
    native.pop('cuda_memory_total_compatibility_verified',None)
    native.update(hardware_memory_evidence=hardware_binding,separate_api_pins_from_existing_qualification_metadata=True,
        device_properties_total_bytes_preserved_in_qualification=True,current_native_state_or_bytes_verified=False)

    input_map=result['complete_input_map']['files_sha256']
    bindings={row['path']:row for row in result['provenance_bindings']['bindings']}
    def proof(name,*parts):return dict(metadata_file=name,metadata_sha256=PINS[name],json_pointer=pointer(*parts))
    for name,pin in report['v1_source_pins_preserved'].items():
        path=R+'/cuda_preparation/'+name
        require(input_map.pop(path)==pin,'Prior input-map source differs');bindings.pop(path)
    for role,group,key in (('entry_or_new_source',new_sources,'new_sources'),('reporting_source',reporting,'reporting_sources')):
        for name,row in group.items():
            require(row['path'] not in input_map,'New version must not alias an existing source path')
            input_map[row['path']]=row['sha256']
            bindings[row['path']]=dict(row,roles=[role],metadata_evidence=[proof(report_name,key,name)])
    require(hardware_binding['path'] not in input_map,'Hardware evidence path unexpectedly occupied')
    input_map[hardware_binding['path']]=hardware_binding['sha256']
    bindings[hardware_binding['path']]=dict(hardware_binding,roles=['hardware_memory_qualification'],
        metadata_evidence=[proof(report_name,'hardware_memory_evidence','sha256')])
    result['complete_input_map']['files_sha256']=dict(sorted(input_map.items()))
    result['provenance_bindings']['bindings']=[bindings[p] for p in sorted(bindings)]
    for key in ('complete_input_map','provenance_bindings'):
        result[key]['schema']=result[key]['schema'].removesuffix('_v1')+'_v2'
        result[key]['counts'].update(reporting_source_paths=2,hardware_memory_qualification_paths=1,total_distinct_input_paths=137)
    result['provenance_bindings']['input_metadata_sha256'].update(PINS)
    result['provenance_bindings']['preserved_v1_construction_sha256']=PINS[PRIOR+'/construction.json']
    require(len(input_map)==len(bindings)==137,'Exact v2 map expected: old134 minus3 old sources plus3 new +2 reporting +1 hardware')
    require(pilot['models']==prior['pilot_candidate']['models'] and full['models']==pilot['models'],'Endpoint mappings must not change')
    for field in ('workload','limits','environment','streams','controls','python'):
        require(pilot[field]==prior['pilot_candidate'][field] and full[field]==pilot[field],'Scientific/grid/runtime field changed: '+field)
    require(not any('/test' in path or '/train/' in path for path in input_map),'No test or training array paths allowed')
    return result


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__,allow_abbrev=False);p.add_argument('--build',action='store_true');p.add_argument('--output',type=Path)
    args=p.parse_args(argv)
    if not args.build:print(json.dumps(dict(status='description_only',execution=False)));return 0
    require(args.output is not None,'Fresh local output required');out=args.output.resolve();require(out.parent==HERE,'Local preparation output only')
    meta={name:load(name,pin) for name,pin in PINS.items()}
    construction=meta[PRIOR+'/construction.json']
    prior={Path(name).stem:load(PRIOR+'/'+name,pin) for name,pin in construction['output_sha256'].items() if name.endswith('.json')}
    products=assemble(meta,prior)
    # Snapshot all metadata before writing. No remote/checkpoint/array access.
    for name,pin in PINS.items():load(name,pin)
    out.mkdir(mode=0o700,exist_ok=False)
    hashes={name+'.json':write(out/(name+'.json'),value) for name,value in products.items()}
    record=dict(schema='adaptgns_goop2d_validation_cost_candidate_construction_v2',status='UNADMITTED_metadata_only_complete',
        builder_sha256=sha(Path(__file__).read_bytes()),input_metadata_sha256=PINS,output_sha256=hashes,
        counts=products['complete_input_map']['counts'],preserved_prior_construction_sha256=PINS[PRIOR+'/construction.json'],
        authority=None,clock_started=False,payloads_read=False,remote_calls=False,staging_performed=False,launch_performed=False)
    d=write(out/'construction.json',record)
    print(json.dumps(dict(output=str(out),construction_sha256=d,counts=record['counts']),indent=2));return 0


if __name__=='__main__':raise SystemExit(main())
