#!/usr/bin/env python3
"""Preliminary B-host CUDA memory metadata only; inert unless --execute.

Root owns invocation and post-exit native closure. This does not admit either
benchmark phase, read model/data payloads, or begin the3600-second staging clock.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time

EXPECTED_HOST = 'aidenzhou-aquamarine-toad-75-6d8b45c98d-mgjlq'
EXPECTED_PYTHON = '/root/repos/AdaptGNS-cuda-20261006/.venv/bin/python'
EXPECTED_UUIDS = (
    '37c3dfdb-9027-e3cb-c899-b0a12f130b52',
    '3b22d55b-8f80-cc77-5a6f-f9181f3286c4',
    '89b83aa8-f20b-dd13-811c-5f54165eb865',
    '28475341-1f76-1575-5aaf-bb8616bc1052',
)
EXPECTED_NVIDIA_MEMORY_MIB = 189471
MIB = 1048576


def require(value, message):
    if not value:
        raise ValueError(message)


def utc():
    return datetime.now(timezone.utc).isoformat()


def gpu_uuid(value):
    value = str(value).lower()
    return value[4:] if value.startswith('gpu-') else value


def nvidia(query):
    result = subprocess.run(['nvidia-smi', query, '--format=csv,noheader,nounits'],
                            capture_output=True, text=True, timeout=10, check=True)
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def process_inventory():
    """Retain exact Python/scientific argv plus all process executable identities.

    The raw inventory is private operational evidence, not a publication asset.
    Root decides exclusivity; this observer grants no native-process authority.
    """
    rows = []
    for path in sorted(Path('/proc').iterdir()):
        if not path.name.isdecimal():
            continue
        try:
            stat = (path / 'stat').read_text().rsplit(')', 1)[1].split()
            executable = os.readlink(path / 'exe')
            argv = [x.decode(errors='surrogateescape') for x in (path / 'cmdline').read_bytes().split(b'\0') if x]
            stat_after = (path / 'stat').read_text().rsplit(')', 1)[1].split()
            if stat[19] != stat_after[19]:
                continue
            row = {'pid': int(path.name), 'ppid': int(stat[1]), 'start_ticks': int(stat[19]),
                   'state': stat[0], 'executable': executable}
            if 'python' in Path(executable).name.lower() or any(x.endswith('.py') for x in argv):
                row['argv'] = argv
            rows.append(row)
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue
    return rows


def check_memory_rows(nvidia_rows, cuda_rows):
    require(len(nvidia_rows) == len(cuda_rows) == 4, 'All four physical GPUs required')
    result = []
    for index, (nv, cu) in enumerate(zip(nvidia_rows, cuda_rows)):
        require(nv['index'] == cu['index'] == index and gpu_uuid(nv['uuid']) == gpu_uuid(cu['uuid']) == EXPECTED_UUIDS[index],
                'Physical GPU index or UUID differs')
        require('GB200' in nv['name'] and 'GB200' in cu['name'], 'Expected GB200 device name')
        require(nv['memory_total_mib'] == EXPECTED_NVIDIA_MEMORY_MIB, 'Known B nvidia-smi memory identity differs')
        lower = nv['memory_total_mib'] * MIB
        total = cu['memory_total_bytes']
        require(type(total) is int and lower <= total < lower + MIB,
                'CUDA/nvidia-smi total memory fails the existing adapter one-MiB rule')
        require(type(cu['memory_free_bytes']) is int and 0 <= cu['memory_free_bytes'] <= total,
                'Invalid CUDA free-memory metadata')
        result.append({'index': index, 'canonical_uuid': EXPECTED_UUIDS[index], 'nvidia': nv, 'cuda': cu,
                       'cuda_minus_nvidia_total_bytes': total - lower, 'existing_memory_identity_rule_passed': True})
    return result


def inspect():
    require(socket.gethostname() == EXPECTED_HOST, 'This check is specific to the known B host')
    require(sys.executable == EXPECTED_PYTHON, 'Use the known lexical B virtual-environment interpreter')
    require(os.environ.get('CUDA_VISIBLE_DEVICES') in (None, ''), 'Physical GPU indices must not be remapped')
    before = nvidia('--query-compute-apps=pid,gpu_uuid,used_memory')
    require(before == [], 'GPU applications exist; do not initialize metadata contexts on a busy host')
    raw = nvidia('--query-gpu=index,uuid,name,memory.total')
    nv = []
    for line in raw:
        index, uuid, name, memory = [x.strip() for x in line.split(',')]
        nv.append({'index': int(index), 'uuid': uuid, 'name': name, 'memory_total_mib': int(memory)})
    nv.sort(key=lambda row: row['index'])
    native_before = process_inventory()
    import torch  # Root-only metadata execution; never model construction or tensors.
    require(str(torch.__version__) == '2.13.0+cu129' and torch.version.cuda == '12.9', 'Expected frozen CUDA stack')
    require(torch.cuda.is_available() and torch.cuda.device_count() == 4, 'All four CUDA devices required')
    cuda_rows = []
    for index in range(4):
        props = torch.cuda.get_device_properties(index)
        free, total = torch.cuda.mem_get_info(index)
        cuda_rows.append({'index': index, 'uuid': str(props.uuid), 'name': props.name,
                          'properties_total_memory_bytes': int(props.total_memory),
                          'memory_free_bytes': int(free), 'memory_total_bytes': int(total)})
    memory = check_memory_rows(nv, cuda_rows)
    active = nvidia('--query-compute-apps=pid,gpu_uuid,used_memory')
    require(all(int(line.split(',')[0].strip()) == os.getpid() for line in active), 'Foreign GPU process appeared during metadata inspection')
    return {'status': 'memory_metadata_compatible_root_native_review_still_required', 'hostname': EXPECTED_HOST,
            'observer_pid': os.getpid(), 'python_lexical_path': sys.executable, 'python_resolved_path': str(Path(sys.executable).resolve()),
            'python_sha256': hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
            'torch': str(torch.__version__), 'cuda': torch.version.cuda,
            'host_boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
            'checked_host_monotonic_seconds': time.monotonic(), 'checked_utc': utc(),
            'gpu_apps_before': before, 'gpu_apps_during_metadata_contexts': active,
            'memory': memory, 'native_inventory_before': native_before,
            'no_tensor_allocation_requested': True, 'no_checkpoint_or_dataset_access': True,
            'staging_clock_started': False, 'pilot_or_full_admitted': False,
            'root_post_exit_native_and_gpu_absence_required': True}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args(argv)
    if not args.execute:
        print(json.dumps({'status': 'description_only', 'execute': False, 'gpu_contexts_created': False,
                          'root_only_scope': 'preliminary CUDA total-memory and native metadata; no experiment authority'}))
        return 0
    try:
        result = inspect()
    except BaseException as error:
        print(json.dumps({'status': 'metadata_check_failed', 'error_type': type(error).__name__, 'error': str(error),
                          'observer_pid': os.getpid(), 'ended_utc': utc(), 'pilot_or_full_admitted': False,
                          'root_post_exit_native_and_gpu_absence_required': True}))
        return 1
    print(json.dumps(result, allow_nan=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
