import os,json,socket,subprocess,datetime,pathlib,time
apps=lambda:subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,process_name','--format=csv,noheader,nounits'],text=True,timeout=15)
before=apps();assert not before.strip(),before
rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,name,memory.total','--format=csv,noheader,nounits'],text=True,timeout=15)
import torch
out=[]
for line in rows.strip().splitlines():
 idx,uuid,name,total=[x.strip() for x in line.split(',')];idx=int(idx);p=torch.cuda.get_device_properties(idx);nbytes=int(total)*1048576
 with torch.cuda.device(idx):
  free,context_total=torch.cuda.mem_get_info(idx)
 out.append({'index':idx,'nvidia_uuid':uuid,'cuda_uuid':str(p.uuid),'name':p.name,'cuda_device_properties_total_bytes':p.total_memory,'cuda_mem_get_info_total_bytes':context_total,'cuda_mem_get_info_free_bytes':free,'nvidia_total_integer_mib':int(total),'nvidia_integer_mib_as_bytes':nbytes,'v1_actual_memory_pass_predicate':nbytes<=context_total<nbytes+1048576})
print(json.dumps({'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'host':socket.gethostname(),'pid':os.getpid(),'boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'monotonic':time.monotonic(),'torch':torch.__version__,'cuda':torch.version.cuda,'devices':out,'pre_gpu_apps':before,'post_context_gpu_apps':apps(),'models_data_or_benchmark_loaded':False}))
