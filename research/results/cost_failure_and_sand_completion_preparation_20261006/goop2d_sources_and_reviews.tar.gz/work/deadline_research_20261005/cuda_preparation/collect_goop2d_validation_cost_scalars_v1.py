#!/usr/bin/env python3
"""Copy complete stopped cost-study JSON bytes to a fresh scalar bundle.

No model/data/NPZ is read. Originals and unsuccessful phases remain untouched.
The root closure must come from the original external session and native check.
The separate summary verifies all scalar ledgers before reporting cost results.
"""
import argparse
import hashlib
import json
from pathlib import Path
import summarize_goop2d_validation_cost_v1 as S


def require(ok, message):
    if not ok:
        raise ValueError(message)


def raw_file(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'Missing or linked scalar file: ' + str(path))
    raw = path.read_bytes()
    json.loads(raw)
    return raw


def collect(release_path, owner_path, closure_path, output):
    release_path, owner_path, closure_path, output = map(Path, (release_path, owner_path, closure_path, output))
    release_raw, owner_raw, closure_raw = map(raw_file, (release_path, owner_path, closure_path))
    release, owner, closure = map(json.loads, (release_raw, owner_raw, closure_raw))
    S.verify_reporting_sources(release)
    S.deadline_check(release)
    require(release.get('phase') == 'full' and release.get('status') == 'admitted_full'
        and release.get('issued_by') == 'root', 'Separately admitted full phase required')
    original_root = Path(release['outputs']['full'])
    require(owner_path == original_root / 'owner_receipt.json'
        and owner.get('phase') == 'full' and owner.get('status') == 'complete'
        and owner.get('release_sha256') == hashlib.sha256(release_raw).hexdigest()
        and owner.get('failure') is None and owner.get('all_children_reaped') is True
        and owner.get('final_gpu_processes') == [], 'Original complete full owner required')
    require(closure.get('issued_by') == 'root'
        and closure.get('schema') == 'adaptgns_goop2d_validation_cost_full_external_closure_v1'
        and closure.get('status') == 'original_session_exit_and_native_absence_verified'
        and closure.get('owner_receipt_sha256') == hashlib.sha256(owner_raw).hexdigest()
        and closure.get('original_session_exit_code') == 0
        and closure.get('owner_native_absent') is True and closure.get('all_children_native_absent') is True
        and closure.get('gpu_processes') == [], 'Original external exit/native closure required')
    children = owner.get('children', [])
    require(len(children) == 6 and {(c['arm'], c['seed']) for c in children}
        == {(a, s) for a in ('base', 'mix') for s in range(3)}, 'Whole six-model cohort required')
    output = output.resolve()
    protected = [original_root.resolve(), release_path.resolve().parent, closure_path.resolve().parent]
    require(not output.exists() and all(output != p and output not in p.parents and p not in output.parents for p in protected),
        'Fresh output outside original controls/results required')
    output.mkdir(parents=True)
    inventory = {}

    def copy(path, name, expected=None):
        S.deadline_check(release)
        raw = raw_file(path); digest = hashlib.sha256(raw).hexdigest()
        require(expected is None or digest == expected, 'Original scalar changed: ' + str(path))
        destination = output / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as stream:
            stream.write(raw)
        inventory[name] = dict(original_path=str(path), sha256=digest, size_bytes=len(raw))
        S.deadline_check(release)

    copy(release_path, 'release.json', hashlib.sha256(release_raw).hexdigest())
    copy(owner_path, 'owner_receipt.json', hashlib.sha256(owner_raw).hexdigest())
    copy(closure_path, 'external_closure.json', hashlib.sha256(closure_raw).hexdigest())
    copy(release['controls']['manifest']['path'], 'valid_manifest.json', release['controls']['manifest']['sha256'])
    for child in sorted(children, key=lambda c: (c['arm'], c['seed'])):
        folder = 'seed%d_%s' % (child['seed'], child['arm'])
        source = original_root / folder
        require(child.get('output') == str(source) and child.get('verified') is True
            and child.get('reaped') is True and child.get('exit_code') == 0 and child.get('signals') == [],
            'Complete original child path/lifecycle required')
        require(not source.is_symlink() and source.is_dir(), 'Original child directory missing or linked')
        receipt = json.loads(raw_file(source / 'receipt.json'))
        require(receipt.get('blocks') == 150 and len(receipt.get('committed', [])) == 150,
            'Complete scalar ledger required')
        expected = {r['path']: r['sha256'] for r in receipt['committed']}
        require(set(expected) == {'state_%03d.json' % i for i in range(150)}, 'Complete unique state grid required')
        expected['receipt.json'] = child['receipt_sha256']
        for p in sorted(source.glob('*.json')):
            copy(p, folder + '/' + p.name, expected.get(p.name))
        require(set(expected) <= {p.name for p in (output / folder).glob('*.json')}, 'Original scalar absent during collection')
    result = dict(schema='adaptgns_goop2d_validation_cost_scalar_collection_v1',
        status='complete_scalar_copy_pending_summary', phase='full', files=inventory,
        numeric_payloads_read=False, checkpoint_or_dataset_payloads_read=False,
        complete_numeric_validation_scope='original stopped owner; this collector copies exact JSON bytes')
    with (output / 'collection_manifest.json').open('x') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, allow_nan=False); stream.write('\n')
    S.deadline_check(release)
    S.verify_reporting_sources(release)
    return result


def main():
    p = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    p.add_argument('--execute', action='store_true'); p.add_argument('--release', type=Path)
    p.add_argument('--owner-receipt', type=Path); p.add_argument('--external-closure', type=Path)
    p.add_argument('--output', type=Path)
    a = p.parse_args()
    if not a.execute:
        print(json.dumps(dict(status='description_only', numerical_or_payload_access=False))); return
    require(a.release and a.owner_receipt and a.external_closure and a.output, 'Explicit complete arguments required')
    result = collect(a.release, a.owner_receipt, a.external_closure, a.output)
    print(json.dumps(dict(status=result['status'], output=str(a.output), files=len(result['files']))))


if __name__ == '__main__':
    main()
