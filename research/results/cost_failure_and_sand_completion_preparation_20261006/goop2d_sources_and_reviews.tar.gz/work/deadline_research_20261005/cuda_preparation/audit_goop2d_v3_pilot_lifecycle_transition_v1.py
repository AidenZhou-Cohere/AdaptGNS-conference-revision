#!/usr/bin/env python3
"""Local JSON-only v3 pilot lifecycle audit; never launches or authorizes work.

Default invocation is inert. --audit takes a local input manifest with release,
owner_started, owner_receipt, external_exit, native_closure, and optional
children, launcher_log, publication_failure, assessment_utc. The collection
directory containing owner_receipt is used to bind raw child receipt bytes.
No benchmark modules, models or numeric artifacts are loaded.
"""
import argparse
import datetime as dt
import hashlib
import json
import math
from pathlib import Path

ORIGIN = dict(checked_utc='2026-10-06T15:42:19.395876+00:00',
              error_bound_seconds=5, host_boot_id='3d254b4e-ede4-492f-839a-5f16b6f3d1b3',
              host_monotonic_seconds=5349886.185545305)
LIMITS = dict(cleanup_seconds=90, collection_analysis_seconds=450,
              forecast_multiplier=1.35, handoff_seconds=60, pilot_seconds=600,
              staging_preflight_seconds=900, whole_seconds=3600)
PAIRS = {(a, s) for a in ('base', 'mix') for s in range(3)}
ARMS = (('base', 'mix'), ('mix', 'base'), ('base', 'mix'))
IDENTITY_KEYS = ('pid', 'ppid', 'start_ticks', 'argv', 'executable')
STUDY_KEYS = ('study_id', 'repo', 'hostname', 'python', 'sources', 'controls', 'models', 'streams',
              'gpus', 'hardware_memory_evidence', 'instrumentation_amendment', 'prior_failed_owner_receipt',
              'reporting_sources', 'outputs', 'initial_staging_utc', 'absolute_stop_utc',
              'clock_origin', 'workload', 'limits', 'environment')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def finite(value, positive=False):
    return type(value) in (int, float) and math.isfinite(value) and (value > 0 if positive else value >= 0)


def stamp(value):
    result = dt.datetime.fromisoformat(value.replace('Z', '+00:00'))
    require(result.tzinfo is not None, 'Timezone is required')
    return result


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def stable(row):
    return {k: row[k] for k in IDENTITY_KEYS}


def measured_forecast(rows, elapsed):
    """Independent arithmetic only. Caller must establish original completion.

    Owner verification is serialized across all six models, outside max(stream).
    This function creates neither an execution release nor launch authority.
    """
    require(len(rows) == 6 and {(r['arm'], r['seed']) for r in rows} == PAIRS, 'Six unique models required')
    require(finite(elapsed), 'Invalid elapsed time')
    streams, verification = [0.0] * 3, 0.0
    for row in rows:
        require(row.get('status') == 'complete' and row.get('phase') == 'pilot'
                and row.get('blocks') == 15 and row.get('complete_forwards') == 1140,
                'Incomplete pilot row')
        require(all(row.get(k) is True for k in ('all_inputs_reverified', 'all_memory_reference_hashes_equal',
                                                'all_headroom_checks_passed')), 'Missing child proof flag')
        child_times = row.get('publication_inclusive_block_seconds', [])
        owner_times = row.get('owner_verification_block_seconds', [])
        require(len(child_times) == len(owner_times) == 15 and all(finite(x, True) for x in child_times)
                and all(finite(x) for x in owner_times), 'Missing or invalid measured rates')
        require(row.get('maximum_publication_inclusive_block_seconds') == max(child_times)
                and row.get('maximum_owner_verification_block_seconds') == max(owner_times), 'Maximum rate mismatch')
        a, f = row.get('setup_seconds'), row.get('finalization_seconds')
        require(finite(a) and finite(f), 'Invalid setup/finalization')
        streams[row['seed']] += a + 1.35 * 150 * max(child_times) + f
        verification += 1.35 * 150 * max(owner_times)
    work = max(streams) + verification
    required = elapsed + 5 + 60 + work + 90 + 450
    return dict(per_seed_stream_seconds=streams, serial_owner_verification_seconds=work-max(streams),
                work_seconds=work, required_whole_seconds=required,
                remaining_margin_seconds=3600-required, arithmetic_fits=required <= 3600,
                formula='max_seed(sum_arms(setup + 1.35*150*max_child_block + enriched_finalization)) + 1.35*150*sum_all_six(max_owner_verification)',
                authority=False)


def audit(spec):
    evidence, warnings = [], []

    def read(key, required=True):
        value = spec.get(key)
        if not value:
            require(not required, 'Missing ' + key)
            return None
        path = Path(value).resolve()
        require(path.suffix == '.json', 'Only local JSON evidence is accepted')
        raw = path.read_bytes()
        evidence.append(dict(role=key, path=str(path), sha256=digest(raw), size_bytes=len(raw)))
        return json.loads(raw)

    release = read('release')
    started = read('owner_started')
    owner = read('owner_receipt')
    exit_record = read('external_exit')
    closure = read('native_closure')
    startup_children = read('children', False)
    publication_failure = read('publication_failure', False)
    release_hash = evidence[0]['sha256']
    require(release['schema'] == 'adaptgns_goop2d_validation_cost_release_v3'
            and release['phase'] == 'pilot' and release['status'] == 'admitted_pilot', 'Not the original v3 pilot release')
    require(release['clock_origin'] == ORIGIN and release['initial_staging_utc'] == ORIGIN['checked_utc']
            and release['limits'] == LIMITS, 'Original clock or limits changed')
    require((stamp(release['absolute_stop_utc'])-stamp(ORIGIN['checked_utc'])).total_seconds() == 3600,
            'Whole-study stop changed')
    study = digest((json.dumps({k: release[k] for k in STUDY_KEYS}, sort_keys=True, indent=2, allow_nan=False)+'\n').encode())
    for record in (started, owner):
        require(record.get('schema') == 'adaptgns_goop2d_validation_cost_owner_v3'
                and record.get('phase') == 'pilot' and record.get('study_identity') == study
                and record.get('release_sha256') == release_hash
                and record.get('initial_staging_utc') == release['initial_staging_utc']
                and record.get('absolute_stop_utc') == release['absolute_stop_utc'], 'Owner/release identity mismatch')
    require(owner.get('clock_origin') == ORIGIN, 'Owner clock changed')
    identity = started['owner_identity']
    pid = started['owner_pid']
    require(type(pid) is int and pid > 0 and owner['owner_pid'] == identity['pid'] == pid
            and type(identity['start_ticks']) is int and identity['start_ticks'] > 0, 'Invalid owner identity')
    command = [release['python']['lexical_path'], release['sources']['supervise_goop2d_validation_cost_v3.py']['path'],
               '--execute', '--release', exit_record['remote_release_path']]
    require(identity['argv'] == command and identity['executable'] == release['python']['resolved_path'], 'Owner command mismatch')
    require(exit_record.get('release_sha256') == release_hash and type(exit_record.get('exit_code')) is int,
            'Original external exit not bound')
    stamp(exit_record['observed_utc'])  # Local clock; intentionally no remote-clock ordering assertion.
    if spec.get('launcher_log'):
        path = Path(spec['launcher_log']).resolve()
        raw = path.read_bytes()
        launch = json.loads(raw.splitlines()[0])
        evidence.append(dict(role='launcher_log', path=str(path), sha256=digest(raw), size_bytes=len(raw)))
        require(launch['pid'] == pid and launch['start_ticks'] == identity['start_ticks']
                and launch['argv'] == command and launch['release_sha256'] == release_hash, 'Launcher identity mismatch')

    children = owner.get('children', [])
    require(isinstance(children, list) and len(children) <= 6, 'Invalid child ledger')
    pairs = [(c['arm'], c['seed']) for c in children]
    require(len(set(pairs)) == len(pairs) and set(pairs) <= PAIRS, 'Duplicate/invalid child pair')
    pids = [pid] + [c['pid'] for c in children]
    require(all(type(p) is int and p > 0 for p in pids) and len(set(pids)) == len(pids), 'Duplicate/invalid PID')
    require(closure.get('host_boot_id') == ORIGIN['host_boot_id'], 'Closure is on another boot')
    require(all(closure.get('native_absent', {}).get(str(p)) is True for p in pids), 'Explicit PID absence missing')
    require(closure.get('gpu_apps') in ('', []) and closure.get('processes', []) == [], 'Native/GPU closure not clean')
    terminal, native_time = owner.get('completed_monotonic'), closure.get('host_monotonic_seconds')
    phase = owner.get('phase_started_monotonic')
    require(finite(terminal) and finite(native_time) and ORIGIN['host_monotonic_seconds'] <= terminal <= native_time,
            'Invalid native closure chronology')
    wall_elapsed = (stamp(closure['checked_utc'])-stamp(ORIGIN['checked_utc'])).total_seconds()
    require(abs(wall_elapsed-(native_time-ORIGIN['host_monotonic_seconds'])) <= 5, 'Closure clock disagreement')
    require(stamp(owner['completed_utc']) <= stamp(closure['checked_utc']), 'Remote terminal/closure chronology invalid')
    if phase is not None:
        require(finite(phase) and ORIGIN['host_monotonic_seconds'] <= phase <= terminal, 'Invalid phase origin')
        require(phase-ORIGIN['host_monotonic_seconds'] < 895, 'Pilot entered after original staging cutoff')
    else:
        require(owner.get('status') == 'failed' and children == [], 'No phase origin for launched work')
    require(owner.get('all_children_reaped') is True and owner.get('final_gpu_processes') == [], 'Owner cleanup not closed')
    require(owner.get('full_launch_authorized_by_pilot') is False and owner.get('no_retry_or_subset_authorized') is True,
            'Pilot unexpectedly claims execution authority')
    for child in children:
        require(child.get('registered') is True and child.get('reaped') is True and type(child.get('exit_code')) is int,
                'Registered child was not reaped')
        require(child['owner_pid'] == pid and child['release_sha256'] == release_hash, 'Child owner/release mismatch')
        require(finite(child.get('launched_monotonic')) and finite(child.get('reaped_monotonic'))
                and phase <= child['launched_monotonic'] <= child['reaped_monotonic'] <= terminal, 'Invalid child chronology')
        seed, arm = child['seed'], child['arm']
        require(child['gpu_uuid'] == release['streams'][seed]['gpu_uuid'], 'Wrong physical GPU')
        actual_command = child.get('command', [])
        require(len(actual_command) == 11, 'Invalid child command length')
        expected_command = [release['python']['lexical_path'], release['sources']['measure_goop2d_validation_cost_v3.py']['path'],
                            '--execute', '--release', exit_record['remote_release_path'], '--arm', arm,
                            '--seed', str(seed), '--work-stop-utc', actual_command[-1]]
        require(actual_command == expected_command, 'Child command differs from released arm/seed/source')
        require(stamp(actual_command[-1]) <= stamp(release['absolute_stop_utc'])-dt.timedelta(seconds=540),
                'Child work stop exceeds original reserve')
        child_identity = child.get('identity')
        if child_identity is None:
            warnings.append('PID %s has incomplete captured identity evidence' % child['pid'])
        else:
            require(child_identity['pid'] == child['pid'] and child_identity['ppid'] == pid
                    and type(child_identity['start_ticks']) is int and child_identity['start_ticks'] > 0
                    and child_identity['argv'] == child['command']
                    and child_identity['executable'] == child['expected_executable'] == release['python']['resolved_path'],
                    'Child identity mismatch')
        for event in child.get('signals', []):
            require(child_identity is not None and stable(event['identity']) == stable(child_identity), 'Signal identity mismatch')
        warnings.extend('PID %s: %s' % (child['pid'], e) for e in child.get('cleanup_errors', []))
        if arm == ARMS[seed][1]:
            first = next((c for c in children if (c['arm'], c['seed']) == (ARMS[seed][0], seed)), None)
            require(first is not None and first.get('verified') is True
                    and first['reaped_monotonic'] <= child['launched_monotonic'], 'Counterpart launched before verified reap')
            require(first['launched_monotonic']+first['receipt']['observed_child_wall_seconds'] <= child['launched_monotonic'],
                    'Counterpart launched before recorded verification window')
    if startup_children is not None:
        final = {c['pid']: c for c in children}
        for initial in startup_children:
            require(initial['pid'] in final, 'Startup child missing from terminal ledger')
            current = final[initial['pid']]
            for key in ('pid', 'arm', 'seed', 'command', 'owner_pid', 'gpu_uuid', 'launched_monotonic', 'identity'):
                require(initial.get(key) == current.get(key), 'Startup identity changed: ' + key)
        if any(c.get('reaped') is not True for c in startup_children):
            warnings.append('children.json is a startup/intermediate ledger; terminal owner records establish reaps')
    attached_blocks = sum(c.get('receipt', {}).get('blocks', 0) for c in children)
    require(owner.get('observed_complete_blocks') == attached_blocks, 'Owner attached-receipt block count mismatch')
    status = owner.get('status')
    forecast = None
    if status == 'failed':
        require(owner.get('failure') is not None and exit_record['exit_code'] != 0 and owner.get('capacity_gate') is None,
                'Contradictory failed-pilot evidence')
        classification = 'failed_pilot_closed_no_cost_result_no_full_admission'
    else:
        require(status == 'complete' and owner.get('failure') is None and exit_record['exit_code'] == 0
                and publication_failure is None and len(children) == 6 and set(pairs) == PAIRS and attached_blocks == 90,
                'Original complete pilot not established')
        require(phase is not None and terminal-phase < 600 and native_time-phase <= 600
                and finite(owner.get('whole_phase_seconds')) and owner['whole_phase_seconds'] <= 600,
                'Pilot publication/native closure exceeds phase budget')
        rows = []
        collection = Path(spec['owner_receipt']).resolve().parent
        for child in children:
            require(child.get('verified') is True and child['exit_code'] == 0 and child.get('signals') == []
                    and child.get('identity') is not None and not child.get('cleanup_errors'), 'Unaccepted child result')
            raw_path = collection / ('seed%d_%s' % (child['seed'], child['arm'])) / 'receipt.json'
            raw_bytes = raw_path.read_bytes()
            require(digest(raw_bytes) == child['receipt_sha256'], 'Original child bytes changed')
            evidence.append(dict(role='raw_child_receipt', path=str(raw_path), sha256=digest(raw_bytes), size_bytes=len(raw_bytes)))
            raw, row = json.loads(raw_bytes), child['receipt']
            require(all(row.get(k) == v for k, v in raw.items() if k != 'finalization_seconds'), 'Owner changed raw child receipt fields')
            require(row.get('raw_receipt_finalization_seconds') == raw['finalization_seconds'], 'Raw finalization binding changed')
            measured = raw['setup_seconds']+sum(raw['publication_inclusive_block_seconds'])+raw['finalization_seconds']
            enriched = raw['finalization_seconds']+max(0, row['observed_child_wall_seconds']-measured-sum(row['owner_verification_block_seconds']))
            require(row['finalization_seconds'] == enriched, 'Incorrect owner finalization enrichment')
            require((row['arm'], row['seed']) == (child['arm'], child['seed']) and row['study_identity'] == study
                    and row['release_sha256'] == release_hash and row['gpu_uuid'] == child['gpu_uuid'], 'Child receipt binding changed')
            rows.append(row)
        assessed = stamp(spec['assessment_utc'])
        require(assessed >= stamp(closure['checked_utc']), 'Assessment predates closure')
        forecast = measured_forecast(rows, (assessed-stamp(ORIGIN['checked_utc'])).total_seconds())
        forecast['assessment_utc'] = assessed.isoformat()
        classification = 'complete_lifecycle_and_capacity_arithmetic_only_requires_separate_scientific_review'
    # The historical closure is only evidence for the exact collected bytes.
    # Hash every listed text file; opaque NPZ entries remain uninspected metadata.
    collection = Path(spec['owner_receipt']).resolve().parent
    inventory = closure.get('files')
    require(isinstance(inventory, dict), 'Closure collection file inventory is required')
    for role, name in (('owner_receipt','owner_receipt.json'), ('owner_started','owner_started.json'), ('children','children.json')):
        if spec.get(role):
            bound = next(e for e in evidence if e['role'] == role)
            require(name in inventory and bound['sha256'] == inventory[name]['sha256']
                    and bound['size_bytes'] == inventory[name]['size_bytes'], 'Historical closure bytes differ: '+role)
    for name, item in sorted(inventory.items()):
        path = (collection/name).resolve()
        require(path.is_relative_to(collection) and path.suffix in ('.json','.log','.txt'), 'Invalid collected text path')
        raw_bytes = path.read_bytes()
        require(digest(raw_bytes) == item['sha256'] and len(raw_bytes) == item['size_bytes'], 'Collected bytes changed: '+name)
        evidence.append(dict(role='collected_text', path=str(path), sha256=digest(raw_bytes), size_bytes=len(raw_bytes)))
    if 'owner_publication_failed.json' in inventory or (collection/'owner_publication_failed.json').exists():
        require(status == 'failed', 'A publication failure marker prevents completion')
        warnings.append('Terminal publication failure marker is retained')
    return dict(schema='adaptgns_goop2d_v3_pilot_lifecycle_audit_transition_v1', status=classification,
                evidence=evidence, owner_pid=pid, owner_start_ticks=identity['start_ticks'], failure=owner.get('failure'),
                external_exit=exit_record, children=[{k:c.get(k) for k in ('pid','arm','seed','identity','exit_code','reaped',
                    'verified','signals','cleanup_errors','launched_monotonic','reaped_monotonic')} for c in children],
                clock=dict(original=ORIGIN, phase_started_monotonic=phase, completed_monotonic=terminal,
                    closure_monotonic=native_time, closure_utc=closure['checked_utc'],
                    original_to_phase_seconds=None if phase is None else phase-ORIGIN['host_monotonic_seconds'],
                    phase_to_terminal_seconds=None if phase is None else terminal-phase,
                    phase_to_closure_seconds=None if phase is None else native_time-phase,
                    original_to_closure_seconds=native_time-ORIGIN['host_monotonic_seconds']),
                warnings=warnings, observed_owner_attached_complete_blocks=attached_blocks,
                forecast=forecast, execution_authority=False, scientific_results_admitted=False,
                evidence_limits=['Local exit timestamp is not ordered against remote wall clock.',
                    'Owner attached-receipt count does not count every raw inference or published state.',
                    'Native closure is a historical observation, not a guarantee about future host activity.',
                    'No models, arrays or NPZ artifacts were loaded; separate scalar/provenance review is required.',
                    'Tool session identity is supplied by the root transcript, not by exit JSON.'])


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__, allow_abbrev=False)
    parser.add_argument('--audit', type=Path)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args(argv)
    if args.audit is None:
        print(json.dumps(dict(status='description_only', local_json_only=True, execution_authority=False)))
        return 0
    result = audit(json.loads(args.audit.read_bytes()))
    encoded = json.dumps(result, indent=2, sort_keys=True, allow_nan=False)+'\n'
    if args.output:
        with args.output.open('x') as stream:
            stream.write(encoded)
    else:
        print(encoded, end='')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
