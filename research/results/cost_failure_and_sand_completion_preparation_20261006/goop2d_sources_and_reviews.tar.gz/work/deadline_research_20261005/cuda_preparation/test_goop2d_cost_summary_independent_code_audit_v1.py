"""Independent cost-summary arithmetic and completeness tests; synthetic scalars only."""
import copy
from pathlib import Path
import sys
import unittest

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import summarize_goop2d_validation_cost_v1 as S

CASES = ('base', 'dense', 'random25', 'speed25', 'relative-velocity-RMS25',
         'previous-observed-base-risk25', 'natural_base_reference')
TARGETS = (7, 105, 203, 301, 400)


def scalar_rows():
    rows = []
    for source in range(30):
        for t_index, target in enumerate(TARGETS):
            timing = []
            memory = []
            for p_index, policy in enumerate(CASES):
                for repetition in range(7):
                    value = 1 + source + t_index + repetition + 100 * p_index
                    timing.append(dict(method=policy, round=repetition,
                        timing={key: value for key in S.TIMES}))
                memory.append(dict(method=policy, **{key: 1 + source + t_index + 100 * p_index for key in S.MEMORY}))
            rows.append(dict(schedule_index=source * 5 + t_index, source_index=source,
                trajectory_id='trajectory_%02d' % source, target_frame=target,
                timed_calls=timing, memory=memory))
    return rows


class SummaryIndependentTests(unittest.TestCase):
    def test_explicit_three_level_mean_and_memory_extreme(self):
        result = S.aggregate(scalar_rows(), CASES)
        self.assertEqual(len(result['trajectories']), 30)
        for p_index, policy in enumerate(CASES):
            self.assertEqual(result['policies'][policy]['end_to_end_seconds'], 20.5 + 100 * p_index)
            self.assertEqual(result['policies'][policy]['peak_allocated_bytes'], 17.5 + 100 * p_index)
            self.assertEqual(result['maximum_observed_memory'][policy]['peak_allocated_bytes'], 34 + 100 * p_index)
            self.assertEqual(result['trajectories'][0]['policies'][policy]['end_to_end_seconds'], 6 + 100 * p_index)

    def test_complete_grid_repeat_and_trajectory_identity_required(self):
        mutations = {
            'missing_state': lambda rows: rows.pop(),
            'duplicate_state': lambda rows: rows.__setitem__(1, copy.deepcopy(rows[0])),
            'wrong_target': lambda rows: rows[0].__setitem__('target_frame', 6),
            'duplicate_schedule': lambda rows: rows[1].__setitem__('schedule_index', 0),
            'trajectory_identity_changed': lambda rows: rows[0].__setitem__('trajectory_id', 'wrong'),
            'missing_repeat': lambda rows: rows[0]['timed_calls'].pop(),
            'duplicate_repeat': lambda rows: rows[0]['timed_calls'][1].__setitem__('round', 0),
            'missing_memory': lambda rows: rows[0]['memory'].pop(),
        }
        for name, mutation in mutations.items():
            with self.subTest(name=name):
                rows = scalar_rows(); mutation(rows)
                with self.assertRaises(ValueError):
                    S.aggregate(rows, CASES)

    def test_paired_percent_effect_computed_within_seed(self):
        result = S.paired([1, 2, 4], [2, 2, 2])
        difference = result['difference_second_minus_first']
        percent = result['paired_percent_change']
        self.assertEqual(difference['seed_values'], [1, 0, -2])
        self.assertAlmostEqual(difference['mean'], -1 / 3)
        self.assertEqual(difference['n_seeds'], 3)
        self.assertEqual(percent['seed_values'], [100, 0, -50])
        self.assertAlmostEqual(percent['mean'], 50 / 3)

    def test_zero_denominator_is_undefined_without_dropping_seed(self):
        result = S.paired([0, 2, 4], [2, 2, 2])
        percent = result['paired_percent_change']
        self.assertEqual(percent['seed_values'], [None, 0, -50])
        self.assertIsNone(percent['mean'])
        self.assertIsNone(percent['sample_sd'])
        self.assertEqual(len(result['difference_second_minus_first']['seed_values']), 3)

    def test_nonfinite_or_incomplete_seed_summary_rejected(self):
        for values in ([1, 2], [1, 2, float('nan')], [1, 2, float('inf')], [1, 2, True]):
            with self.subTest(values=values):
                with self.assertRaises(ValueError):
                    S.three_seed(values)

    def test_no_numerical_imports(self):
        self.assertFalse({'torch', 'numpy', 'scipy'} & set(sys.modules))


if __name__ == '__main__':
    unittest.main(verbosity=2)
