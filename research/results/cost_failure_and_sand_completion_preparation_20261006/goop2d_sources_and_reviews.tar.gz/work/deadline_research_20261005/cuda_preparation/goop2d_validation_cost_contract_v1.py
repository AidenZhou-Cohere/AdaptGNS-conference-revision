#!/usr/bin/env python3
"""Stdlib-only contract for the separate Goop2D validation cost supplement.

Importing this module reads no data, imports no numerical package and launches
nothing. A root pilot release is not a full-study release.
"""
from datetime import datetime, timedelta, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import sys

SCHEMA = 'adaptgns_goop2d_validation_cost_release_v1'
CHILD_SCHEMA = 'adaptgns_goop2d_validation_cost_child_v1'
OWNER_SCHEMA = 'adaptgns_goop2d_validation_cost_owner_v1'
POLICIES = ('base', 'dense', 'random25', 'speed25', 'relative-velocity-RMS25', 'previous-observed-base-risk25')
CASES = POLICIES + ('natural_base_reference',)
TARGETS = (7, 105, 203, 301, 400)
ARMS = {0: ('base', 'mix'), 1: ('mix', 'base'), 2: ('base', 'mix')}
CONTROL_NAMES = ('cohort', 'cohort_audit', 'train_admission', 'protocol', 'manifest', 'admission',
                 'structural_report', 'acquisition_report', 'context_semantics', 'auxiliary_report', 'metadata')
NEW_SOURCES = ('goop2d_validation_cost_contract_v1.py', 'measure_goop2d_validation_cost_v1.py',
               'supervise_goop2d_validation_cost_v1.py')
FROZEN = {
    'evaluate_goop_graph_support_final.py': 'cd970e04012930d896b31944271ccaf7da2b0881f22fe2f903533a8d5911dc6d',
    'benchmark_goop_graph_support_rollout.py': '2e0ef0b84635c8430102cd797648d24cec14b457e1df900eb784d5e167966f8f',
    'goop_evaluation_contract.py': '4ee1e33dbe666804d1827b88565620a435d04836a170671914a71acb818be090',
    'train_goop_graph_support_cuda.py': 'dd9ef01a16116f04a578bbfe9ed01774e66fdc08d60b913072a33ad211b319c1',
    'sand_graph_support_policy.py': '4a1db45f742043ba261c06273c1538fa0195dfb7f203423510b9a353c5ddb03a',
}
WORKLOAD = dict(split='valid', endpoints=6, updates=100000, trajectories=30, targets=list(TARGETS),
                histories_per_model=150, full_blocks=900, pilot_blocks=90, policies=list(POLICIES),
                timing_reference=CASES[-1], warmup_rounds=1, timed_rounds=7,
                forwards_per_complete_block=76, pilot_forwards=6840, full_forwards=68400,
                memory_order='same frozen cyclic order at round_index=0',
                memory_baseline='warm allocator after unchanged same_state; no empty_cache',
                peak_allocated_fraction_limit=0.90, headroom_bytes_minimum=0,
                full_rollout_claim=False, accuracy_results_published=False,
                target_diagnostics_computed_by_frozen_same_state=True, pilot_in_final_estimates=False)
LIMITS = dict(whole_seconds=3600, staging_preflight_seconds=300, pilot_seconds=600,
              handoff_seconds=60, cleanup_seconds=90, collection_analysis_seconds=450,
              forecast_multiplier=1.35)
THREAD_ENV = {k: '2' for k in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
                              'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS')}
ENV = dict(THREAD_ENV, CUBLAS_WORKSPACE_CONFIG=':4096:8', PYTHONDONTWRITEBYTECODE='1')
RESEARCH_STOP = datetime(2026, 10, 7, 1, tzinfo=timezone.utc)


def require(value, message):
    if not value:
        raise ValueError(message)


def utc():
    return datetime.now(timezone.utc)


def stamp(value):
    result = datetime.fromisoformat(value)
    require(result.tzinfo is not None, 'Timezone-aware clock required')
    return result.astimezone(timezone.utc)


def finite(value, positive=False):
    return type(value) in (int, float) and math.isfinite(value) and (value > 0 if positive else value >= 0)


def digest(value):
    return isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def gpu_uuid(value):
    require(isinstance(value, str) and value, 'GPU UUID required')
    return value.removeprefix('GPU-').lower()


def encode(value):
    return (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode()


def canonical(value):
    return hashlib.sha256(encode(value)).hexdigest()


def sha(path, check=lambda: None):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        while True:
            check()
            block = stream.read(1 << 20)
            if not block:
                break
            h.update(block)
    check()
    return h.hexdigest()


def write(path, value, check=lambda: None):
    check()
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('xb') as stream:
        raw = encode(value)
        for offset in range(0, len(raw), 1 << 20):
            check(); stream.write(raw[offset:offset + (1 << 20)])
        stream.flush(); os.fsync(stream.fileno()); check()
    temporary.replace(path)
    check()
    return sha(path, check)


def absolute(path):
    p = Path(path)
    require(p.is_absolute() and str(p) == str(p.resolve()), 'Canonical absolute path required: ' + str(p))
    return p


def binding(value, check=lambda: None):
    require(isinstance(value, dict) and set(value) == {'path', 'sha256'} and digest(value['sha256']), 'Exact path/SHA binding required')
    p = absolute(value['path'])
    require(p.is_file() and not p.is_symlink() and sha(p, check) == value['sha256'], 'Bound bytes differ: ' + str(p))
    return p


def read_bound(value, check=lambda: None):
    p = binding(value, check)
    raw = p.read_bytes()
    require(hashlib.sha256(raw).hexdigest() == value['sha256'], 'Bound JSON changed during read')
    return json.loads(raw)


def verify_files(files, check=lambda: None):
    for p, expected in files.items():
        require(digest(expected) and sha(p, check) == expected, 'Input/source changed: ' + str(p))


def load_source(path, pin, label):
    require(sha(path) == pin, 'Source changed before import')
    spec = importlib.util.spec_from_file_location(label, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    require(sha(path) == pin, 'Source changed during import')
    return mod


def schedule(records, phase):
    require(phase in ('pilot', 'full') and len(records) == 30, 'All 30 validation descriptors required')
    require(len({r['id'] for r in records}) == 30, 'Duplicate trajectory identity')
    for i, row in enumerate(records):
        shape = row['positions']['shape']
        require(row['source_index'] == i and len(shape) == 3 and shape[0] == 401 and shape[2] == 2
                and type(shape[1]) is int and shape[1] > 0, 'Invalid frozen validation descriptor')
    selected = set(range(30))
    if phase == 'pilot':
        ranked = sorted(range(30), key=lambda i: (records[i]['positions']['shape'][1], i))
        selected = {ranked[0], ranked[14], ranked[29]}
        require(len(selected) == 3, 'Pilot rank identities must be distinct')
    # Preserve the original full schedule_index in the pilot: RNG and cyclic
    # order match the same full-study state, never a compressed pilot index.
    return [dict(schedule_index=i * 5 + j, source_index=i, trajectory_id=r['id'], target_frame=target)
            for i, r in enumerate(records) if i in selected for j, target in enumerate(TARGETS)]


def study_identity(release):
    keys = ('study_id', 'repo', 'hostname', 'python', 'sources', 'controls', 'models', 'streams',
            'gpus', 'outputs', 'initial_staging_utc', 'absolute_stop_utc', 'clock_origin', 'workload', 'limits', 'environment')
    return canonical({k: release[k] for k in keys})


def scalar_block(result, item, seed):
    """Independent scalar receipt coverage/hash checks; no numerical imports."""
    require(all(result.get(k) == v for k, v in item.items()) and result.get('status') == 'complete'
            and result.get('failure') is None and result.get('complete_forwards') == 76,
            'State receipt identity/completion differs')
    require(type(seed) is int and seed in range(3) and result.get('random_seed_material') ==
            [20261006, 93000, seed, 0, item['source_index'], item['target_frame']], 'Exact paired-seed validation RNG material required')
    policies = result.get('policies', {})
    require(set(policies) == set(CASES) and all(p.get('status') == 'complete' and p.get('repeat_consistent') is True
            and p.get('completed_repetitions') == p.get('expected_repetitions') == 7 for p in policies.values()),
            'Every policy/reference and all seven repeats required')
    parity = result.get('native_parity', {})
    require(set(parity) == {'current', 'previous'} and all(p.get('passed') is True for p in parity.values()), 'Both native parity receipts required')
    natural = result.get('natural_shared_base', {})
    require(natural.get('ordered_edges_exact') is True and natural.get('outputs_within_fixed_parity_tolerance') is True,
            'Natural/shared base equivalence receipt required')
    for field, rounds in (('warmup_calls', [-1]), ('timed_calls', list(range(7)))):
        calls = result.get(field, [])
        require(len(calls) == len(rounds) * 7, 'Incomplete timing call grid')
        for j, repetition in enumerate(rounds):
            offset = (item['source_index'] * 5 + item['schedule_index'] + max(0, repetition)) % 7
            order = CASES[offset:] + CASES[:offset]
            for slot, method in enumerate(order):
                call = calls[j * 7 + slot]
                timing_keys = {'end_to_end_seconds', 'score_generation_seconds', 'score_graph_seconds',
                               'score_forward_seconds', 'current_graph_and_selection_seconds', 'current_forward_seconds', 'network_passes'}
                proof_keys = {'ordered_edges_exact', 'outputs_within_fixed_parity_tolerance'}
                if method == POLICIES[-1]: proof_keys |= {'previous_score_ordered_edges_exact', 'previous_score_outputs_within_fixed_parity_tolerance'}
                if method == POLICIES[4]: proof_keys.add('physical_scores_exact')
                require((call.get('method'), call.get('round'), call.get('slot')) == (method, repetition, slot)
                        and call.get('status') == 'complete' and call.get('failure') is None
                        and set(call.get('timing', {})) == timing_keys
                        and (repetition < 1 or set(call.get('repeat_consistency', {})) == proof_keys)
                        and all(v is True for v in call.get('repeat_consistency', {}).values())
                        and call.get('timing', {}).get('network_passes') == (2 if method == POLICIES[-1] else 1),
                        'Failed, reordered, or missing charged timing call')
                require(all(finite(v) for v in call['timing'].values()), 'Invalid timing scalar')
    memory = result.get('memory', [])
    offset = (item['source_index'] * 5 + item['schedule_index']) % 7
    require(len(memory) == 7 and [m.get('method') for m in memory] == list(CASES[offset:] + CASES[:offset]), 'Memory policy/order coverage differs')
    for slot, row in enumerate(memory):
        method = row['method']
        prefix = 'r1_' + method + '__'
        reference = {k[len(prefix):]: v for k, v in result.get('array_value_sha256', {}).items() if k.startswith(prefix)}
        required = {'edges', 'prediction', 'risk', 'raw_risk', 'selected_optional_pairs'}
        if method == POLICIES[-1]:
            required |= {'previous_base_edges', 'previous_base_prediction', 'previous_base_risk', 'previous_base_raw_risk'}
        if method == POLICIES[4]: required.add('physical_selection_scores')
        require(required <= set(reference) and all(digest(v) for v in reference.values())
                and row.get('array_value_sha256') == reference and row.get('reference_hashes_equal') is True
                and row.get('status') == 'complete' and row.get('headroom_passed') is True and row.get('slot') == slot
                and row.get('graph') == policies[method]['graph'], 'Memory reference/hash/graph proof incomplete')
        keys = ('baseline_allocated_bytes', 'baseline_reserved_bytes', 'peak_allocated_bytes', 'peak_reserved_bytes',
                'incremental_allocated_bytes', 'device_total_bytes')
        require(all(type(row.get(k)) is int and row[k] >= 0 for k in keys)
                and row['device_total_bytes'] > 0 and row['baseline_allocated_bytes'] <= row['peak_allocated_bytes'] <= row['peak_reserved_bytes']
                and row['baseline_reserved_bytes'] <= row['peak_reserved_bytes']
                and row['incremental_allocated_bytes'] == row['peak_allocated_bytes'] - row['baseline_allocated_bytes']
                and row['peak_reserved_bytes'] <= int(row['device_total_bytes'] * .90), 'Allocator accounting/headroom differs')
    return True


def validate_release(release, phase, now=None, verify=True, check=lambda: None):
    now = now or utc()
    require(release.get('schema') == SCHEMA and release.get('issued_by') == 'root'
            and release.get('status') == 'admitted_' + phase and release.get('phase') == phase,
            'Separate root phase admission required')
    require(release.get('workload') == WORKLOAD and release.get('limits') == LIMITS
            and release.get('environment') == ENV, 'Prospective full workload/bounds changed')
    start, stop = stamp(release['initial_staging_utc']), stamp(release['absolute_stop_utc'])
    require(stop - start == timedelta(seconds=3600) and start <= now < stop <= RESEARCH_STOP,
            'One original 3600-second clock within research stop required')
    clock = release['clock_origin']
    require(set(clock) == {'host_monotonic_seconds', 'host_boot_id', 'checked_utc', 'error_bound_seconds'}
            and finite(clock['host_monotonic_seconds']) and isinstance(clock['host_boot_id'], str) and clock['host_boot_id']
            and stamp(clock['checked_utc']) == start and finite(clock['error_bound_seconds']) and clock['error_bound_seconds'] <= 5,
            'Original staging host monotonic/boot identity and bounded root clock evidence required')
    if phase == 'full':
        require(start <= stamp(release['full_admission_utc']) <= now, 'Root full admission time required')
        require(set(release['pilot_receipt']) == set(release['pilot_external_closure']) == {'path', 'sha256'}, 'Full phase must bind original pilot and root closure')
    require(isinstance(release.get('study_id'), str) and release['study_id'] and release.get('hostname'), 'Study/host identity missing')
    repo = absolute(release['repo'])
    python = release['python']
    require(set(python) == {'lexical_path', 'resolved_path', 'sha256', 'venv_config'}
            and Path(python['lexical_path']).is_absolute() and digest(python['sha256']), 'Pinned interpreter/venv required')
    require(set(release['controls']) == set(CONTROL_NAMES), 'Only complete validation control bundle allowed')
    sources = release['sources']
    require(set(sources) == set(FROZEN) | set(NEW_SOURCES), 'Exact frozen/new entry source closure required')
    for name, row in sources.items():
        require(row['path'] == str(repo / 'cuda_preparation' / name), 'Source path differs')
        require(name not in FROZEN or row['sha256'] == FROZEN[name], 'Frozen scientific source pin changed')
    models = release['models']
    require(len(models) == 6 and {(m['arm'], m['seed']) for m in models} == {(a, s) for a in ('base', 'mix') for s in range(3)}
            and all(type(m['seed']) is int and set(m) == {'arm', 'seed', 'checkpoint', 'original_checkpoint_path'}
                    and Path(m['original_checkpoint_path']).is_absolute() for m in models)
            and len({m['checkpoint']['sha256'] for m in models}) == 6, 'All six distinct original final endpoints required')
    gpus = release['gpus']
    require(len(gpus) == 4 and {g['index'] for g in gpus} == set(range(4))
            and len({gpu_uuid(g['uuid']) for g in gpus}) == 4 and all('GB200' in g['name'] and type(g['total_memory_bytes']) is int
                and g['total_memory_bytes'] > 0 for g in gpus), 'Exact dedicated four-GB200 host inventory required')
    expected = [dict(seed=s, gpu_index=s, gpu_uuid=next(g['uuid'] for g in gpus if g['index'] == s), arms=list(ARMS[s])) for s in range(3)]
    require(release['streams'] == expected, 'Fixed three paired-seed streams/arm order required')
    require(set(release['outputs']) == {'pilot', 'full'}, 'Both fresh phase outputs must be frozen before pilot')
    outs = [absolute(p) for p in release['outputs'].values()]
    require(outs[0] != outs[1] and not any(a in b.parents for a in outs for b in outs if a != b), 'Separate phase output trees required')
    protected = [repo / 'adaptive-gns', repo / 'cuda_preparation'] + [Path(v['path']).parent for v in release['controls'].values()] + [Path(m['checkpoint']['path']).parent for m in models]
    require(all(out != p and out not in p.parents and p not in out.parents for out in outs for p in protected), 'Output overlaps source/model/data/control tree')
    if verify:
        for row in list(sources.values()) + list(release['controls'].values()) + [m['checkpoint'] for m in models]:
            binding(row, check)
        require(str(Path(python['lexical_path']).resolve()) == python['resolved_path'] and sha(python['lexical_path'], check) == python['sha256'], 'Python bytes/resolution changed')
        binding(python['venv_config'], check)
    return study_identity(release)


def forecast(rows):
    require(len(rows) == 6 and {(r['arm'], r['seed']) for r in rows} == {(a, s) for a in ('base', 'mix') for s in range(3)}, 'Six complete pilot child receipts required')
    estimates, owner_estimates = {}, {}
    for r in rows:
        require(r.get('schema') == CHILD_SCHEMA and r.get('status') == 'complete' and r.get('phase') == 'pilot' and r.get('blocks') == 15
                and r.get('all_inputs_reverified') is True and r.get('all_memory_reference_hashes_equal') is True
                and r.get('all_headroom_checks_passed') is True and r.get('complete_forwards') == 1140,
                'Failed/incomplete pilot cannot admit a subset')
        owner_times = r.get('owner_verification_block_seconds', [])
        require(len(owner_times) == 15 and all(finite(v) for v in owner_times)
                and r.get('maximum_owner_verification_block_seconds') == max(owner_times), 'Complete measured per-block owner verification costs required')
        a = r['setup_seconds']
        c = r['maximum_publication_inclusive_block_seconds']
        f = r['finalization_seconds']
        require(finite(a) and finite(c, True) and finite(f), 'Finite measured complete-block costs required')
        estimates[(r['arm'], r['seed'])] = a + 1.35 * 150 * c + f
        owner_estimates[(r['arm'], r['seed'])] = 1.35 * 150 * r['maximum_owner_verification_block_seconds']
    streams = [sum(estimates[(arm, seed)] for arm in ARMS[seed]) for seed in range(3)]
    return {'per_model_seconds': [{'arm': arm, 'seed': seed, 'seconds': seconds} for (arm, seed), seconds in sorted(estimates.items())],
            'per_seed_stream_seconds': streams, 'serial_owner_verification_seconds': sum(owner_estimates.values()),
            'per_model_owner_verification_seconds': [{'arm': arm, 'seed': seed, 'seconds': seconds} for (arm, seed), seconds in sorted(owner_estimates.items())],
            'work_seconds': max(streams) + sum(owner_estimates.values()),
            'formula': 'max_seed(sum_arms(a_m + 1.35 * 150 * maximum_complete_publication_inclusive_child_block_m + fixed_f_m)) + 1.35 * 150 * sum_all_six(maximum_owner_verification_block_m)'}


def capacity_gate(release, pilot, closure, now=None):
    now = now or utc()
    identity = study_identity(release)
    require(pilot.get('schema') == OWNER_SCHEMA and pilot.get('status') == 'complete' and pilot.get('phase') == 'pilot'
            and pilot.get('study_identity') == identity and pilot.get('all_children_reaped') is True
            and pilot.get('final_gpu_processes') == [] and pilot.get('failure') is None
            and pilot.get('observed_complete_blocks') == 90 and finite(pilot.get('whole_phase_seconds'))
            and pilot['whole_phase_seconds'] <= 600, 'Complete original same-study pilot owner required')
    require(closure.get('schema') == 'adaptgns_goop2d_validation_cost_external_closure_v1'
            and closure.get('issued_by') == 'root' and closure.get('status') == 'original_session_exit_and_native_absence_verified'
            and closure.get('pilot_receipt_sha256') == release['pilot_receipt']['sha256']
            and closure.get('original_session_exit_code') == 0 and closure.get('owner_native_absent') is True
            and closure.get('all_children_native_absent') is True and closure.get('gpu_processes') == [],
            'Root original-session/native/GPU closure required before full admission')
    require(stamp(pilot['completed_utc']) <= stamp(closure['checked_utc']) <= now, 'Pilot closure chronology invalid')
    require(stamp(pilot['phase_started_utc']) <= stamp(pilot['completed_utc'])
            and (stamp(closure['checked_utc']) - stamp(pilot['phase_started_utc'])).total_seconds() <= 600,
            'Complete pilot publication, original exit and native closure must fit the same 600-second phase')
    origin = release['clock_origin']
    require(pilot.get('clock_origin') == origin and closure.get('host_boot_id') == origin['host_boot_id']
            and finite(pilot.get('phase_started_monotonic')) and finite(pilot.get('completed_monotonic'))
            and finite(closure.get('checked_host_monotonic_seconds'))
            and origin['host_monotonic_seconds'] <= pilot['phase_started_monotonic'] <= pilot['completed_monotonic']
                <= closure['checked_host_monotonic_seconds']
            and closure['checked_host_monotonic_seconds'] - pilot['phase_started_monotonic'] <= 600
            and abs((stamp(closure['checked_utc']) - stamp(release['initial_staging_utc'])).total_seconds()
                - (closure['checked_host_monotonic_seconds'] - origin['host_monotonic_seconds'])) <= origin['error_bound_seconds'],
            'Original-boot monotonic pilot publication/exit/closure must fit 600 seconds without wall-clock credit')
    children = pilot.get('children', [])
    require(len(children) == 6 and all(c.get('exit_code') == 0 and c.get('reaped') is True and c.get('signals') == [] for c in children), 'Every pilot child must exit zero and be reaped without signals')
    for child in children:
        row = child['receipt']
        model = next((m for m in release['models'] if (m['arm'], m['seed']) == (row.get('arm'), row.get('seed'))), None)
        require(model is not None and row.get('study_identity') == identity
                and row.get('checkpoint_sha256') == model['checkpoint']['sha256']
                and (child.get('arm'), child.get('seed')) == (row['arm'], row['seed'])
                and row.get('gpu_uuid') == release['streams'][row['seed']]['gpu_uuid'], 'Pilot endpoint/device/study provenance differs')
    estimate = forecast([c['receipt'] for c in children])
    elapsed = (now - stamp(release['initial_staging_utc'])).total_seconds()
    required = elapsed + release['clock_origin']['error_bound_seconds'] + 60 + estimate['work_seconds'] + 90 + 450
    require(required <= 3600, 'Measured full-workload forecast does not fit unchanged whole-study clock/reserves')
    return dict(estimate, elapsed_since_initial_staging_seconds=elapsed, required_whole_seconds=required,
                remaining_margin_seconds=3600 - required)
