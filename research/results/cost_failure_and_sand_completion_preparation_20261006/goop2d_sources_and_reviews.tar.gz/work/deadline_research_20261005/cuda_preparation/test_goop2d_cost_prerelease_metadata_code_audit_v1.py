"""Synthetic metadata only; no real CUDA, model, data, process or remote calls."""
import copy
import importlib.util
import io
from pathlib import Path
from contextlib import redirect_stdout
import sys
import unittest
from unittest.mock import patch

P = Path(__file__).resolve().parent / 'inspect_goop2d_cost_prerelease_metadata_code_audit_v1.py'
spec = importlib.util.spec_from_file_location('cost_metadata', P)
M = importlib.util.module_from_spec(spec)
spec.loader.exec_module(M)


def rows():
    nv, cu = [], []
    for index, uuid in enumerate(M.EXPECTED_UUIDS):
        nv.append(dict(index=index, uuid='GPU-' + uuid, name='NVIDIA GB200', memory_total_mib=M.EXPECTED_NVIDIA_MEMORY_MIB))
        cu.append(dict(index=index, uuid=uuid, name='NVIDIA GB200', memory_total_bytes=M.EXPECTED_NVIDIA_MEMORY_MIB * M.MIB,
                       memory_free_bytes=1))
    return nv, cu


class MetadataOnlyTests(unittest.TestCase):
    def test_inert_default_never_inspects_host_or_imports_torch(self):
        with patch.object(M, 'inspect') as inspect, redirect_stdout(io.StringIO()):
            self.assertEqual(M.main([]), 0)
            inspect.assert_not_called()
        self.assertNotIn('torch', sys.modules)

    def test_exact_memory_and_sub_mib_floor_bound(self):
        nv, cu = rows()
        result = M.check_memory_rows(nv, cu)
        self.assertEqual(len(result), 4)
        self.assertTrue(all(r['existing_memory_identity_rule_passed'] for r in result))
        for row in cu:
            row['memory_total_bytes'] += M.MIB - 1
        self.assertTrue(all(r['cuda_minus_nvidia_total_bytes'] == M.MIB - 1 for r in M.check_memory_rows(nv, cu)))

    def test_wrong_identity_or_out_of_range_memory_rejected(self):
        changes = [lambda n, c: c[0].update(uuid=c[1]['uuid']),
                   lambda n, c: c[0].update(memory_total_bytes=c[0]['memory_total_bytes'] - 1),
                   lambda n, c: c[0].update(memory_total_bytes=c[0]['memory_total_bytes'] + M.MIB),
                   lambda n, c: n.pop()]
        for index, change in enumerate(changes):
            with self.subTest(index=index):
                nv, cu = rows()
                change(nv, cu)
                with self.assertRaises(ValueError):
                    M.check_memory_rows(nv, cu)


if __name__ == '__main__':
    unittest.main(verbosity=2)
