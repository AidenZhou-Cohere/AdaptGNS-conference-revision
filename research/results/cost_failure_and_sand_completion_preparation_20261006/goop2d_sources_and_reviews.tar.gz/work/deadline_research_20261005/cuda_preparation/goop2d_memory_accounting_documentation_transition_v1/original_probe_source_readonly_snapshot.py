import pathlib,subprocess,json,datetime,shlex
P=pathlib.Path('work/deadline_research_20261005/cuda_preparation').resolve();tag=datetime.datetime.now(datetime.timezone.utc).strftime('%H%M%S')
code='''import os,json,socket,subprocess,datetime,pathlib,time
apps=lambda:subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,process_name','--format=csv,noheader,nounits'],text=True,timeout=15)
before=apps();assert not before.strip(),before
rows=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,name,memory.total','--format=csv,noheader,nounits'],text=True,timeout=15)
import torch
out=[]
for line in rows.strip().splitlines():
 idx,uuid,name,total=[x.strip() for x in line.split(',')];idx=int(idx);p=torch.cuda.get_device_properties(idx);raw=str(p.uuid);nbytes=int(total)*1048576;out.append({'index':idx,'nvidia_uuid':uuid,'cuda_uuid':raw,'name':p.name,'cuda_total_bytes':p.total_memory,'nvidia_total_integer_mib':int(total),'difference_bytes':p.total_memory-nbytes,'one_mib_compatible':abs(p.total_memory-nbytes)<=1048576})
print(json.dumps({'checked_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'host':socket.gethostname(),'pid':os.getpid(),'boot_id':pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'monotonic':time.monotonic(),'torch':torch.__version__,'cuda':torch.version.cuda,'devices':out,'pre_gpu_apps':before,'models_data_or_benchmark_loaded':False}))
'''
command='env LD_LIBRARY_PATH=/usr/lib/aarch64-linux-gnu:/usr/local/nvidia/lib:/usr/local/nvidia/lib64 CUBLAS_WORKSPACE_CONFIG=:4096:8 /root/repos/AdaptGNS-cuda-20261006/.venv/bin/python -B -'
r=subprocess.run(['ssh','-T','-F',str(P/'ssh_config'),'aquamarine-toad-75.coder',command],input=code,text=True,capture_output=True,timeout=60);prefix=P/('goop2d_memory_interface_'+tag+'_root_v1');prefix.with_suffix('.stdout').write_text(r.stdout);prefix.with_suffix('.stderr').write_text(r.stderr);assert r.returncode==0,(r.returncode,r.stderr);d=json.loads(r.stdout);prefix.with_suffix('.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'path':str(prefix.with_suffix('.json')),**d}))
