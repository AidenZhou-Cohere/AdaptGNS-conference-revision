# Post-full reporting handoff — prospective only

Use the approved v2 candidate in `goop2d_validation_cost_candidate_UNADMITTED_owner_v2r2` (construction SHA256 `f30e0ad378aa0322b36cf02fa666c270b5b605c4f74033e21fe9c17cc2070480`). Authority and clocks are still null. The earlier v2 candidate and all v1 products remain preserved.

Reporting runs on the same B host and boot, under the same original staging UTC/monotonic origin and 3,600-second stop. It does not create another allocation. The full original owner must have completed all 900 blocks, exited zero, reaped every child and passed root's fresh native/GPU absence check. The root closure must preserve the complete 450-second reporting reserve: `max(elapsed_monotonic, elapsed_UTC) + clock_error ≤ 3150`, with wall/monotonic agreement within the original error bound.

The full-run closure is separate from the pilot closure. Its exact schema is `adaptgns_goop2d_validation_cost_full_external_closure_v1`, with:

```json
{
  "schema": "adaptgns_goop2d_validation_cost_full_external_closure_v1",
  "issued_by": "root",
  "status": "original_session_exit_and_native_absence_verified",
  "owner_receipt_sha256": "ROOT_VERIFIED_ORIGINAL_FULL_OWNER_RECEIPT_SHA256",
  "original_session_exit_code": 0,
  "owner_native_absent": true,
  "all_children_native_absent": true,
  "gpu_processes": [],
  "host_boot_id": "SAME_RELEASE_BOOT_ID",
  "checked_utc": "ROOT_FRESH_POST_EXIT_UTC",
  "checked_host_monotonic_seconds": "ROOT_FRESH_POST_EXIT_MONOTONIC_NUMBER"
}
```

This is an interface example, not a receipt. Root must populate the actual scalar values and retain original session identity and native evidence. `checked_host_monotonic_seconds` must be a number in the real receipt. The pilot's v2 closure schema cannot replace this full-run schema.

After root has issued the full release and actual full closure, run these commands sequentially on B. The release and closure filenames below are proposed publication paths; if root issues either at another path, use that exact issued path. The owner output path is already fixed in the v2 candidate. All outputs must be fresh.

```sh
COST_REPO=/root/repos/AdaptGNS-cuda-20261006
COST_FULL_RELEASE="$COST_REPO/cuda_preparation/goop2d_validation_cost_full_release_root_v2.json"
COST_FULL_CLOSURE="$COST_REPO/cuda_preparation/goop2d_validation_cost_full_external_closure_root_v2.json"

"$COST_REPO/.venv/bin/python" \
  "$COST_REPO/cuda_preparation/collect_goop2d_validation_cost_scalars_v1.py" \
  --execute \
  --release "$COST_FULL_RELEASE" \
  --owner-receipt "$COST_REPO/goop2d_validation_cost_full_20261006_v2/owner_receipt.json" \
  --external-closure "$COST_FULL_CLOSURE" \
  --output "$COST_REPO/goop2d_validation_cost_scalars_20261006_v2"

"$COST_REPO/.venv/bin/python" \
  "$COST_REPO/cuda_preparation/summarize_goop2d_validation_cost_v1.py" \
  --execute \
  --bundle "$COST_REPO/goop2d_validation_cost_scalars_20261006_v2" \
  --contract "$COST_REPO/cuda_preparation/goop2d_validation_cost_contract_v2.py" \
  --output "$COST_REPO/goop2d_validation_cost_summary_20261006_v2.json"
```

Both reporters verify their exact `release.reporting_sources` paths/hashes before and after work and enforce the live original boot/monotonic/UTC clock through publication. The summary imports the released v2 scalar contract and passes the selected GPU row as the mandatory fourth `scalar_block` argument. It reports full coverage, all policies, paired seed results and the explicitly scoped CUDA allocator/process RSS observations. It cannot promote partial coverage to a complete estimate.

The released reporter pins are:

- `collect_goop2d_validation_cost_scalars_v1.py`: `9a7d4c92a687b3ff095fb1af76390205e919d57009eddf607e73e8cb9020f21e`.
- `summarize_goop2d_validation_cost_v1.py`: `d3e85888f947f969ae6181b5628bba51de5a0c94187af57d2d15a1bc181bbab6`.

Root retains original reporter exits and publication records, then performs any final collection/writeup inside the remaining original clock. No command in this handoff was executed during preparation.
