"""Write unadmitted scalar templates only; never execute a research mode."""
import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / 'sand_recovered_completion_candidates_UNADMITTED_transition_v1'
ROOT = '/root/repos/AdaptGNS-cuda-20261006'
PREP = ROOT + '/cuda_preparation'
PYTHON = ROOT + '/.venv/bin/python'


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(name): return json.loads((HERE / name).read_text())
def save(name, value): (OUT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
def literal(name, file):
    return next(ast.literal_eval(n.value) for n in ast.parse((HERE / file).read_text()).body
                if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in n.targets))


def main():
    OUT.mkdir(exist_ok=False)
    recovery_path = HERE / 'sand_migration_training_v2_root_1500_v1/training_release.json'
    recovery = json.loads(recovery_path.read_text())
    release_sha = sha(recovery_path)
    bridge_name = 'prepare_sand_recovered_final_cohort_v1.py'
    prep_name = 'prepare_sand_reserved_test_recovered_v1.py'
    bridge_sha, prep_sha = sha(HERE / bridge_name), sha(HERE / prep_name)
    assert literal('COHORT_ADAPTER_SHA', prep_name) == bridge_sha
    cohort_id = recovery['cohort_id']
    owner = recovery['owner_output_directory']
    actual_release_path = ROOT + '/sand_runtime_migration_A_20261006_v2/controls/training_release.json'
    process_a = {'schema': 'adaptgns_sand_recovered_A_completed_process_check_v1', 'status': 'template_not_admitted',
                 'issued_by': None, 'checked_utc': None, 'hostname': recovery['host'], 'owner_pid': None,
                 'owner_release_sha256': release_sha, 'owner_exited': False, 'all_children_reaped': False,
                 'matching_training_processes': None, 'scoped_gpu_inventory': None,
                 'files_sha256': {actual_release_path: release_sha, **{owner + '/' + n: None for n in
                                   ('owner_started.json', 'wave_A.json', 'owner_terminal.json')}}}
    save('process_check_A.template.json', process_a)
    process_b = read('sand_completed_host_process_check.template.json')
    process_b.update(host_role='B', cohort_id=cohort_id)
    save('process_check_B.template.json', process_b)
    final_pins = read('sand_final_cohort_scoped_release.template.json')['final_source_sha256']
    bridge_release = {'schema': 'adaptgns_sand_recovered_final_cohort_bridge_release_v1', 'status': 'template_not_admitted',
                      'issued_by': None, 'review_rationale': None, 'cohort_id': cohort_id, 'adapter_sha256': bridge_sha,
                      'original_B_adapter_sha256': sha(HERE / 'prepare_sand_final_cohort_scoped_v1.py'),
                      'recovery_release_sha256': release_sha, 'inventory_sha256': {'A': None, 'B': None},
                      'final_source_sha256': final_pins}
    save('bridge_release.template.json', bridge_release)
    final_paths = {'protocol': PREP + '/sand_graph_support_100k_protocol_v1.md',
                   'train_admission': PREP + '/sand_train_admission.json',
                   'trainer_source': PREP + '/train_sand_graph_support_cuda.py',
                   'benchmark_helper': PREP + '/benchmark_sand_graph_support_rollout.py',
                   'diagnostic_source': PREP + '/evaluate_sand_graph_support_final.py'}
    commands = {'inventory_A': [PYTHON, '-B', PREP + '/' + bridge_name, '--execute', '--mode', 'inventory-a',
                                '--recovery-release', actual_release_path, '--process-check', '${PROCESS_A}', '--output', '${INVENTORY_A}'],
                'inventory_B': [PYTHON, '-B', PREP + '/prepare_sand_final_cohort_scoped_v1.py', '--execute', '--mode', 'inventory',
                                '--host-root', ROOT + '/sand_scoped_science_B_20261006_v1', '--process-check', '${PROCESS_B}',
                                '--output', '${INVENTORY_B}'],
                'build_cohort': [PYTHON, '-B', PREP + '/' + bridge_name, '--execute', '--mode', 'build', '--inventory-a', '${INVENTORY_A}',
                                 '--inventory-b', '${INVENTORY_B}', '--root-release', '${BRIDGE_RELEASE}', '--output-dir', '${COHORT_DIR}']}
    for key, path in final_paths.items(): commands['build_cohort'] += ['--' + key.replace('_', '-'), path]
    save('handoff_commands_UNADMITTED.json', {'status': 'UNADMITTED_do_not_execute', 'commands': commands})
    mapping = []
    for job in recovery['jobs']:
        mapping.append({'id': job['id'], 'arm': job['arm'], 'seed': job['seed'], 'host_role': 'A', 'gpu': job['gpu'],
                        'checkpoint_path': job['output_directory'] + '/checkpoint-000100000.pt', 'checkpoint_sha256': None,
                        'origin_directory': job['origin_directory'], 'origin0to50k_checkpoint_sha256': job['origin_checkpoint_inventory'],
                        'lineage': 'original0to50k_then_reviewed_recovery50kto100k'})
    for arm, gpu in [('base', 2), ('mix', 3)]:
        mapping.append({'id': arm + '_seed0', 'arm': arm, 'seed': 0, 'host_role': 'B', 'gpu': gpu,
                        'checkpoint_path': ROOT + '/sand_scoped_science_B_20261006_v1/jobs/' + arm + '_seed0/checkpoint-000100000.pt',
                        'checkpoint_sha256': None, 'lineage': 'original_uninterrupted0to100k'})
    save('six_model_lineage_UNADMITTED.json', {'status': 'future_endpoint_hashes_unresolved', 'models': mapping,
                                             'capacity_or_replay_checkpoint_promotion': False})
    benchmark_pins = literal('SOURCE_PINS', 'benchmark_sand_graph_support_rollout.py')
    fixed_names = ['supervise_sand_final_evaluation_scoped_v1.py', 'supervise_goop_evaluation_gpu_scoped_v3.py',
                   'supervise_sand_scoped_science_v1.py', 'evaluate_sand_graph_support_final.py',
                   'benchmark_sand_graph_support_rollout.py', 'train_sand_graph_support_cuda.py',
                   'sand_graph_support_100k_protocol_v1.md', 'sand_scoped_schedule_fixed_spec_v2.json',
                   'sand_scoped_operational_amendment_v1.md', 'measure_sand_cuda_capacity_v2.py']
    fixed = {PREP + '/' + n: sha(HERE / n) for n in fixed_names}
    fixed.update({ROOT + '/' + n: v for n, v in benchmark_pins.items()})
    fixed[final_paths['train_admission']] = final_pins['train_admission']
    stages = [('full_rollout_test', 'full-rollout', 'test', 7200), ('same_state_valid', 'same-state', 'valid', 1800),
              ('same_state_test', 'same-state', 'test', 1800), ('clean_validation', 'clean-validation', 'valid', 900)]
    for role in ('A', 'B'):
        release = read('sand_final_evaluation_scoped_release.template.json')
        release.update(host_role=role, host=None, files_sha256=dict(fixed), gpu_uuids=[None] * 4,
                       gpu_scope={'owned_indices': [0, 1, 2, 3] if role == 'A' else [2, 3],
                                  'unassigned_devices': 'observe_without_control', 'timing_scope': 'shared_host_operational_measurement',
                                  'live_training_handoff': False},
                       operational_amendment={'path': PREP + '/sand_scoped_operational_amendment_v1.md',
                                              'sha256': fixed[PREP + '/sand_scoped_operational_amendment_v1.md']})
        release['streams'] = []
        for model in [m for m in mapping if m['host_role'] == role]:
            stream = {k: model[k] for k in ('id', 'arm', 'seed', 'gpu')};stream['commands'] = []
            release['files_sha256'][model['checkpoint_path']] = None
            for name, mode, split, quota in stages:
                options = {'--repo': ROOT, '--benchmark-helper': final_paths['benchmark_helper'], '--benchmark-sha256': final_pins['benchmark_helper'],
                           '--cohort': '${COHORT_DIR}/cohort.json', '--cohort-audit': '${COHORT_DIR}/cohort_audit.json',
                           '--manifest': '${' + split.upper() + '_MANIFEST}', '--admission': '${' + split.upper() + '_ADMISSION}',
                           '--structural-report': '${' + split.upper() + '_STRUCTURAL_REPORT}',
                           '--train-admission': final_paths['train_admission'], '--trainer-source': final_paths['trainer_source'],
                           '--protocol': final_paths['protocol'], '--checkpoint': model['checkpoint_path'], '--checkpoint-sha256': None,
                           '--output-dir': '${QUEUE_' + role + '}/jobs/' + model['id'] + '/' + name,
                           '--mode': mode, '--split': split, '--objective': 'faithful', '--arm': model['arm'], '--seed': str(model['seed']),
                           '--cuda-index': str(model['gpu']), '--threads': '2', '--max-seconds': str(quota)}
                cmd = [PYTHON, PREP + '/evaluate_sand_graph_support_final.py', '--execute']
                for k, v in options.items(): cmd += [k, v]
                stream['commands'].append(cmd)
                for k in ('--cohort', '--cohort-audit', '--manifest', '--admission', '--structural-report'):
                    release['files_sha256'][options[k]] = None
            release['streams'].append(stream)
        save('evaluation_' + role + '.template.json', release)
    prep_fixed_names = [bridge_name, prep_name, 'download_sand_public_v2.py', 'repackage_designsafe_sand.py',
                        'evaluate_sand_graph_support_final.py', 'benchmark_sand_graph_support_rollout.py',
                        'sand_graph_support_100k_protocol_v1.md', 'sand_scoped_operational_amendment_v1.md', 'sand_scoped_schedule_fixed_spec_v2.json']
    save('reserved_preparation.template.json', {'schema': 'adaptgns_sand_reserved_test_preparation_release_scoped_v1',
         'status': 'template_not_admitted', 'issued_by': None, 'issued_utc': None, 'mode': None,
         'preparation_source_sha256': prep_sha, 'cohort_sha256': None, 'cohort_audit_sha256': None, 'output_dir': None,
         'preparation_started_utc': None, 'preparation_stop_utc': None, 'clock_error_bound_seconds': None,
         'no_retry_or_checkpoint_selection': True, 'files_sha256': {**{PREP + '/' + n: sha(HERE / n) for n in prep_fixed_names},
          '${COHORT_DIR}/cohort.json': None, '${COHORT_DIR}/cohort_audit.json': None},
         'construction_note': 'Each mode has a separate root release and fresh output. All acquire/convert/census/valid+test candidate/valid+test preflight actions share one original900second window. No window reset; bind actual outputs only after prior mode completes.'})
    save('construction_record.json', {'status': 'UNADMITTED_source_and_scalar_templates_only', 'created_utc': datetime.now(timezone.utc).isoformat(),
         'bridge_source_sha256': bridge_sha, 'reserved_preparer_source_sha256': prep_sha, 'recovery_release_sha256': release_sha,
         'constructor_sha256': sha(__file__), 'no_scientific_modes_or_payload_reads': True, 'no_remote_calls': True,
         'original_posttraining_allocation_seconds': 18960, 'components_seconds': {'parallel_six_model_evaluation': 11760,
            'shared_source_preparation': 900, 'cohort_source_verification': 2700, 'paired_analysis': 3600},
         'stage_count': 24, 'model_count': 6, 'policies': ['base', 'dense', 'random25', 'speed25', 'laggedrisk25', 'relative-velocity-RMS25'],
         'full_rollout_horizon': 314, 'full_required_outcomes': 1080, 'deadline_utc': '2026-10-07T04:00:00+00:00',
         'maximum_latest_start_at5second_error': '2026-10-06T23:43:55+00:00',
         'unresolved': ['All four A completed endpoint and paired audit receipts; original B exact completed inventory and native closure.',
                        'Independent source/synthetic review and frozen final bridge/preparer source hashes.',
                        'Actual six final checkpoint hashes, both inventories, root bridge release, produced cohort/audit hashes.',
                        'One900second source window, future actual test/source/admission/preflight outputs.',
                        'Both fresh host/Python/GPU/clock/native evidence, interpreter pins, resolved output/control paths and complete evaluation input hashes.',
                        'Root-only publication/staging/launch; no quota/seed/policy/horizon reduction or automatic retry.']})
    save('candidate_manifest.json', {'status': 'UNADMITTED', 'files_sha256': {f.name: sha(f) for f in sorted(OUT.iterdir()) if f.is_file()}})
    print(json.dumps({'output_dir': str(OUT), 'manifest_sha256': sha(OUT / 'candidate_manifest.json')}))


if __name__ == '__main__': main()
