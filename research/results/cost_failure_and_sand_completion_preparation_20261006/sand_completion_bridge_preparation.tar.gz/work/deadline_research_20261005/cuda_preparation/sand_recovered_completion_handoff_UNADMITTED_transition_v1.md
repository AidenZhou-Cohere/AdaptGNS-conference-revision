# Sand completion handoff — unadmitted

The original study remains six faithful models (base/mix × seeds 0, 1, 2), each at exactly 100,000 updates. Recovered A supplies seeds 1 and 2; original B supplies seed 0. No capacity or replay checkpoint is eligible. This document and its templates grant no execution, staging, publication or test access.

## Provenance and the compatibility change

The frozen original cohort adapter requires a clean uninterrupted scoped-owner receipt and all eleven scientific checkpoints in one directory. Those requirements remain correct for B. They cannot describe A's interrupted original run and reviewed recovery honestly.

`prepare_sand_recovered_final_cohort_v1.py` therefore provides a separate byte-inventory and scalar-cohort bridge. It pins the actual manually issued recovery release `194437c62c992a061e2b3e4f3f7d12d487d7edcca2a2c701e185d3d05d3bd9ca`. A retains its original 0–50k checkpoint tree, original lock, protocol, pointer, historical stdout, replay receipt, and the distinct recovered 50–100k tree. The 50k copy must equal the original. The recovered owner must first publish all four successful endpoint audits and both full 100k pairing audits, then exit with its children reaped. A new root native-closure check must bind the exact release and owner products before byte inventory begins.

The bridge never deserializes tensors or loads training/test arrays. Its future inventory hashes checkpoint and retained-file bytes after that completion gate. Payload, Adam, RNG, original-prefix and full-schedule conclusions are explicitly inherited from the frozen recovery auditor. It does not claim that recovery started afresh or that different physical GPUs are bitwise equivalent. Failed historical attempts remain failed and are retained as provenance.

B continues to use `prepare_sand_final_cohort_scoped_v1.py` without edits. The bridge calls its unchanged scalar receipt validator for B and requires the exact old adapter source hash. Both inventories must name the original cohort. Their final hashes, six distinct endpoint hashes and three paired seeds must agree before the existing cohort/audit interface is published.

The original reserved-test preparation gate pins the old cohort adapter, so it rejects an honestly labelled new bridge. `prepare_sand_reserved_test_recovered_v1.py` is a separate compatibility candidate: only its description, accepted bridge hash, and bound bridge filename differ. Its cohort gates, downloader, restricted converter, census, admission, preflight bodies, and shared 900-second preparation window remain unchanged. The original file is preserved. Any bridge source fix invalidates this candidate's bridge pin and requires a regenerated, reviewed source/control package.

## Required handoff sequence

1. Root collects original A recovery terminal, wave, launch/outcome logs and full endpoint/pairing evidence after the sole admitted training invocation has stopped. Root verifies owner/children absent, exact native identities and closure; no automatic retry. Original B receives its own fresh completed-host closure check. Existing training results are not inferred from live counters.
2. Under separate root authorization, inventory A with the new bridge and B with the frozen original adapter. Both inventory outputs must be outside retained training trees. Original A's historical lock is retained; active locks, partial files and failure markers in the recovered/owner trees are rejected.
3. Independently review both actual inventories and their source/audit/endpoint bindings. Root fills the bridge release with their exact hashes. Build the final cohort and audit in a fresh output directory, with post-serialization source/inventory checks before each publication. Preserve any failed publication.
4. Only after that whole-cohort freeze, root may admit the separately reviewed recovered-cohort reserved-test preparer. Acquire, convert, census, valid/test admission candidates and valid/test preflights share one original 900-second source window. Each operation has a separate concrete root release and fresh output; prior elapsed time remains spent.
5. Transfer and verify the same final cohort, source evidence and required split data for both original evaluation roles. Resolve the templates' actual source/admission/preflight paths and hashes, six endpoint hashes, interpreter provenance, fresh host/GPU/clock evidence and fresh outputs. Review the exact input closure and all 24 commands before root admits either evaluation queue.
6. Preserve all outcomes and missing/failed cases for the original paired accuracy–cost analysis. Completion of a timeout-controlled invocation is not proof that every requested scientific outcome completed.

## Fixed allocation and evaluation mapping

The original post-training allocation is **18,960 seconds**: 2,700 cohort/source verification + 900 shared source preparation + 11,760 concurrent evaluation streams + 3,600 paired analysis. These components are not replenished after a failed or slow operation. The training/endpoint-audit stop remains October 6 at 22:44 UTC and the compute/analysis deadline remains October 7 at 04:00 UTC.

Each of the six models has the same four ordered stage allocations: full test rollout 7,200 seconds; same-state validation 1,800; same-state test 1,800; clean validation 900. Each stage includes a separate 15-second cleanup allowance, giving `7200 + 1800 + 1800 + 900 + 4×15 = 11760` seconds per concurrent stream. There are no additional evaluation waves. With a five-second clock bound, the latest allowed evaluation-start field is 23:43:55 UTC; freshness and actual available time must still pass at launch.

| Role | GPU indices | Models | Final checkpoint lineage |
|---|---|---|---|
| A | 0, 1, 2, 3 | base1, mix1, base2, mix2 | New recovered 100k endpoints with original 0–50k lineage |
| B | 2, 3 | base0, mix0 | Original uninterrupted 100k endpoints |

The unchanged comparison requests all 30 test trajectories, full H314 forecasts, and all six policies: base, dense, random25, speed25, laggedrisk25 and relative-velocity-RMS25. That is 1,080 full-rollout outcomes. Each model also has 150 same-state histories per split and 128 clean validation histories. Final physical GPU UUIDs and current interpreter/clock/native-state evidence remain unresolved until root observes them after training.

## Review still required

The new bridge requires independent producer-to-consumer schema checks and synthetic rejection tests for failed/incomplete A, changed old/new checkpoint bindings, original lock/stdout/replay mutations, mismatched owner identity or control hashes, incorrect pairing or runtime lineage, wrong B adapter/inventory, incomplete six-model coverage, and mutation before publication. The compatibility preparer requires an exact three-line source-diff review and scalar cohort-gate tests using the new truthful adapter identity. No actual training, model, test or remote mode has been executed by this preparation task.

The generated package is `sand_recovered_completion_candidates_UNADMITTED_transition_v1`. Every null hash, path role, false admission flag and template status is intentional. Root must resolve them from completed evidence and separately issue the resulting concrete controls. The templates do not establish completion, fit, or permission to launch.
