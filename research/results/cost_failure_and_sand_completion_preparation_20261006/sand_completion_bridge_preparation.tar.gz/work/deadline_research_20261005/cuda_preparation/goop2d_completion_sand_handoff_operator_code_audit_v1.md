# Goop 2D completion and Sand handoff: frozen-source operator note

Prepared from saved receipts and static source inspection, October 6, 2026. This note creates no release and authorizes no execution. No remote query, real data/model read, source import, test, process control, HEAD or GET was performed to prepare it. Commands below are future operator invocations after the stated gates. The existing scientific protocols, outcomes, quotas and deadlines remain fixed.

## 1. Host ownership and the first gates

| Role | Exact hostname | Existing Goop training directory | Goop evaluation | New Sand training |
|---|---|---|---|---|
| A | `aidenzhou-yellow-worm-77-78fff65d5-kgdt9` | `/root/repos/AdaptGNS-cuda-20261006/goop_graph_support_science_A_20261006_v2` | base0/GPU0, mix0/GPU1, base1/GPU2, mix1/GPU3 | base1/GPU0, mix1/GPU1, base2/GPU2, mix2/GPU3 |
| B | `aidenzhou-aquamarine-toad-75-6d8b45c98d-mgjlq` | `/root/repos/AdaptGNS-cuda-20261006/goop_graph_support_science_B_20261006_v2` | base2/GPU0, mix2/GPU1 | base0/GPU2, mix0/GPU3 |

**B handoff:** all original local Goop trainers must be reaped and the entire original broad training supervisor must have exited after its CPU endpoint/pairing audit. `verifying_endpoints`, ended GPU work, or an idle GPU alone is insufficient. B can then start separately released Sand training on GPUs 2/3 while Goop scoped evaluation uses 0/1. Sand B need not wait for Goop A or the common Goop cohort.

**A handoff:** the same original-training exit gate applies; all former Goop-owned GPU evaluation work must also be reaped/exited before Sand acquires GPUs 0–3. Never edit/filter/suspend a running original supervisor or use the old broad Goop evaluation supervisor for coexistence.

**Goop test gate:** both original hosts must have fully completed, their fresh byte inventories must pass, and the common six-model cohort/audit must be frozen and root-reviewed before even test HEAD. Local host completion is not whole-cohort admission.

The saved 08:14 UTC receipts still reported running Goop training: A base0 77,600 / mix0 77,200 / base1 76,400 / mix1 76,900; B base2 72,100 / mix2 74,300. These are historical progress only, not completion or launch authority. Fresh native PID/start-time/argv, GPU UUID/process and clock evidence remains necessary at each actual handoff.

## 2. Paths, staging evidence and future outputs

Existing paths on both hosts:

```sh
TASK_REPO=/root/repos/AdaptGNS-cuda-20261006
TASK_PREP="$TASK_REPO/cuda_preparation"
TASK_PY="$TASK_REPO/.venv/bin/python"
TASK_GOOP_INPUT="$TASK_REPO/goop_numeric_train_valid_20261006_v1"
TASK_SAND_INPUT="$TASK_REPO/sand_numeric_train_valid_20261006_v1"
```

The following are **proposed future paths**, not assertions that they exist or are absent. Confirm freshness before authoring/binding anything. Retain failures; do not clear or overwrite a collision. Keep matching absolute paths across A/B where practical.

```sh
TASK_COMPLETION="$TASK_REPO/goop_completion_20261006_v1"
TASK_COHORT="$TASK_COMPLETION/cohort"
TASK_TEST_SOURCE="$TASK_COMPLETION/test_source"
TASK_TEST_NUMERIC="$TASK_COMPLETION/test_numeric"
TASK_TEST_EVIDENCE="$TASK_COMPLETION/test_evidence"
```

Per host set `TASK_ROLE=A` or `TASK_ROLE=B`, and set `TASK_GOOP_TRAIN` to that role's existing directory in the table. Proposed fresh queues are `TASK_GOOP_EVAL="$TASK_REPO/goop_scoped_evaluation_${TASK_ROLE}_20261006_v3"` and `TASK_SAND_TRAIN="$TASK_REPO/sand_scoped_science_${TASK_ROLE}_20261006_v1"`.

Saved `yellow_completion_helpers_stage_0820_v1.json` and `aquamarine_completion_helpers_stage_0820_v1.json` record 47 and 56 verified files respectively, with `source_execution:false`. Parent subsequently staged the separate Goop cohort/reserved-test adapters on both hosts and the official converter on A; the pinned original reader already matched on both. These additions are outside the older dependency manifest's original scope; do not regenerate that sealed manifest merely to add them.

Saved `*_preparation_packages_0820_v1.json` establish NumPy 2.5.3, requests 2.34.2 and crc32c 2.9.post0 metadata/module presence. Saved `*_reader_packages_0822_v1.json` establish tfrecord 1.14.6 with `tfrecord/example_pb2.py` and protobuf 7.36.2 with `google/protobuf/__init__.py` on A/B/D3. No package imports occurred. The lexical venv interpreter/prefix was verified. This establishes availability; actual conversion and final-input runtime remain untested until admitted execution. Fresh launch pin checks and complete successful preparation are still required.

## 3. Complete both Goop host inventories, then build once

For each host, root first confirms native inactivity and these terminal receipts: `worker_summary.json.status == verified_host_scientific_endpoints`; `status.json.state == complete_host_scientific_training`; `wave_A.json` or `wave_B.json.state == verified`; input reverification passed; every child exited 0 without signals; all endpoints are exact 100k with paired histories. The host summary's `whole_six_model_cohort_admitted` remains false. Any `.tmp`, `run.lock`, `unsuccessful*`, `state_preservation_error*` or symlink prevents inventory promotion; preserve it.

Root authors a fresh process receipt outside the training tree at proposed `$TASK_COMPLETION/process_${TASK_ROLE}.json` with schema `adaptgns_goop_completed_host_process_check_v1`, `issued_by:root`, `matching_training_processes:[]`, `supervisor_exited:true`, `all_children_reaped:true`, exact `host_role`, and `hostname` / `supervisor_pid` / `cohort_id` matching the completed `launch.json`. Its `checked_utc` must be after terminal `ended_utc` and at most 1,800 seconds old at inventory.

Run separately on each original host:

```sh
"$TASK_PY" -B "$TASK_PREP/prepare_goop_final_cohort_quota_v2.py" \
  --execute --mode inventory --host-root "$TASK_GOOP_TRAIN" \
  --process-check "$TASK_COMPLETION/process_${TASK_ROLE}.json" \
  --output "$TASK_COMPLETION/inventory_${TASK_ROLE}.json"
```

Inventory hashes every retained ordinary file, including all eleven checkpoints per model. It inherits the completed supervisor's initial/final tensor/Adam and full-history pairing audit; it does not deserialize the nine intermediate payloads or perform a second tensor audit. Root's review rationale must explicitly accept this scope.

Copy B's inventory to the A/coordinator completion directory byte-identically. Root creates proposed `cohort_release.json` with schema `adaptgns_goop_final_cohort_release_quota_v2`, status `approved_for_cohort_interface_mapping`, `issued_by:root`, adapter hash below, `cohort_id:goop_graph_support_100k_20261006_v2`, a nonempty review rationale, `inventory_sha256:{A:actual,B:actual}`, and `final_source_sha256` exactly equal to the adapter's six-key `FINAL_PINS` mapping below. Build **once**, on A/coordinator:

```sh
"$TASK_PY" -B "$TASK_PREP/prepare_goop_final_cohort_quota_v2.py" \
  --execute --mode build \
  --inventory-a "$TASK_COMPLETION/inventory_A.json" \
  --inventory-b "$TASK_COMPLETION/inventory_B.json" \
  --root-release "$TASK_COMPLETION/cohort_release.json" --output-dir "$TASK_COHORT" \
  --protocol "$TASK_PREP/goop_graph_support_100k_protocol_v2.md" \
  --train-admission "$TASK_PREP/goop_training_admission_v1.json" \
  --trainer-source "$TASK_PREP/train_goop_graph_support_cuda.py" \
  --benchmark-helper "$TASK_PREP/benchmark_goop_graph_support_rollout.py" \
  --data-contract "$TASK_PREP/goop_evaluation_contract.py" \
  --diagnostic-source "$TASK_PREP/evaluate_goop_graph_support_final.py"
```

Outputs are `cohort.json`, `cohort_audit.json`, `root_release.json`. Copy identical cohort/audit/release and both inventories to B; do not rebuild independently because timestamps would change identities. The cohort preserves original checkpoint paths. Each host loads only its selected local checkpoints, so no cross-host checkpoint copy is needed.

## 4. Reserved Goop test: HEAD → GET → convert → census → admit/preflight

Use A for the shared preparation so B Sand can proceed independently. Every mode requires the complete six-model gate and closes at **October 7 01:00 UTC**. This shell function only abbreviates the common arguments:

```sh
goop_test_prepare() {
  "$TASK_PY" -B "$TASK_PREP/prepare_goop_reserved_test_v1.py" --execute \
    --cohort "$TASK_COHORT/cohort.json" --cohort-audit "$TASK_COHORT/cohort_audit.json" "$@"
}
```

Root creates proposed `test_head_release.json` with schema `adaptgns_goop_reserved_test_preparation_release_v1`, status `approved_for_source_metadata`, `issued_by:root`, `issued_utc` at/after cohort creation, exact cohort/audit hashes, `preparation_source_sha256` below, source URL `https://storage.googleapis.com/learning-to-simulate-complex-physics/Datasets/Goop/test.tfrecord`, both `all_six_checkpoint_hashes_verified:true` and `test_converter_independently_reviewed:true`, and a nonempty review rationale. Only then:

```sh
goop_test_prepare --mode inspect \
  --root-release "$TASK_COMPLETION/test_head_release.json" \
  --output "$TASK_COMPLETION/test_source_metadata.json"
```

HEAD uses identity encoding and refuses redirects. Generation, length and CRC are unknown until the actual successful receipt; do not invent them. Root reviews it and writes a **new** proposed `test_preparation_release.json` with the same bindings, status `approved_for_acquisition_preparation`, and `source_metadata_sha256` equal to the actual header receipt hash. This release is used for all remaining modes.

```sh
goop_test_prepare --mode acquire \
  --root-release "$TASK_COMPLETION/test_preparation_release.json" \
  --source-metadata "$TASK_COMPLETION/test_source_metadata.json" \
  --metadata "$TASK_GOOP_INPUT/metadata.json" --output-dir "$TASK_TEST_SOURCE"
```

Acquisition publishes `test.tfrecord`, `metadata.json`, `acquisition_report.json`. GET is bound to admitted publisher generation/length/CRC; full received SHA/CRC and partial failures are preserved. No automatic retry/resume.

```sh
goop_test_prepare --mode convert \
  --root-release "$TASK_COMPLETION/test_preparation_release.json" \
  --source-metadata "$TASK_COMPLETION/test_source_metadata.json" \
  --input-dir "$TASK_TEST_SOURCE" --acquisition-report "$TASK_TEST_SOURCE/acquisition_report.json" \
  --reader "$TASK_REPO/research/prepare_full_waterdrop.py" --output-dir "$TASK_TEST_NUMERIC"
```

Conversion uses the pinned sibling `prepare_goop_official.py` and reader. All 30 records must satisfy T401/type7/context401×1 and the frozen H395 contract; retain discrepancies without repair/subsetting. Outputs include `test.json`, `test/`, `metadata.json`, `structural_report.json`.

```sh
goop_test_prepare --mode census \
  --root-release "$TASK_COMPLETION/test_preparation_release.json" \
  --source-metadata "$TASK_COMPLETION/test_source_metadata.json" \
  --numeric-root "$TASK_TEST_NUMERIC" \
  --train-manifest "$TASK_GOOP_INPUT/train.json" --valid-manifest "$TASK_GOOP_INPUT/valid.json" \
  --acquisition-report "$TASK_TEST_SOURCE/acquisition_report.json" --output-dir "$TASK_TEST_EVIDENCE"
```

Census checks position/type bytes and identities across all 1000/30/30 train/valid/test records, all within/across-split duplicates and exact test auxiliary bits. Outputs are `auxiliary_report.json`, `cross_split_audit.json`, `preparation_status.json`, and only on success `final_test_admission.candidate.json` with status `prepared_requires_root_review`.

Root reviews source, conversion, census, overlap and cohort bindings, preserves that candidate and creates a separate proposed `$TASK_COMPLETION/final_test_admission.json` with status `admitted_for_final_evaluation`. Then:

```sh
goop_test_prepare --mode preflight \
  --root-release "$TASK_COMPLETION/test_preparation_release.json" \
  --source-metadata "$TASK_COMPLETION/test_source_metadata.json" \
  --numeric-root "$TASK_TEST_NUMERIC" --admission "$TASK_COMPLETION/final_test_admission.json" \
  --acquisition-report "$TASK_TEST_SOURCE/acquisition_report.json" \
  --context-semantics "$TASK_PREP/goop_context_semantics_review.json" \
  --auxiliary-report "$TASK_TEST_EVIDENCE/auxiliary_report.json" \
  --cross-split-audit "$TASK_TEST_EVIDENCE/cross_split_audit.json" \
  --output "$TASK_COMPLETION/test_preflight_${TASK_ROLE}.json"
```

Preflight repeats the frozen split/evidence contract, including auxiliary arrays and four official context-semantics source files, without inference. Root also issues proposed `final_valid_admission.json` from original admitted valid/source/auxiliary pins, with final schema `adaptgns_goop_graph_support_final_evaluation_admission_v1`, status `admitted_for_final_evaluation`, `issued_by:root`, and actual `cohort_manifest_sha256`, `training_admission_sha256`, `protocol_sha256`. The unadmitted `goop_rollout_admission_valid.template.json` is only a source-field guide; its feasibility schema/status cannot launch final evaluation. No valid reconversion.

Transfer the full raw test source, numeric tree, header/acquisition/structural/auxiliary/overlap/candidate/admitted receipts, releases and A preflight to B byte-identically. Preserve original names, all partial/failure evidence and matching absolute paths; never rewrite frozen JSON merely to relocate it. The original train/valid arrays and selected checkpoints remain on their respective hosts. Verify transferred bytes and repeat the pure test preflight on B to a new `test_preflight_B.json` before B evaluation. Both hosts use identical common cohort/audit and final valid/test admissions.

## 5. Root release and launch of the Goop GPU-scoped v3 queue

Use `supervise_goop_evaluation_gpu_scoped_v3.py`, not the older broad quota-v2 wrapper. No separate reviewed v3 release generator/template was found in the frozen preparation set; its `validate_release` is the exact schema authority. Root must author fresh host-specific releases and obtain the required release review.

Required release fields: schema `adaptgns_goop_evaluation_gpu_scoped_release_v3`; status `admitted_for_execution_allocation`; `issued_by:root`; dataset `Goop`; exact `host` and `host_role`; `cost_basis:fixed_execution_allocation_not_empirical_full_horizon_forecast`; exact environment below; deadline `2026-10-07T01:00:00+00:00`; `stage_quotas_seconds` keyed by the four stage-directory names below; `cleanup_seconds_per_invocation:15`; positive `outer_processing_reserve_seconds`; fresh `process_clock_checked_utc` within 300 seconds and `clock_error_bound_seconds` in [0,5]. Enforce `now + error <= latest_start_utc <= deadline − (11760 + outer reserve + error)`.

Bind all four physical `gpu_uuids`, ordered `streams` from section 1, and exact `gpu_scope:{owned_indices:[0,1,2,3] for A or [0,1] for B, unassigned_devices:observe_without_control, timing_scope:shared_host_operational_measurement, live_training_handoff:false}`. Bind `operational_amendment:{path,sha256}`. Goop's `files_sha256` is an **absolute-path-keyed map**, including supervisor, lifecycle, lexical interpreter, evaluator, amendment, every command input and relevant immutable numerical/context source closure. Every bound file is rehashed at execution.

Each stream is `{id:arm_seedN,arm,seed,gpu,commands:[four argv arrays]}` in this exact order:

| Stage directory | `--mode` | `--split` | `--max-seconds` |
|---|---|---|---:|
| full_rollout_test | full-rollout | test | 7200 |
| same_state_valid | same-state | valid | 1800 |
| same_state_test | same-state | test | 1800 |
| clean_validation | clean-validation | valid | 900 |

Each receives 15 seconds cleanup: **11,760 seconds = 3h16m** per concurrent model stream. No empirical full-horizon runtime forecast is implied.

Child argv must begin exactly `[ABS_PYTHON, ABS_EVALUATOR, "--execute", ...paired flags...]`. Do not insert `-B` or `-u` into child argv: `command[2]` must be `--execute`. All and only these paired options are required:

```text
--repo TASK_REPO
--benchmark-helper TASK_PREP/benchmark_goop_graph_support_rollout.py
--benchmark-sha256 2e0ef0b84635c8430102cd797648d24cec14b457e1df900eb784d5e167966f8f
--cohort TASK_COHORT/cohort.json
--cohort-audit TASK_COHORT/cohort_audit.json
--manifest SPLIT_MANIFEST
--admission SPLIT_FINAL_ADMISSION
--structural-report SPLIT_STRUCTURAL
--train-admission TASK_PREP/goop_training_admission_v1.json
--trainer-source TASK_PREP/train_goop_graph_support_cuda.py
--protocol TASK_PREP/goop_graph_support_100k_protocol_v2.md
--checkpoint EXACT_SELECTED_COHORT_CHECKPOINT_PATH
--checkpoint-sha256 EXACT_SELECTED_COHORT_CHECKPOINT_SHA
--output-dir TASK_GOOP_EVAL/jobs/ARM_seedN/STAGE_DIRECTORY
--mode MODE --split SPLIT --objective faithful --arm ARM --seed N
--cuda-index PHYSICAL_INDEX --threads 2 --max-seconds STAGE_QUOTA
--acquisition-report SPLIT_ACQUISITION
--context-semantics TASK_PREP/goop_context_semantics_review.json
--auxiliary-report SPLIT_AUXILIARY
--cross-split-audit TASK_TEST_EVIDENCE/cross_split_audit.json   [TEST STAGES ONLY]
```

The text block is an argv specification; substitute absolute strings and remove its bracketed annotation. Checkpoint paths come from the common cohort and normally end in `jobs/ARM_seedN/checkpoint-000100000.pt`. Test paths are the newly admitted numeric/admission/evidence paths above. Valid paths are `$TASK_GOOP_INPUT/valid.json`, `$TASK_COMPLETION/final_valid_admission.json`, `$TASK_PREP/goop_structural_v1_report.json`, `$TASK_PREP/goop_acquisition_v1_report.json`, `$TASK_PREP/goop_auxiliary_v1_report.json`. Valid stages must omit `--cross-split-audit` entirely.

With concrete reviewed `$TASK_COMPLETION/evaluation_release_${TASK_ROLE}_v3.json`, fresh process/clock/UUID evidence and a fresh queue output:

```sh
env -u CUDA_VISIBLE_DEVICES CUBLAS_WORKSPACE_CONFIG=:4096:8 \
  LD_LIBRARY_PATH=/usr/lib/aarch64-linux-gnu:/usr/local/nvidia/lib:/usr/local/nvidia/lib64 \
  "$TASK_PY" -B -u "$TASK_PREP/supervise_goop_evaluation_gpu_scoped_v3.py" \
  --execute --release "$TASK_COMPLETION/evaluation_release_${TASK_ROLE}_v3.json" \
  --lifecycle-source "$TASK_PREP/measure_sand_cuda_capacity_v2.py" --output-dir "$TASK_GOOP_EVAL"
```

After stopped queues and owned-child reaping, use the staged `summarize_goop_graph_support_scoped_v3.py` collector under its own fixed release/interface, not the old v2 collection command in older notes. Preserve all 6×30×6 = **1,080** full-rollout cells plus fixed diagnostics. Missing/quota/guarded outcomes remain distinct. Shared-host durations are operational measurements and cannot establish isolated policy speedup.

## 6. Exact Sand training launch after each host's safe handoff

Use the three `sand_scoped_{scientific_release,process_check,clock_check}.template.json` files as field guides only. Root completes new receipts/releases from fresh native evidence; templates are not admitted. Process/clock evidence must be at most 300 seconds old, clock error [0,5], all four UUIDs and complete raw GPU processes retained. Closure records bind actual prior PID/start_ticks/argv, with at least a trainer and the **entire** original whole-host training supervisor, both stopped/reaped/exited; matching Sand trainers and active old whole-host monitors must be empty. A additionally requires all prior Goop GPU work reaped. A reused PID is distinguished by native start_ticks and never adopted.

Release schema is `adaptgns_sand_scoped_scientific_release_v1`, status `admitted_fresh_scoped_training`, `issued_by:root`, `scientific_training_admitted:true`, with the exact all-six schedule, common cohort ID, host role/output directory, original scientific pins and frozen amendment/schedule fields from the template. Sand's `files_sha256` uses **semantic keys** (`trainer`, `capacity_source`, `lifecycle_source`, `verifier_source`, `train_manifest`, `admission`, `structural_report`, `protocol`, `schedule_plan`, `amendment`, `process_check`, `clock_check`, `python`, `supervisor`, `python_target`, and `python_venv_config` when present), unlike Goop's absolute-path map.

Preserve lexical `.venv/bin/python` in `--python` and supervisor/child argv. Root `python_environment` binds lexical path, resolved binary/hash, `sys.prefix`, `sys.base_prefix`, and actual `pyvenv.cfg` path/hash. Do not substitute the resolved system binary for the lexical venv interpreter. Fresh source/input/clock/process checks remain necessary despite saved package metadata.

Proposed release/check paths below are new root-authored files in `TASK_COMPLETION`; Sand outputs are separate from Goop. After the corresponding B or A handoff gate:

```sh
env -u CUDA_VISIBLE_DEVICES CUBLAS_WORKSPACE_CONFIG=:4096:8 \
  LD_LIBRARY_PATH=/usr/lib/aarch64-linux-gnu:/usr/local/nvidia/lib:/usr/local/nvidia/lib64 \
  "$TASK_PY" -B -u "$TASK_PREP/supervise_sand_scoped_science_v1.py" \
  --execute --host-role "$TASK_ROLE" --release "$TASK_COMPLETION/sand_release_${TASK_ROLE}.json" \
  --repo "$TASK_REPO" --trainer "$TASK_PREP/train_sand_graph_support_cuda.py" \
  --capacity-source "$TASK_PREP/measure_sand_graph_support_capacity.py" \
  --lifecycle-source "$TASK_PREP/measure_sand_cuda_capacity_v2.py" \
  --verifier-source "$TASK_PREP/supervise_sand_graph_support_science.py" \
  --train-manifest "$TASK_SAND_INPUT/train.json" --admission "$TASK_PREP/sand_train_admission.json" \
  --structural-report "$TASK_PREP/sand_numeric_structural_report.json" \
  --protocol "$TASK_PREP/sand_graph_support_100k_protocol_v1.md" \
  --schedule-plan "$TASK_PREP/sand_scoped_schedule_fixed_spec_v2.json" \
  --amendment "$TASK_PREP/sand_scoped_operational_amendment_v1.md" \
  --process-check "$TASK_COMPLETION/sand_process_${TASK_ROLE}.json" \
  --clock-check "$TASK_COMPLETION/sand_clock_${TASK_ROLE}.json" \
  --python "$TASK_PY" --output-dir "$TASK_SAND_TRAIN"
```

Use the scientific 100k protocol above, not the earlier capacity protocol or `stop-after512` configuration. The helper chain constructs the unchanged faithful 100k/two-thread/log100/checkpoint10k runs; no arbitrary child argv or resume is admitted.

Both roles enforce latest **actual child launch October 6 15:05 UTC**, training/endpoint-audit stop **22:44 UTC**, training allocation `27404.671591931674` seconds and cleanup starting no later than `22:44 − clock error − 15 seconds`. Source additionally requires `latest_start + allocation <= cleanup start` and rechecks time immediately before each child. Posttraining reserve is 18,960 seconds: 11,760 evaluation + 900 preparation + 2,700 cohort/source + 3,600 analysis. Computation/analysis ends October 7 04:00 UTC; writing 04:00–08:00; hard no-new-work 08:00.

Planning arithmetic, not a protocol amendment: to leave A's full 11,760-second Goop allocation before the latest Sand launch, Goop A must start by **11:49 UTC minus clock/handoff slack**. The earlier target Sand A start 14:00 corresponds to Goop A 10:44 minus slack. These are not observed launch times. Preserve missing/failed studies if the fixed all-six schedule does not fit; there is no reduced-model/update or two-GPU three-wave fallback. Sand host summaries still require later complete-six cohort freeze and source/test admission.

## 7. Frozen reference hashes and remaining dependencies

These are source/reference pins, not newly observed remote data/checkpoint hashes.

| File or `FINAL_PINS` key | SHA256 |
|---|---|
| `prepare_goop_final_cohort_quota_v2.py` | `5ec953969dd79326c5b878ed7b6ab5359cd91304b8cb1db169241262804da30c` |
| `prepare_goop_reserved_test_v1.py` | `4b72fc5f4aff5dc1abe6ec6be55e961b88dc557cc3a43ad394c7c679294fd539` |
| `prepare_goop_official.py` | `fa4b7d883d7c360500fc3c603c9cd14538c916f1ddd7435aedfc8ec2420f2985` |
| `research/prepare_full_waterdrop.py` | `ab077f11240a7296a2a15679ae8a57032c91280fdc94c23b63155e86793d2f33` |
| `protocol` | `c8690d0da209c66557e3dbb0cbccd55d660b4cc270683913f74d381516591851` |
| `train_admission` | `c2a12ef0c55b47f4c9493027450f8b51f52dbbd6043915bb09c1648b6cb9edeb` |
| `trainer_source` | `dd9ef01a16116f04a578bbfe9ed01774e66fdc08d60b913072a33ad211b319c1` |
| `benchmark_helper` | `2e0ef0b84635c8430102cd797648d24cec14b457e1df900eb784d5e167966f8f` |
| `data_contract` | `4ee1e33dbe666804d1827b88565620a435d04836a170671914a71acb818be090` |
| `diagnostic_source` | `cd970e04012930d896b31944271ccaf7da2b0881f22fe2f903533a8d5911dc6d` |
| `supervise_goop_evaluation_gpu_scoped_v3.py` | `a13ca1bc30161f89cf79b6c0b632c65a272913302ef0cc37dcfd7ed762c6aa21` |
| `goop_gpu_scoped_evaluation_amendment_v3.md` | `0ecb8d3c6b5dd74150d6253cc84be2548827b235490eb35da50afcc0df6e28f4` |
| `supervise_sand_scoped_science_v1.py` | `2970922593f41f74713aff9208e4c6964bb1b3f351fee906724bbf52f11d4d13` |
| `sand_scoped_schedule_fixed_spec_v2.json` | `403a96c1304341ea1899c994e0ab7474280add44ea5986ec41570e08d16c337b` |
| `sand_scoped_operational_amendment_v1.md` | `411547c3355859906f59792b3b493841030b0afd2e105e17e466114df6743738` |

The execution dependencies are now explicit: actual complete Goop receipts and native inactivity; fresh per-host inventories and root cohort mapping; successful admitted HEAD/GET/conversion/census and final admissions; identical transferred bytes and destination preflight; concrete reviewed v3 evaluation and Sand releases with fresh process/clock/UUID/interpreter evidence; and enough remaining fixed allocation. Saved staging/package presence does not establish these outcomes. No remaining package absence is inferred from the older closure reports. Preserve every unsuccessful output and do not reopen sealed numerical/scientific decisions to make a late schedule fit.
