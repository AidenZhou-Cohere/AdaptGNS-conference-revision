# Goop2D cost candidate — UNADMITTED

These controls contain known paths and hashes from pinned local metadata. Authority and all clock fields remain null. They have not been issued or staged; the 3,600-second clock has not started.

The complete input map has 134 distinct paths: 8 entry/new sources, 12 frozen numerical helpers, 4 preserved context sources, 11 controls, 60 validation position/type arrays, 30 preserved validation context arrays, 6 actual checkpoint paths and 3 interpreter/venv paths. Original A lineage paths remain separate from actual B input paths.

The two base seed-0/1 destinations need charged transfer before pilot; mix seed-0/1 use prior gate-copy path metadata, and seed-2 uses original B paths. Every actual checkpoint and input needs a fresh rehash. No model or array payload was opened.

Root owns fresh native/device-memory checks, monotonic/boot clock capture, source/input staging, pilot issuance, measured capacity admission, and any launch. The pilot does not authorize the full study.
