import sys,json,pathlib,base64,hashlib,time,os,socket
x=json.load(sys.stdin);raw=base64.b64decode(x['raw']);assert hashlib.sha256(raw).hexdigest()==x['sha256'];r=json.loads(raw)
assert socket.gethostname()==r['hostname'] and pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()==r['clock_origin']['host_boot_id'];assert time.monotonic()-r['clock_origin']['host_monotonic_seconds']+5<900
p=pathlib.Path(x['path'])
with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
source=r['sources']['supervise_goop2d_validation_cost_v3.py'];assert hashlib.sha256(pathlib.Path(source['path']).read_bytes()).hexdigest()==source['sha256']
env=os.environ.copy();env.update(r['environment']);env.pop('CUDA_VISIBLE_DEVICES',None)
argv=[r['python']['lexical_path'],source['path'],'--execute','--release',str(p)]
print(json.dumps(dict(status='release_staged_exec_owner_next',pid=os.getpid(),start_ticks=int(pathlib.Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19]),argv=argv,release_sha256=x['sha256'])),flush=True)
os.execve(argv[0],argv,env)
