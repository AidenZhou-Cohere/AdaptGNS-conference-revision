import pathlib,subprocess,json,hashlib,base64,shlex,datetime
Q=pathlib.Path(__file__).resolve().parent;P=Q.parent
raw=(Q/'pilot_release.json').read_bytes();r=json.loads(raw)
assert hashlib.sha256(raw).hexdigest()=='9208335e2a0c71049707fa1163b92eaef06f900c889c7283305fa0bf42c5c27f'
remote=r['repo']+'/cuda_preparation/goop2d_validation_cost_pilot_release_root_v2.json'
code='''import sys,json,pathlib,base64,hashlib,time,os,socket
x=json.load(sys.stdin);raw=base64.b64decode(x['raw']);assert hashlib.sha256(raw).hexdigest()==x['sha256'];r=json.loads(raw)
assert socket.gethostname()==r['hostname'] and pathlib.Path('/proc/sys/kernel/random/boot_id').read_text().strip()==r['clock_origin']['host_boot_id'];assert time.monotonic()-r['clock_origin']['host_monotonic_seconds']+5<300
p=pathlib.Path(x['path'])
with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
source=r['sources']['supervise_goop2d_validation_cost_v2.py'];assert hashlib.sha256(pathlib.Path(source['path']).read_bytes()).hexdigest()==source['sha256']
env=os.environ.copy();env.update(r['environment']);env.pop('CUDA_VISIBLE_DEVICES',None)
argv=[r['python']['lexical_path'],source['path'],'--execute','--release',str(p)]
print(json.dumps(dict(status='release_staged_exec_owner_next',pid=os.getpid(),start_ticks=int(pathlib.Path('/proc/self/stat').read_text().rsplit(') ',1)[1].split()[19]),argv=argv,release_sha256=x['sha256'])),flush=True)
os.execve(argv[0],argv,env)
'''
command='env LD_LIBRARY_PATH=/usr/lib/aarch64-linux-gnu:/usr/local/nvidia/lib:/usr/local/nvidia/lib64 CUBLAS_WORKSPACE_CONFIG=:4096:8 '+r['python']['lexical_path']+' -B -c '+shlex.quote(code)
(Q/'pilot_remote_launch_source.py').write_text(code)
payload=json.dumps(dict(raw=base64.b64encode(raw).decode(),sha256=hashlib.sha256(raw).hexdigest(),path=remote)).encode()
with (Q/'pilot_launcher.log').open('xb') as log:
 p=subprocess.Popen(['ssh','-T','-F',str(P/'ssh_config'),'aquamarine-toad-75.coder',command],stdin=subprocess.PIPE,stdout=log,stderr=subprocess.STDOUT)
 p.communicate(payload)
with (Q/'pilot_external_exit.json').open('x') as f:json.dump(dict(exit_code=p.returncode,observed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),release_sha256=hashlib.sha256(raw).hexdigest(),remote_release_path=remote),f,indent=2);f.write('\n')
print(json.dumps(dict(exit_code=p.returncode,remote_release=remote)))
raise SystemExit(p.returncode)
